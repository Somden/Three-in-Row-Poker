﻿angular
    .module('LoginApp', ['ngCookies', 'LeadApp'])
    .controller('LoginController', ["$http", "$cookies", "pageFactory",
        function ($http, $cookies, pageFactory) {
            var vm = this;
            vm.errorMessage = "";
            vm.email = '';
            vm.password = '';


            function tryLogin(email, password) {
                return $http({
                    method: 'POST',
                    url: '/Token',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    transformRequest: function (obj) {
                        var str = [];
                        for (var p in obj)
                            str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                        return str.join("&");
                    },
                    data: { grant_type: 'password', username: email, password: password }
                });
            }

            vm.loginClick = function () {
                vm.loginButtonDisabled = true;
                tryLogin(vm.email, vm.password)
                    .then(function (result) {
                        vm.errorMessage = "";
                        $cookies.put("FallbackAuthentication", result.data.access_token, { path: "/" });
                        location.href = "/";
                    })
                    .catch(function (result) {
                        vm.loginButtonDisabled = false;
                        vm.password = "";
                        vm.errorMessage = "Invalid username or password";
                    });
            };

            vm.getLanguages = function () {
                return pageFactory.languageSettings;
            }

        }
    ]);
