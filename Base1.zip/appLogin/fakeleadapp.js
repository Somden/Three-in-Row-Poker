﻿// Global attributes for configurations
var globalConfig = {};

angular
    .module('LeadApp', ["ngRoute", "ngResource", "ngCookies", 'pascalprecht.translate']);