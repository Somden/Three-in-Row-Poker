﻿'use strict';

angular
    .module("LeadApp")
    .controller('ContractOverviewController', [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder", "KENDO_OVERVIEW_TEMPLATE_PATH","resourceFactory","messageFactory","promptFactory",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder, KENDO_OVERVIEW_TEMPLATE_PATH,resourceFactory,messageFactory,promptFactory) {
            var vm = this;
            vm.shouldSearchWithEnter = true;
            vm.searchTextComment = "";
            vm.showCommentSearch = false;
            vm.showLargeView = true;
            vm.KENDO_OVERVIEW_TEMPLATE_PATH = KENDO_OVERVIEW_TEMPLATE_PATH;

            /*Methods*/ {
                /*Public methods*/ {
                    vm.new = function () {
                        if (vm.isTemplate) {
                            location.href = "#!/contract/templates/new";
                        }
                        else {
                            location.href = "#!/contract/contracts/new";
                        }
                    };

                    vm.canCreate = function () {
                        for (var f in $rootScope.currentUser.UserCompanies) {
                            var userCompany = $rootScope.currentUser.UserCompanies[f];
                            if (userCompany.CanModify) {
                                return true;
                            }
                        }

                        return false;
                    };

                    vm.canSeeAnyContracts = function () {
                        return $rootScope.currentUser.IsAdmin || $rootScope.currentUser.UserCompanies.length > 0 ; 
                    };

                    vm.startCommentSearch = function (arg) {
                        if (arg != null) {
                            if ((arg.which || arg.keyCode) == 13) //Enter
                            {
                                vm.searchGridData(vm.searchTextComment);
                            }
                        }
                    };

                    vm.hideCommentSearch = function () {
                        vm.showCommentSearch = !vm.showCommentSearch;
                        vm.searchTextComment = "";
                        vm.searchGridData(vm.searchTextComment);
                    };

                    vm._onSearchTextChange = function () {
                        if (!vm.shouldSearchWithEnter) {
                            vm.searchGridData(vm.searchTextComment);
                        }
                    };
                }

                /*Private methods*/ {
                    vm.revertToValidated = function (arg, dataItem) {
                        arg.stopPropagation();
                        var success = function() {
                            vm._changeToState('Validated', dataItem);    
                        }
                        $scope.promptContactDescription = dataItem.ContractName;
                        promptFactory(success,
                            $scope,
                            {
                                messageText: "PROMPT_NOTEDITABLESTATE_DISCARD",
                                templateUrl: "promptDiscardModal"
                            });
                    }

                    vm.revertToOldState = function (arg, dataItem) {
                        arg.stopPropagation();
                        vm._changeToState(dataItem.RevertChanges.ChangedState, dataItem);
                    }

                    vm._changeToState = function (newstate, dataItem) {
                        var successCallback = function (resp) {
                            
                            if (newstate === 'Validated') {
                                dataItem.CanRevert = true;
                                dataItem.RevertChanges = {
                                    RetirementDate: resp.Payload.CurrentContractRevision.RetirementDate,
                                    ChangedState: resp.Payload.CurrentContractRevision.ContractRevisionState.Value
                                };
                                messageFactory.showSuccessMessage("MESSAGE_REVISION_NOW_EDTABLE");
                            } else {
                                dataItem.CanRevert = false;
                                dataItem.RevertChanges = {};
                            }
                            
                            dataItem.ContractRevisionState = newstate;
                            
                        };

                        var validatingLoadingId = messageFactory.loadingMessage.show("LOADING_VALIDATING_CONTRACT");

                        var finalCallback = function() {
                            messageFactory.loadingMessage.hide(validatingLoadingId);
                        }

                        var newState = {
                            activateDate: null,
                            retirementDate: null,
                            newContractrevisionState: newstate,
                            createNewContractRevisionForReassessment: null,
                            createNewContractRevisionForModification: null
                        };

                        if (dataItem.RevertChanges) {
                            newState.retirementDate = dataItem.RevertChanges.RetirementDate;
                        }

                        resourceFactory
                            .contractRevisionState(dataItem.Id)
                            .changeState(newState)
                            .$promise
                            .then(successCallback)
                            .catch(function(e) {
                                console.error(e);

                                $scope.resourceErrors = {
                                    list: e.data.ValidationErrors
                                }
                            }).finally(finalCallback);
                    };

                    vm.openEntity = function (contractId) {
                        if (vm.isTemplate) {
                            location.href = "#!/contract/templates/" + contractId;
                        }
                        else {
                            location.href = "#!/contract/contracts/" + contractId;
                        }
                    };

                    vm.setTitle = function () {
                        if (vm.isTemplate) {
                            pageFactory.setTitle("TITLE_CONTRACT_TEMPLATES");
                            vm.isTemplate = true;
                        }
                        else {
                            pageFactory.setTitle("TITLE_CONTRACTS");
                            vm.isTemplate = false;
                        }
                    };

                    vm.initializeGrid = function (callback) {
                        var url = vm.isTemplate ? "/odata/TemplateOverview" : "/odata/ContractOverviewView";

                        kendoGridBuilder(
                            url,
                            "ContractOverviewView",
                            null,
                            vm.openEntity,
                            function (gridDefinition) {
                                $scope.$apply(function () {
                                    vm.gridOptions = gridDefinition;
                                });
                            });
                    }

                    vm.searchGridData = function (selectedItem) {
                        if (selectedItem.length < 3) {
                            vm.gridOptions.dataSource.filter({});
                            return;
                        }

                        selectedItem = selectedItem.toUpperCase();
                        if (selectedItem) {
                            var orFilter = { logic: "or", filters: [] };

                            angular.forEach(vm.gridOptions.columns, function (key, column) {
                                if (key.isSearchEnabled != null && key.isSearchEnabled == true) {
                                    orFilter.filters.push({ field: key.field, operator: "contains", value: selectedItem });
                                }
                            });

                            vm.gridOptions.dataSource.filter(orFilter);
                        }
                    };
                }
            }

            vm.isTemplate = $routeParams.contractState == "templates";
            vm.setTitle();

            vm.initializeGrid();
        }
    ]);