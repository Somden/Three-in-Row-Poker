'use strict';

angular
    .module('LeadApp')
    .controller('ContractController', [
        "$scope", "$rootScope", "$route", "$routeParams", "$translate", "$uibModal", "pageFactory", "messageFactory", "resourceFactory", "contractValidator", "contractRevisionValidator", "accountingStandardsValidator", "rightOfUseAssetValidator", "assetValidator", "assetComponentValidator", "purchaseOptionValidator", "contractLeasingPeriodValidator", "extensionLeasingPeriodValidator", "kendoDataSourceBuilder","promptFactory","kendoReportFactory",
        function ($scope, $rootScope, $route, $routeParams, $translate, $uibModal, pageFactory, messageFactory, resourceFactory, contractValidator, contractRevisionValidator, accountingStandardsValidator, rightOfUseAssetValidator, assetValidator, assetComponentValidator, purchaseOptionValidator, contractLeasingPeriodValidator, extensionLeasingPeriodValidator, kendoDataSourceBuilder,promptFactory,kendoReportFactory) {
            var self = this;
            var isHelpVisible = false;
            var isTemplate = false;
            var isFormReadonly = false;
            var reportHandler = null;

            function constructor() {
                $scope.contractRevisions = {};
                $scope.selectedContractRevision = { Id: 0 };
                $scope.generalCommentIndex = "";
                $scope.terminateCommentIndex = "";
                $scope.adjustmentCommentIndex = "";
                $scope.indexBindingCommentIndex = "";
                $scope.validator = [contractValidator,contractRevisionValidator];
                
                $scope.globalConfig = globalConfig;

                isTemplate = $routeParams.contractState == "templates"

                $scope.currencyCode = "---";

                $scope.resourceErrors = {
                    list: [],
                    shouldShowAllResourceErrors: false
                };

                self.setTitle(isTemplate, $scope.isNewContract());
                self.initializePage();

                if ($routeParams.contractId == "new") {
                    self.loadNewContract();
                }
                else {
                    self.loadContractById($routeParams.contractId);
                }

                contractValidator.reloadExternalData();
            }

            /*#region Public methods*/ {
                $scope.isLoadingScreenVisible = function () {
                    return messageFactory.loadingMessage.isLoadingScreenVisible();
                };

                self.setDefaultAssetComponent = function () {
                    if (!isTemplate) {
                        resourceFactory
                            .emptyEntity("getDefaultAssetWithComponent", $scope.templateBaseId)
                            .getDefaultAssetWithComponent()
                            .$promise
                            .then(function (resp) {
                                $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets = resp.Payload;
                            })
                            .catch(function (e) {
                                console.error(e);

                                if (isTemplate) {
                                    location.href = "#!/contract/templates";
                                }
                                else {
                                    location.href = "#!/contract";
                                }
                            })
                            .finally(function () {
                            });
                    }
                };

                $scope.makeCurrentRevisionEditable = function () {
                    var loadingId = messageFactory.loadingMessage.show("LOADING_MAKE_REVISION_EDITABLE");

                    self.setNewState("Pending", {
                        finalCallback: function () {
                            messageFactory.loadingMessage.hide(loadingId);
                            messageFactory.showSuccessMessage("MESSAGE_REVISION_NOW_EDTABLE");
                        }
                    });
                };

                $scope.canModify = function () {
                    if ($scope.isNewContract()) return true;
                    if (isTemplate) return true;
                    if ($scope.contract == null) return false;
                    if ($scope.contract.Company == null) return false;

                    for (var f in $rootScope.currentUser.UserCompanies) {
                        var userCurrentCompany = $rootScope.currentUser.UserCompanies[f];
                        if (userCurrentCompany.Company.Id == $scope.contract.Company.Id) {
                            return userCurrentCompany.CanModify;
                        }
                    }

                    return false;
                };

                $scope.togglePartnerSelectOrAdd = function () {
                    $scope.showAddPartnerBox = !$scope.showAddPartnerBox;
                    if ($scope.showAddPartnerBox) {
                        $scope.buttonAddPartnerText = "FORM_CONTRACT_BUTTON_SELECT_PARTNER";
                    }
                    else {
                        $scope.buttonAddPartnerText = "FORM_CONTRACT_BUTTON_ADD_PARTNER";
                    }
                };

                $scope.deleteContract = function () {
                    if (!$rootScope.currentUser.IsAdmin) return;

                    var callback = function () {
                        var loadingId = messageFactory.loadingMessage.show(isTemplate
                            ? "REMOVING_CONTRACT_TEMPLATE"
                            : "REMOVING_CONTRACT");

                        resourceFactory
                            .contract($scope.contract.Id)
                            .remove()
                            .$promise
                            .then(function (resp) {
                                if (isTemplate) {
                                    location.href = "#!/contract/templates";
                                } else {
                                    location.href = "#!/contract";
                                }
                            })
                            .catch(function (e) {
                                console.error(e);

                                $scope.resourceErrors = {
                                    list: []
                                };
                                $scope.resourceErrors.list.push(resp.data);
                            })
                            .finally(function () {
                                messageFactory.loadingMessage.hide(loadingId);
                            });
                    };

                    var config = {
                        messageText: isTemplate ? "PROMPT_DELETE_TEMPLATE" : "PROMPT_DELETE_CONTRACT"
                    };

                    self.prompt(callback, config);
                };

                // Create Contract using current Template
                $scope.copyAs = function (isTemplate) {
                    if ($scope.isInitialRevision()) {
                        $scope.contract.CurrentContractRevision.ContractRevisionState_Id = 20;
                        $scope.contract.CurrentContractRevision.ContractRevisionState.Value = "Pending";
                        $scope.contract.CurrentContractRevision.ContractRevisionState.Id = 20;
                        $scope.contract.DisplayedContractRevision.ContractRevisionState_Id = 20;
                        $scope.contract.DisplayedContractRevision.ContractRevisionState.Value = "Pending";
                        $scope.contract.DisplayedContractRevision.ContractRevisionState.Id = 20;
                        $scope.templateBaseId = $scope.contract.Id;
                        $routeParams.contractId = "new";
                        isFormReadonly = false;
                        $routeParams.contractState = isTemplate ? "templates" : "contracts";
                        isTemplate = isTemplate;
                        constructor();
                    }
                    else {
                        messageFactory.showErrorMessage("DECLINED_COPY_CONTRACT_COMMENT");
                    }
                };

                // Removes a pending reassessment
                $scope.discardRessessment = function () {
                    var loadingId = messageFactory.loadingMessage.show("LOADING_DISCARDING_CHANGES");

                    var successCallback = function (resp) {
                        messageFactory.showSuccessMessage("MESSAGE_DISCARDED_CHANGES");

                        $route.reload();
                    };

                    resourceFactory
                        .contractRevisionState($scope.contract.Id)
                        .discardPendingChanges()
                        .$promise
                        .then(successCallback)
                        .catch(function (e) {
                            console.error(e);

                            $scope.resourceErrors = {
                                list: resp.data.ValidationErrors
                            }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                };

                // Saves contract and on success it goes back to the contract overview
                $scope._onClickSaveAndGoBack = function () {
                    self.save(function () {
                        if (isTemplate) {
                            location.href = "#!/contract/templates";
                        }
                        else {
                            location.href = "#!/contract";
                        }
                    });
                };

                // Saves contract and on success it reloads the contract
                $scope._onClickSave = function (callback) {
                    self.save(function (resp) {
                        if (isTemplate) {
                            location.href = "#!/contract/templates/" + resp.Payload.Id;
                        }
                        else {
                            location.href = "#!/contract/contracts/" + resp.Payload.Id;
                        }
                    });
                };

                // Set Currency labels when a new currency is chosen
                $scope._onCurrencyChange = function () {
                    if ($scope.contract.Currency.Code != null) {
                        $scope.currencyCode = $scope.contract.Currency.Code;
                    }
                };

                // If selectedContractRevision, bring it to the display
                $scope._onSelectedContractRevisionChange = function () {
                    if ($scope.contract == null || $scope.selectedContractRevision.Id <= 0) return;

                    if ($scope.contractRevisions[$scope.selectedContractRevision.Id] == null) {
                        var loadingId = messageFactory.loadingMessage.show("LOADING_CONTRACT_REVISION");
                        resourceFactory
                            .contractRevision($scope.selectedContractRevision.Id)
                            .getById()
                            .$promise
                            .then(function (resp) {
                                $scope.contract.DisplayedContractRevision = resp.Payload;
                                $scope.contractRevisions[$scope.contract.DisplayedContractRevision.Id] = $scope.contract.DisplayedContractRevision;

                                isFormReadonly = !$scope.isCurrentRevision() || $scope.isDeleted() || !$scope.isPending() || !$scope.canModify();
                                self.initializeDropDowns();
                            })
                            .catch(function (e) {
                                console.error(e);

                                if (isTemplate) {
                                    location.href = "#!/contract/templates";
                                }
                                else {
                                    location.href = "#!/contract";
                                }
                            })
                            .finally(function () {
                                messageFactory.showSuccessMessage("MESSAGE_SHOWING_NEW_REVISION");

                                messageFactory.loadingMessage.hide(loadingId);
                            });
                    }
                    else if ($scope.contract.DisplayedContractRevision.Id != $scope.selectedContractRevision.Id) {
                        messageFactory.showSuccessMessage("MESSAGE_SHOWING_NEW_REVISION");

                        $scope.contract.DisplayedContractRevision = $scope.contractRevisions[$scope.selectedContractRevision.Id];

                        isFormReadonly = !$scope.isCurrentRevision() || $scope.isDeleted() || !$scope.isPending() || !$scope.canModify();
                        self.initializeDropDowns();
                    }
                };

                // In initial revision, activate date equals commencement date
                $scope._onCommencementDateChange = function () {
                    if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return;
                    if ($scope.contract.DisplayedContractRevision.ContractLeasingPeriod == null) return;

                    if ($scope.contract.DisplayedContractRevision.Revision == 0) {
                        $scope.contract.DisplayedContractRevision.ActivateDate = $scope.contract.CommencementDate;
                    }
                };

                /* Goes through all children of the referenced element and
                   checks, whether they are marked to be invalid.
                   Return true if any child has css-class ".md-input-invalid",
                   or attribute data-error-count="x" (with x bigger than zero).
                */
                $scope.doesElementContainInvalidFields = function (elementId) {
                    var validationErrors = $(".md-input-invalid:not([data-error-count])", "#" + elementId).length;

                    if (validationErrors > 0) return true;

                    $("[data-error-count]", "#" + elementId).each(function () {
                        var count = $(this).attr("data-error-count") * 1.0;
                        validationErrors += count;

                        if (validationErrors > 0) return false; // Causes the each-loop to break
                    });

                    return validationErrors > 0;
                };

                // Executes all validators and determines whether there are any validation errors
                $scope.validateContract = function () {
                    if ($scope.contract == null || $scope.contract.Id == null) {
                        return true;
                    }

                    var isValid = true;
                    isValid &= contractValidator.validate($scope.contract).isValid;
                    isValid &= accountingStandardsValidator.validate($scope.accountingStandard).isValid;
                    isValid &= contractRevisionValidator.validate($scope.contract.DisplayedContractRevision).isValid;

                    if ($scope.contract.DisplayedContractRevision.RightOfUseAsset != null) {
                        isValid &= rightOfUseAssetValidator.validate($scope.contract.DisplayedContractRevision.RightOfUseAsset).isValid;

                        for (var f in $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets) {
                            var asset = $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets[f];
                            isValid &= assetValidator.validate(asset).isValid;

                            for (var g in asset.AssetComponents) {
                                var assetComponent = asset.AssetComponents[g];
                                validationResult = assetComponentValidator.validate(assetComponent);
                                isValid &= validationResult.isValid;
                            }
                        }
                    }

                    var validationResult = contractLeasingPeriodValidator.validate($scope.contract.DisplayedContractRevision.ContractLeasingPeriod);
                    isValid &= validationResult.isValid;

                    var extensionLeasingPeriods = $scope.contract.DisplayedContractRevision.ExtensionLeasingPeriods;
                    for (var f in extensionLeasingPeriods) {
                        var extensionLeasingPeriod = extensionLeasingPeriods[f];
                        validationResult = extensionLeasingPeriodValidator.validate(extensionLeasingPeriod);
                        isValid &= validationResult.isValid;
                    }

                    return !isValid;
                };

                $scope.hasFormErrors = function () {
                    if ($scope.contract == null) return;

                    return $scope.validateContract();
                };

                // Toggles whether to show or hide any help areas
                $scope.toggleShowHelp = function () {
                    isHelpVisible = !isHelpVisible;

                    if (isHelpVisible) {
                        messageFactory.showSuccessMessage($translate.instant("MESSAGE_TOOLTIPS_ACTIVATED"));
                    }
                };

                /*#region Boolean-properties*/ {
                    // Whether the current contract is a new contract
                    $scope.isNewContract = function () {
                        return $scope.contract != null && $scope.contract.Id < 0;
                    };

                    // Whether the current revision is the initial one
                    $scope.isInitialRevision = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;

                        return $scope.contract.DisplayedContractRevision.ModificationType.Value == "Initial";
                    };

                    // Whether the current revision is a reassessment
                    $scope.isReassessment = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;
                        return $scope.contract.DisplayedContractRevision.ModificationType.Value == "Reassement";
                    }

                    // Whether the current revision is a reassessment
                    $scope.isModification = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;

                        return $scope.contract.DisplayedContractRevision.ModificationType.Value == "Modification";
                    };

                    // Whether the current revision is in pending status
                    $scope.isCurrentRevision = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null || $scope.contract.CurrentContractRevision == null) return false;

                        return $scope.contract.DisplayedContractRevision.Id == $scope.contract.CurrentContractRevision.Id;
                    };

                    // Whether the current revision is in pending status
                    $scope.isDeleted = function () {
                        if ($scope.contract == null) return false;

                        return $scope.contract.IsDeleted || false;
                    };

                    // Whether the current revision is in pending status
                    $scope.isPending = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;

                        return $scope.contract.DisplayedContractRevision.ContractRevisionState.Value == 'Pending';
                    };

                    // Whether the current revision is in validated status
                    $scope.isValidated = function () {
                        if ($scope.contract == null || $scope.contract.CurrentContractRevision == null) return false;

                        return $scope.contract.CurrentContractRevision.ContractRevisionState.Value == 'Validated';
                    };

                    // Whether the current revision is in completed status
                    $scope.isCompleted = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;

                        return $scope.contract.CurrentContractRevision.ContractRevisionState.Value == 'Completed';
                    };

                    // Whether the current revision is in terminated status
                    $scope.isTerminated = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;

                        return $scope.contract.CurrentContractRevision.ContractRevisionState.Value == 'Terminated';
                    };

                    // Whether the current contract is one for lessees
                    $scope.isLessee = function () {
                        if ($scope.contract == null || $scope.contract.ContractType == null) return false;

                        return $scope.contract.ContractType.Value == 'Lessee';
                    };

                    // Whether the current contract is one for lessors
                    $scope.isLessor = function () {
                        if ($scope.contract == null || $scope.contract.ContractType == null) return false;

                        return $scope.contract.ContractType.Value == 'Lessor';
                    };

                    // Whether the current revision is readonly
                    $scope.isFormReadonly = function () {
                        return isFormReadonly;
                    };

                    // Whether the current contract is a template
                    $scope.isTemplate = function () {
                        return isTemplate;
                    };

                    // Just a getter for isHelpVisible
                    $scope.isHelpVisible = function (newValue) {
                        if (newValue != null) {
                            isHelpVisible = newValue;
                        }

                        return isHelpVisible;
                    };

                    $scope.isAddPartnerButtonVisible = function () {
                        return !$scope.isFormReadonly() && !$scope.isReassessment() && !$scope.isModification();
                    };

                    // Whether the current revision can be discarded
                    $scope.canDiscardRevision = function () {
                        if ($scope.contract == null || $scope.contract.DisplayedContractRevision == null) return false;

                        return $scope.isPending()
                            && !$scope.isInitialRevision()
                            && !$scope.isFormReadonly()
                            && !$scope.isLoadingScreenVisible();
                    };

                    // Whether the current contract can be saved as validated
                    $scope.canSave = function () {
                        return !$scope.isFormReadonly()
                            && !$scope.isLoadingScreenVisible()
                            && !$scope.hasFormErrors()
                            && $scope.isPending()
                            && $scope.canModify();
                    };

                    // Whether the current contract can be saved as validated
                    $scope.canSaveAsValidated = function () {
                        return $scope.isPending() && !$scope.isNewContract() && !isTemplate;
                    };

                    // Whether for the current revision can be created a reassessment
                    $scope.canCreateReassessment = function () {
                        return $scope.isValidated();
                    };

                    // Whether for the current revision can be created a modification
                    $scope.canCreateModification = function () {
                        return $scope.isValidated();
                    };

                    // Whether for the current revision a type of lease can be classified
                    $scope.canClassifyTypeOfLease = function () {
                        if ($scope.contract == null) return false;
                        if ($scope.contract.DisplayedContractRevision == null) return false;
                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset == null) return false;
                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets == null) return false;

                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets.length != 1) return false;
                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets[0].AssetComponents == null) return false;
                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets[0].AssetComponents.length != 1) return false;

                        return true;
                    };
                }

                /*#region Prompts*/ {
                    // Ask-dialog before validating the contract
                    $scope.askForValidation = function () {
                        self.prompt(self.setValidated, {
                            messageText: "PROMPT_VALIDATE"
                        });
                    };

                    // Ask-dialog before opening reassessment
                    $scope.askForReassessment = function () {
                        $scope.askForReassessmentModal = {
                            isOpen: true,
                            contract: $scope.contract,
                            callback: function (activateDate) {
                                self.createReassessment(activateDate);
                            }
                        };
                    };

                    // Ask-dialog before opening modification
                    $scope.askForModification = function () {
                        $scope.askForModificationModal = {
                            isOpen: true,
                            contract: $scope.contract,
                            callback: function (activateDate) {
                                self.createModification(activateDate);
                            }
                        };
                    };

                    // Opens contract edit selection
                    $scope.openContractEditSelection = function () {
                        $scope.contractEditSelectionModal = {
                            isOpen: true,
                            isTemplate: $scope.isTemplate,
                            canCreateReassessment: $scope.canCreateReassessment,
                            canCreateModification: $scope.canCreateModification,
                            askForReassessment: $scope.askForReassessment,
                            askForModification: $scope.askForModification,
                            makeCurrentRevisionEditable: $scope.makeCurrentRevisionEditable
                        };
                    };

                    $scope.askForCompleteContract = function () {
                        $scope.askForFinalizeContractModal = {
                            isOpen: true,
                            activateDate: $scope.contract.CurrentContractRevision.ActivateDate,
                            callback: function () {
                                var loadingId = messageFactory.loadingMessage.show("LOADING_CHANGE_STATE");
                                self.setNewState("Completed", {
                                    callback: function () {
                                        messageFactory.showSuccessMessage("MESSAGE_CONTRACT_SAVED");
                                    },
                                    finalCallback: function () {
                                        messageFactory.loadingMessage.hide(loadingId);
                                    }
                                });
                            }
                        };
                    };

                    $scope.askForTerminateContract = function () {
                        $scope.askForFinalizeContractModal = {
                            isOpen: true,
                            askForTerminated: true,
                            activateDate: $scope.contract.CurrentContractRevision.ActivateDate,
                            callback: function (retirementDate) {
                                var loadingId = messageFactory.loadingMessage.show("LOADING_CHANGE_STATE");
                                self.setNewState("Terminated", {
                                    retirementDate: retirementDate,
                                    callback: function () {
                                        messageFactory.showSuccessMessage("MESSAGE_CONTRACT_SAVED");
                                    },
                                    finalCallback: function () {
                                        messageFactory.loadingMessage.hide(loadingId);
                                    }
                                });
                            }
                        };
                    };

                    // Ask-dialog before discarding reassessment
                    $scope.askForDiscard = function () {
                        self.prompt($scope.discardRessessment, {
                            messageText: "PROMPT_REASSESSMENT_DISCARD"
                        });
                    };

                    $scope.openClassifyTypeOfLeaseModal = function () {
                        $scope.classifyTypeOfLeaseModal = {
                            isOpen: true,
                            contract: $scope.contract,
                            callback: function (result) {
                                if (!$scope.isFormReadonly() && result != "") {
                                    resourceFactory.permittedValue("LeasingType", result).getByEnumType().$promise.then(function (resp) {
                                        if (resp.value.length > 0) {
                                            $scope.accountingStandard.usGaap = resp.value.pop();
                                        }
                                    });
                                }
                            }
                        };
                    };
                }

                /*#region Additional payments*/ {
                    $scope.openAssetPaymentRuleModal = function (paymentRuleToEdit) {
                        $scope.assetPaymentRuleModal = {
                            isOpen: true,
                            paymentRule: paymentRuleToEdit,
                            onlyOneTimePayments: true,
                            contract: $scope.contract,
                            callback: function (paymentRule, isEdit) {
                                var rou = $scope.contract.DisplayedContractRevision.RightOfUseAsset;
                                if (isEdit) {
                                    // Replace
                                    for (var f in rou.RightOfUseAssetPaymentRules) {
                                        if (rou.RightOfUseAssetPaymentRules[f].Id == paymentRule.Id) {
                                            rou.RightOfUseAssetPaymentRules[f] = paymentRule;
                                        }
                                    }
                                }
                                else {
                                    // Add
                                    rou.RightOfUseAssetPaymentRules = rou.RightOfUseAssetPaymentRules || [];
                                    rou.RightOfUseAssetPaymentRules.push(paymentRule);
                                }
                            }
                        };
                    };

                    // Removes a paymentrule from given leasingperiod
                    $scope.removeAssetPaymentRuleByIndex = function (paymentRuleIndex) {
                        $scope.contract.DisplayedContractRevision.RightOfUseAsset.RightOfUseAssetPaymentRules.splice(paymentRuleIndex, 1);
                    };
                }

                /*#region Assets and AssetComponents*/ {
                    $scope.openAssetModal = function (assetToEdit) {
                        $scope.assetModalConfig = {
                            isOpen: true,
                            asset: assetToEdit,
                            contract: $scope.contract,
                            callback: function (asset, isEdit) {
                                var rou = $scope.contract.DisplayedContractRevision.RightOfUseAsset;
                                if (isEdit) {
                                    // Replace
                                    for (var f in rou.Assets) {
                                        if (rou.Assets[f].Id == asset.Id) {
                                            rou.Assets[f] = asset;
                                        }
                                    }
                                }
                                else {
                                    // Add
                                    rou.Assets = rou.Assets || [];
                                    rou.Assets.push(asset);
                                }
                            }
                        };
                    };

                    // Removes an asset
                    $scope.removeAssetByIndex = function (index) {
                        $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets.splice(index, 1);
                    };

                    $scope.openAssetComponentModal = function (asset, assetComponentToEdit) {
                        $scope.assetComponentModalConfig = {
                            isOpen: true,
                            assetComponent: assetComponentToEdit,
                            contract: $scope.contract,
                            callback: function (assetComponent, isEdit) {
                                var rou = $scope.contract.DisplayedContractRevision.RightOfUseAsset;
                                if (isEdit) {
                                    // Replace
                                    for (var f in asset.AssetComponents) {
                                        if (asset.AssetComponents[f].Id == assetComponent.Id) {
                                            asset.AssetComponents[f] = assetComponent;
                                        }
                                    }
                                }
                                else {
                                    // Add
                                    assetComponent.ContractComponentId = helpers.randomId();

                                    asset.AssetComponents = asset.AssetComponents || [];
                                    asset.AssetComponents.push(assetComponent);
                                }
                            }
                        };
                    };

                    // Removes an asset component from given asset
                    $scope.removeAssetComponentByIndex = function (asset, index) {
                        asset.AssetComponents.splice(index, 1);
                    };

                    $scope.isSumOfAssetShares100Percent = function () {
                        if ($scope.contract == null) return false;
                        if ($scope.contract.DisplayedContractRevision == null) return false;
                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset == null) return false;
                        if ($scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets == null) return false;

                        var sum = 0;
                        for (var f in $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets) {
                            var asset = $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets[f];

                            for (var g in asset.AssetComponents) {
                                var assetComponent = asset.AssetComponents[g];
                                sum += helpers.getNumericValue(assetComponent.AssetShare);
                            }
                        }

                        return sum == 100;
                    };
                }

                /*#region Purchase options*/ {
                    // Opens the modal for adding/creating purchase options
                    $scope.openPurchaseOptionModal = function (purchaseOptionToEdit) {
                        var isEdit = purchaseOptionToEdit != null;
                        var title = isEdit ? "MODAL_REVISION_PURCHASE_OPTION_TITLE_EDIT" : "MODAL_REVISION_PURCHASE_OPTION_TITLE_ADD";

                        var callback = function ($scope) {
                            if ($scope.hasModalErrors($scope.purchaseOption)) return false;

                            var stat = $scope.purchaseOption.IsExpectedExecuted;
                            if (stat) {
                                for (var f in $scope.contract.DisplayedContractRevision.PurchaseOptions) {
                                    $scope.contract.DisplayedContractRevision.PurchaseOptions[f].IsExpectedExecuted = false;
                                }
                                $scope.purchaseOption.IsExpectedExecuted = stat;
                            }

                            if (isEdit) {
                                // Replace
                                for (var f in $scope.contract.DisplayedContractRevision.PurchaseOptions) {
                                    if ($scope.contract.DisplayedContractRevision.PurchaseOptions[f].Id === $scope.purchaseOption.Id) {
                                        $scope.contract.DisplayedContractRevision.PurchaseOptions[f] = $scope.purchaseOption;
                                    }
                                }
                            }
                            else {
                                if ($scope.contract.DisplayedContractRevision.PurchaseOptions == null) {
                                    $scope.contract.DisplayedContractRevision.PurchaseOptions = [];
                                }

                                // Add
                                $scope.contract.DisplayedContractRevision.PurchaseOptions.push($scope.purchaseOption);

                            }
                        };

                        var purchaseOption = {
                            Id: -helpers.randomId()
                        };

                        if (isEdit) {
                            purchaseOption.Id = purchaseOptionToEdit.Id;
                            purchaseOption.IsExpectedExecuted = purchaseOptionToEdit.IsExpectedExecuted;
                            purchaseOption.PurchaseOptionValue = purchaseOptionToEdit.PurchaseOptionValue;
                            purchaseOption.PurchaseOptionDate = purchaseOptionToEdit.PurchaseOptionDate;
                            purchaseOption.CreatedDate = purchaseOptionToEdit.CreatedDate;
                            purchaseOption.CreatedBy = purchaseOptionToEdit.CreatedBy;
                            purchaseOption.RowVersion = purchaseOptionToEdit.RowVersion;
                            purchaseOption.ChangedDate = purchaseOptionToEdit.ChangedDate;
                        }

                        var config = {
                            messageText: title,
                            okButtonText: isEdit ? "BUTTON_EDIT" : "BUTTON_ADD",
                            size: "md",
                            templateUrl: "purchaseOptionModal",
                            overriddenScope: {
                                contract: $scope.contract,
                                isAutoDescriptionEnabled: !isEdit,
                                purchaseOption: purchaseOption,

                                hasModalErrors: function (purchaseOption) {
                                    return !purchaseOptionValidator.validate(purchaseOption).isValid;
                                }
                            }
                        };

                        self.prompt(callback, config);
                    };

                    $scope.removePurchaseOption = function (purchaseOption) {
                        var index = $scope.contract.DisplayedContractRevision.PurchaseOptions.indexOf(purchaseOption);
                        $scope.contract.DisplayedContractRevision.PurchaseOptions.splice(index, 1);
                    };
                }
            }

            /*#region Private methods*/ {
                // Opens a prompt asking whether to execute an action or not
                // okCallback will be called after pressing the OK button.
                // If okCallback returns false, the modal will not be closed
                self.prompt = function (okCallback, config) {
                    if (typeof (config) != "object") {
                        config = {
                        };
                    }
                    var modalConfig = {};
                    modalConfig.templateUrl = "promptModal";

                    for (var f in config) {
                        modalConfig[f] = config[f];
                    }

                    promptFactory(okCallback, $scope, modalConfig);

                };

                self.initializeComment = function () {
                    for (var comment in $scope.contract.DisplayedContractRevision.Comments) {
                        if ($scope.contract.DisplayedContractRevision.Comments[comment].CommentType.Value == "General") {
                            $scope.generalCommentIndex = comment;
                        } else if ($scope.contract.DisplayedContractRevision.Comments[comment].CommentType.Value == "Termination") {
                            $scope.terminateCommentIndex = comment;
                        } else if ($scope.contract.DisplayedContractRevision.Comments[comment].CommentType.Value == "IndexBinding") {
                            $scope.indexBindingCommentIndex = comment;
                        } else if ($scope.contract.DisplayedContractRevision.Comments[comment].CommentType.Value == "Adjustments") {
                            $scope.adjustmentCommentIndex = comment;
                        }
                    }
                };

                self.initializeViewsId = function () {
                    if ($scope.contract.DisplayedContractRevision.ExtensionLeasingPeriods) {
                        for (var period in $scope.contract.DisplayedContractRevision.ExtensionLeasingPeriods) {
                            $scope.contract.DisplayedContractRevision.ExtensionLeasingPeriods[period].ViewModelNewId =
                                $scope.contract.DisplayedContractRevision.ExtensionLeasingPeriods[period].Id;
                        }
                    }
                };

                // Prepares the accountingstandards for the frontend by a given contract
                self.initializeAccountingStandards = function (contract) {
                    $scope.accountingStandard = {
                        ifrs: {
                            Id: -1
                        },
                        usGaap: {
                            Id: -1
                        },
                    };

                    if (contract != null && contract.CurrentContractRevision.AccountingStandards != null) {
                        for (var f in contract.CurrentContractRevision.AccountingStandards) {
                            var accountingStandard = contract.CurrentContractRevision.AccountingStandards[f];

                            switch (accountingStandard.AccountingStandardType.Value) {
                                case "IFRS":
                                    if (!accountingStandard.IsActive) $scope.accountingStandard.ifrs.Id = -1;
                                    else $scope.accountingStandard.ifrs = accountingStandard.LeasingType;
                                    break;
                                case "USGAAP":
                                    if (!accountingStandard.IsActive) $scope.accountingStandard.usGaap.Id = -1;
                                    else $scope.accountingStandard.usGaap = accountingStandard.LeasingType;
                                    break;
                            }
                        }
                    }
                };

                // Sets some properties that are required by the backend model
                self.addRequiredAccountingStandardsToBackendModel = function (contract) {
                    for (var f in contract.CurrentContractRevision.AccountingStandards) {
                        var accountingStandard = contract.CurrentContractRevision.AccountingStandards[f];
                        switch (accountingStandard.AccountingStandardType.Value) {
                            case "IFRS":
                                var isActive = $scope.accountingStandard.ifrs.Id != -1;
                                var leasingTypeId = isActive ? $scope.accountingStandard.ifrs.Id : 60;
                                var leasingTypeValue = isActive ? $scope.accountingStandard.ifrs.Value : "Finance";

                                accountingStandard.IsActive = isActive;
                                accountingStandard.LeasingType = {
                                    Id: leasingTypeId,
                                    EnumType: "LeasingType",
                                    Value: leasingTypeValue
                                };
                                break;
                            case "USGAAP":
                                var isActive = $scope.accountingStandard.usGaap.Id != -1;
                                var leasingTypeId = isActive ? $scope.accountingStandard.usGaap.Id : 60;
                                var leasingTypeValue = isActive ? $scope.accountingStandard.usGaap.Value : "Finance";

                                accountingStandard.IsActive = isActive;
                                accountingStandard.LeasingType = {
                                    Id: leasingTypeId,
                                    EnumType: "LeasingType",
                                    Value: leasingTypeValue
                                };
                                break;
                        }
                    }
                };

                // Initializes all form elements
                self.initializePage = function () {
                    self.initializeTabs();
                    self.initializeWatchers();
                    self.initializeDropDowns();
                    self.initializeButtons();
                };

                // Configures the tabs
                self.initializeTabs = function () {
                    if ($scope.templateBaseId != null)
                        return;
                    $scope.tabs = [
                        {
                            // Translation key
                            title: 'TAB_HEADER_COMMON',
                            // Template URL
                            template: '/app/views/contract/contractTabs/baseData.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_REVISION',
                            template: '/app/views/contract/contractTabs/moreOptions.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_LEASING_PERIODS',
                            showIf: function () {
                                return $scope.contract != null && $scope.contract.IsLimited;
                            },
                            template: '/app/views/contract/contractTabs/leasingPeriods.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_CONTRACT_LEASING_PERIOD',
                            showIf: function () {
                                return $scope.contract != null && !$scope.contract.IsLimited;
                            },
                            template: '/app/views/contract/contractTabs/leasingPeriods.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_ASSETS',
                            showIf: function () {
                                return $scope.isLessee();
                            },
                            template: '/app/views/contract/contractTabs/assets.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_LIABILITY_OVERVIEW',
                            template: '/app/views/contract/contractTabs/calculation.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_COMMENT',
                            template: '/app/views/contract/contractTabs/comment.html?cache=' + globalConfig.htmlCacheToken
                        },
                        {
                            title: 'TAB_HEADER_PREVIEW',
                            template: '/app/views/contract/contractTabs/printPreview.html?cache=' + globalConfig.htmlCacheToken,
                            showIf: function () {
                                return !$scope.isNewContract() && globalConfig.showPrintableContractTab === true;
                            },
                        }
                    ];
                };

                // Configures some watches (e.g. for keep some inputs synchronous)
                self.initializeWatchers = function () {
                    $scope.$watch('contract.ContractType', function (newValue, oldValue) {
                        var oldContractType = oldValue != null ? oldValue.Value : oldValue;
                        var newContractType = newValue != null ? newValue.Value : newValue;

                        // Change from Lessee to Lessor
                        if (oldContractType == "Lessee" && newContractType != "Lessee") {
                            var config = {
                                messageText: "PROMPT_SET_LESSOR",
                                cancelCallback: function () {
                                    if ($scope.contract.ContractType.Value == "Lessee") {
                                        $scope.contract.ContractType = {
                                            Id: 0,
                                            Value: "Lessor"
                                        };
                                    } else
                                        $scope.contract.ContractType = {
                                            Id: 0,
                                            Value: "Lessee"
                                        };
                                }
                            };

                            self.prompt(function () {
                                $scope.contract.DisplayedContractRevision.RightOfUseAsset = null;
                            }, config);
                        }

                        // Change from nothing to Lessor
                        if (oldContractType == null && newContractType == "Lessor") {
                            $scope.contract.DisplayedContractRevision.RightOfUseAsset = null;
                        }

                        // Change from Lessor to Lessee
                        if (oldContractType != "Lessee" && newContractType == "Lessee") {
                            if ($scope.contract.DisplayedContractRevision.RightOfUseAsset == null  /*|| $scope.contract.DisplayedContractRevision.RightOfUseAsset.Id < 0*/) {
                                $scope.contract.DisplayedContractRevision.RightOfUseAsset = {
                                    Id: -1,
                                    ContractRevision: $scope.contract.DisplayedContractRevision
                                };
                            }
                        }
                    });

                    $scope.$watch('contract.IsLimited', function (newIsLimited, oldIsLimited) {
                        if (oldIsLimited == null) return;

                        if (oldIsLimited && !newIsLimited) {
                            var config = {
                                messageText: "PROMPT_SET_UNLIMITED",
                                cancelCallback: function () {
                                    $scope.contract.IsLimited = true;
                                }
                            };

                            self.prompt(function () {
                                $scope.contract.DisplayedContractRevision.ExtensionLeasingPeriods = [];
                                $scope.contract.DisplayedContractRevision.ContractLeasingPeriod.Duration = null;
                                $scope.contract.DisplayedContractRevision.ContractLeasingPeriod.EndDate = null;
                            }, config);
                        }
                    });

                    // If a company is chosen and currency input is empty, then currency will be filled with companies default currency
                    $scope.$watch('contract.Company', function (newValue, oldValue) {
                        if (oldValue != newValue && $scope.contract != null) {
                            if ($scope.contract.DisplayedContractRevision.RightOfUseAsset != null) {
                                if ($scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets != null && $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets.length > 0) {
                                    for (var f in $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets) {
                                        var asset = $scope.contract.DisplayedContractRevision.RightOfUseAsset.Assets[f];

                                        for (var g in asset.AssetComponents) {
                                            var assetComponent = asset.AssetComponents[g];
                                            if (assetComponent.AssetClass != null && (assetComponent.AssetClass.Company_Id != null && assetComponent.AssetClass.Company_Id != $scope.contract.Company.Id)) {
                                                assetComponent.AssetClass = null;
                                            }
                                        }
                                    }
                                }
                                else if (globalConfig.hasSingleAssetComponent) {
                                    self.setDefaultAssetComponent();
                                }
                            }
                        }

                        if ($scope.contract == null || $scope.contract.Company == null) return;

                        if ($scope.contract.Company.DefaultCurrency != null && !$scope.contract.Company.DefaultCurrency.IsDeleted && $scope.contract.Currency == null) {
                            $scope.contract.Currency = $scope.contract.Company.DefaultCurrency;
                            $scope._onCurrencyChange();
                        }
                    });
                };

                self.initializePartnerDropDown = function() {
                    var partnerDataSource = kendoDataSourceBuilder("/odata/Partner").withoutDeleted();
                    if ($scope.contract != null && $scope.contract.Partner != null) {
                        partnerDataSource = partnerDataSource.orHasId($scope.contract.Partner.Id);
                    }
                    $scope.partnerDataSource = partnerDataSource;
                }

                self.initializeReport = function (id) {

                    if (globalConfig.showPrintableContractTab === false) {
                        return;
                    }

                    if (reportHandler == null) {
                        var reportConfig = {
                            ScaleMode: telerikReportViewer.ScaleModes.FIT_PAGE_WIDTH
                        };
                        reportHandler = kendoReportFactory("printableContractReport",
                            "BDO.Lead.Shared.Services.Reports.ContractReport.ContractReport, BDO.Lead.Shared.Services", reportConfig);
                    }

                    reportHandler.refresh({ ReportId: id });
                }

                // Create the datasources for all dropdowns
                self.initializeDropDowns = function () {
                    var contractTypeDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                        .whereEquals("EnumType", "ContractType");

                    var currencyDataSource = kendoDataSourceBuilder("/odata/Currency").withoutDeleted()
                    if ($scope.contract != null && $scope.contract.Currency != null) {
                        currencyDataSource = currencyDataSource.orHasId($scope.contract.Currency.Id);
                    }

                    self.initializePartnerDropDown();
                    
                    var companyDataSource = kendoDataSourceBuilder("/odata/UserCompanies?$expand=Company($expand=DefaultCurrency,AssetClasses)&$select=Company", {
                        onParse: function (data) {
                            var dataAsCompanyList = [];
                            for (var f in data.value) {
                                var item = data.value[f];
                                dataAsCompanyList.push(item.Company);
                            }

                            data.value = dataAsCompanyList;

                            return data;
                        }
                    });
                    companyDataSource = companyDataSource
                        .whereEquals("Company/IsDeleted", false)
                        .whereEquals("Company/IsActive", true);
                    if ($scope.contract != null && $scope.contract.Company != null) {
                        companyDataSource = companyDataSource.whereEquals("Company/Id", $scope.contract.Company.Id);
                    }
                    companyDataSource = companyDataSource
                        .withoutDeleted()
                        .whereEquals("CanModify", true)
                        .whereEquals("User/Id", $rootScope.currentUser.Id);

                    var accountingStandardUsGaapDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                        .whereEquals("EnumType", "LeasingType")
                        .addValue({
                            Id: -1,
                            EnumType: "LeasingType",
                            Value: "DEACTIVATED"
                        });

                    var accountingStandardIfrsDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                        .whereEquals("EnumType", "LeasingType")
                        .whereNotEquals("Value", "Operate")
                        .addValue({
                            Id: -1,
                            EnumType: "LeasingType",
                            Value: "DEACTIVATED"
                        });

                    $scope.contractTypeDataSource = contractTypeDataSource;
                    $scope.currencyDataSource = currencyDataSource;
                    $scope.companyDataSource = companyDataSource;

                    $scope.accountingStandardUsGaapDataSource = accountingStandardUsGaapDataSource;
                    $scope.accountingStandardIfrsDataSource = accountingStandardIfrsDataSource;
                };

                self.initializeButtons = function () {
                    $scope.showAddPartnerBox = true;
                    $scope.togglePartnerSelectOrAdd();
                    $scope.NewPartnerName = "";
                };

                self.loadNewContract = function () {
                    var loadingId = messageFactory.loadingMessage.show("LOADING_CONTRACT_NEW");

                    resourceFactory
                            .emptyEntity(isTemplate ? "ContractTemplate" : "Contract", $scope.templateBaseId)
                            .getById()
                            .$promise
                            .then(function (resp) {
                                retrocycle(resp.Payload);
                                $scope.contract = resp.Payload;
                                $scope.contract.DisplayedContractRevision = $scope.contract.CurrentContractRevision;

                                self.initializeComment();
                                self.initializeAccountingStandards($scope.contract);
                                self.initializeDropDowns();
                            })
                            .catch(function (e) {
                                console.error(e);

                                if (isTemplate) {
                                    location.href = "#!/contract/templates";
                                }
                                else {
                                    location.href = "#!/contract";
                                }
                            })
                            .finally(function () {
                                messageFactory.loadingMessage.hide(loadingId);
                            });
                };

                // Loads a contract by a given contractId
                self.loadContractById = function (contractId) {
                    $scope.companyId *= 1;
                    var loadingId = messageFactory.loadingMessage.show(isTemplate ? "LOADING_CONTRACT_TEMPLATE" : "LOADING_CONTRACT");

                    resourceFactory
                        .contract(contractId)
                        .getById()
                        .$promise
                        .then(function (resp) {
                            retrocycle(resp.Payload);
                            $scope.contract = resp.Payload;
                            $scope.contract.DisplayedContractRevision = $scope.contract.CurrentContractRevision;

                            $scope.selectedContractRevision = { Id: $scope.contract.DisplayedContractRevision.Id };
                            $scope.contractRevisions[$scope.contract.DisplayedContractRevision.Id] = $scope.contract.DisplayedContractRevision;

                            $scope._onCurrencyChange();

                            self.initializeComment();
                            self.initializeViewsId();
                            self.initializeAccountingStandards($scope.contract);

                            isFormReadonly = !$scope.isPending() || $scope.isDeleted() || !$scope.canModify();

                            self.initializeDropDowns();
                            self.initializeReport(contractId);
                        })
                        .catch(function (e) {
                            console.error(e);

                            if (isTemplate) {
                                location.href = "#!/contract/templates";
                            } else {
                                location.href = "#!/contract";
                            }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                };

                // Sets the title for the contract view
                self.setTitle = function (isTemplate, isNew) {
                    if (isTemplate) {
                        if (isNew) {
                            pageFactory.setTitle("TITLE_NEW_TEMPLATE", "/contract/templates");
                        }
                        else {
                            pageFactory.setTitle("TITLE_CONTRACT_TEMPLATE_DETAILS", "/contract/templates");
                        }
                    }
                    else {
                        if (isNew) {
                            pageFactory.setTitle("TITLE_NEW_CONTRACT", "/contract/contracts");
                        }
                        else {
                            pageFactory.setTitle("TITLE_CONTRACT_DETAILS", "/contract/contracts");
                        }
                    }
                };

                self.createReassessment = function (activateDate) {
                    var loadingId = messageFactory.loadingMessage.show("LOADING_CREATE_NEW_REVISION");

                    self.setNewState("Pending", {
                        activateDate: activateDate,
                        createNewContractRevisionForReassessment: true,
                        callback: function () {
                            messageFactory.showSuccessMessage("MESSAGE_CREATED_NEW_REVISION");
                        },
                        finalCallback: function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        }
                    });
                };

                self.createModification = function (activateDate) {
                    var loadingId = messageFactory.loadingMessage.show("LOADING_CREATE_NEW_MODIFICATION");

                    self.setNewState("Pending", {
                        activateDate: activateDate,
                        createNewContractRevisionForModification: true,
                        callback: function () {
                            messageFactory.showSuccessMessage("MESSAGE_CREATED_NEW_REVISION");
                        },
                        finalCallback: function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        }
                    });
                };

                self.setValidated = function () {
                    self.save(function () {
                        var validatingLoadingId = messageFactory.loadingMessage.show("LOADING_VALIDATING_CONTRACT");

                        self.setNewState("Validated", {
                            callback: function () {
                                messageFactory.showSuccessMessage("MESSAGE_VALIDATED_CONTRACT");
                            },
                            finalCallback: function () {
                                messageFactory.loadingMessage.hide(validatingLoadingId);
                            }
                        });
                    });
                };

                self.setNewState = function (newContractrevisionState, config) {
                    config = config || {};
                    config.createNewContractRevisionForReassessment = config.createNewContractRevisionForReassessment || false;
                    config.createNewContractRevisionForModification = config.createNewContractRevisionForModification || false;

                    var successCallback = function (resp) {
                        $route.reload();

                        if (typeof (config.callback) == "function") {
                            config.callback(resp);
                        }
                    };

                    resourceFactory
                        .contractRevisionState($scope.contract.Id)
                        .changeState({
                            activateDate: config.activateDate,
                            retirementDate: config.retirementDate,
                            newContractrevisionState: newContractrevisionState,
                            createNewContractRevisionForReassessment: config.createNewContractRevisionForReassessment,
                            createNewContractRevisionForModification: config.createNewContractRevisionForModification
                        })
                        .$promise
                        .then(successCallback)
                        .catch(function (e) {
                            console.error(e);

                            $scope.resourceErrors = {
                                list: e.data.ValidationErrors
                            }
                        })
                        .finally(config.finalCallback);
                };

                // Saves the contract
                self.save = function (successCallback) {
                    if ($scope.hasFormErrors()) return;
                    var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_CONTRACT");

                    if ($scope.showAddPartnerBox && $scope.contract.Partner != null && $scope.contract.Partner.CompanyName != null && $scope.contract.Partner.CompanyName != "") {
                        $scope.contract.Partner.Id = -999;
                    }

                    if ($scope.contract.DisplayedContractRevision.UseInterestRate) {
                        $scope.contract.DisplayedContractRevision.IncrementalBorrowingRate = 0;
                    }
                    else {
                        $scope.contract.DisplayedContractRevision.InterestRate = 0;
                    }

                    if (($scope.contract.DisplayedContractRevision.ResidualValue || 0) <=0) {
                        $scope.contract.DisplayedContractRevision.ResidualDate = null;
                    }

                    var removeDeleted = function (obj) {
                        if (obj.IsDeleted) {
                            return false;
                        }
                        return true;
                    }

                    var requestCallback = function (resp) {
                        retrocycle(resp.Payload);
                        $scope.contract = resp.Payload;
                        $scope.contract.DisplayedContractRevision = $scope.contract.CurrentContractRevision;

                        $scope.selectedContractRevision = { Id: $scope.contract.DisplayedContractRevision.Id };
                        $scope.contractRevisions[$scope.contract.DisplayedContractRevision.Id] = $scope.contract.DisplayedContractRevision;

                        self.initializeAccountingStandards($scope.contract);

                        messageFactory.showSuccessMessage("MESSAGE_CONTRACT_SAVED");

                        $scope.resourceErrors = {
                        };

                        if (typeof (successCallback) == "function") {
                            successCallback(resp);
                        }

                        if ($scope.showAddPartnerBox) {
                            $scope.showAddPartnerBox = false;
                            self.initializePartnerDropDown();// reload dropdowns (because of new partner)
                        }
                    };

                    self.addRequiredAccountingStandardsToBackendModel($scope.contract);

                    var decycledContract = decycle($scope.contract);

                    if ($scope.isNewContract()) {
                        resourceFactory
                                .contract($scope.contract.Id)
                                .create(decycledContract)
                                .$promise
                                .then(requestCallback)
                                .catch(function (e) {
                                    console.error(e);

                                    $scope.resourceErrors = {
                                        list: e.data.ValidationErrors
                                    }
                                })
                                .finally(function () {
                                    messageFactory.loadingMessage.hide(loadingId);
                                });
                    }
                    else {
                        resourceFactory
                                .contract($scope.contract.Id)
                                .update(decycledContract)
                                .$promise
                                .then(requestCallback)
                                .catch(function (e) {
                                    console.error(e);

                                    $scope.resourceErrors = {
                                        list: e.data.ValidationErrors
                                    }
                                })
                                .finally(function () {
                                    messageFactory.loadingMessage.hide(loadingId);
                                });
                    }

                    
                };
            }

            constructor();
        }
    ]);