﻿"use strict";

angular
    .module("LeadApp")
    .controller("LedgerAssociationController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "ledgerAssociationValidator", "kendoDataSourceBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, ledgerAssociationValidator, kendoDataSourceBuilder) {
            pageFactory.setTitle("TITLE_LEDGERASSOCIATION_DETAILS", "/configuration/ledgerAssociation/all");
            var vm = this;
            $scope.ledgerAssociationId = $routeParams.ledgerAssociationId;
            $scope.isNew = $scope.ledgerAssociationId == null || $scope.ledgerAssociationId == "undefined" || $scope.ledgerAssociationId.trim().length == 0;
            $scope.hasError = false;

            vm.ledgerDataSource = kendoDataSourceBuilder("/odata/Ledger").withoutDeleted();
            vm.ledgerTypeDataSource = kendoDataSourceBuilder("/odata/LedgerType").withoutDeleted();
            vm.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();
            vm.assetClassDataSource = kendoDataSourceBuilder("/odata/AssetClass").withoutDeleted();
                
            $scope.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };

            if ($scope.isNew) {
                vm.ledgerAssociation = {
                    Id: -1
                };
            }
            else {
                $scope.ledgerAssociationId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_LEDGERASSOCIATION");
                resourceFactory
                    .ledgerAssociation($scope.ledgerAssociationId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.ledgerAssociation = resp.Payload;

                        pageFactory.setTitle(resp.Payload.Name, "/configuration/ledgerAssociation/" + (vm.ledgerAssociation.IsDeleted ? keywords.ARCHIVE : ""));
                    })
                    .catch(function () {
                        location.href = "#!/configuration/ledgerAssociation";
                    })
                    .finally(function () {
                        messageFactory.loadingMessage.hide(loadingId);
                    });
            }

            $scope.save = function () {
                if (!$scope.validate()) {
                    return;
                }
                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_LEDGERASSOCIATION");
                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_LEDGERASSOCIATION_SAVED");
                    location.href = "#!/configuration/ledgerAssociation";
                };

                if ($scope.isNew) {
                    resourceFactory
                        .ledgerAssociation()
                        .create(vm.ledgerAssociation)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) {
                            $scope.resourceErrors = { list: resp.data.ValidationErrors }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                }
                else {
                    resourceFactory
                        .ledgerAssociation($scope.ledgerAssociationId)
                        .update(vm.ledgerAssociation)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { $scope.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });

                }
            };

            vm.isFormReadonly = function () {
                if (vm.ledgerAssociation === null) return true;
                return vm.ledgerAssociation.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };

            $scope.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_LEDGERASSOCIATION");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_LEDGERASSOCIATION_REMOVED");
                    location.href = "#!/configuration/ledgerAssociation";
                };
                resourceFactory
                    .ledgerAssociation($scope.ledgerAssociationId)
                    .remove(vm.ledgerAssociation)
                    .$promise
                    .then(successCallback)
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            $scope.validate = function () {
                if (vm.ledgerAssociation === null) {
                    $scope.doesFormHaveErrors = true;
                } else {
                    $scope.doesFormHaveErrors = false;
                    $scope.doesFormHaveErrors |= !ledgerAssociationValidator.validate(vm.ledgerAssociation).isValid;
                }
                return !$scope.doesFormHaveErrors;
            };

            $scope.$watch('vm.ledgerAssociation', function (newValue, oldValue) {
                $scope.validate();
            }, true);

        }
    ]);