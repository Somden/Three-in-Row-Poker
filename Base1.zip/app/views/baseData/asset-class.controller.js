﻿"use strict";

angular
    .module("LeadApp")
    .controller("AssetClassController", [
        "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "assetClassValidator", "kendoDataSourceBuilder",
        function ($rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, assetClassValidator, kendoDataSourceBuilder) {
            pageFactory.setTitle("TITLE_ASSETCLASS_DETAILS", "/configuration/assetClass/all");

            var vm = this;
            vm.assetClassId = $routeParams.assetClassId;
            vm.isNew = vm.assetClassId == null || vm.assetClassId == "undefined" || vm.assetClassId.toString().trim().length == 0;


            vm.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };

            if (vm.isNew) {
                vm.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();
                vm.assetClass = {
                    Id: -1,
                    IsActive: true
                };
            }
            else {
                vm.assetClassId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_ASSETCLASS");

                resourceFactory
                    .assetClass(vm.assetClassId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.assetClass = resp.Payload;

                        retrocycle(vm.assetClass);

                        if (vm.assetClass.Company != null) {
                           vm.companyDataSource = kendoDataSourceBuilder("/odata/Company")
                                .withoutDeleted()
                                .orHasId(vm.assetClass.Company.Id);
                        } else {
                            vm.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();
                        }

                        pageFactory.setTitle(resp.Payload.Name, "/configuration/assetClass/" + (vm.assetClass.IsDeleted ? keywords.ARCHIVE : ""));
                    })
                    .catch(function (e) {
                        console.error(e);
                        location.href = "#!/configuration/assetClass";
                    })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            }

            vm.save = function () {
                // debugger;
                if (!vm.validate()) {
                    return;
                }

                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_ASSETCLASS");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_ASSETCLASS_SAVED");
                    location.href = "#!/configuration/assetClass";
                };

                var decycledAssetClass = decycle(vm.assetClass);
                if (vm.isNew) {
                    resourceFactory
                        .assetClass()
                        .create(decycledAssetClass)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
                else {
                    resourceFactory
                        .assetClass(vm.assetClassId)
                        .update(decycledAssetClass)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
            };

            vm.isFormReadonly = function () {
                if (vm.assetClass == null) return true;

                return vm.assetClass.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };

            vm.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_ASSETCLASS");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_ASSETCLASS_REMOVED");
                    location.href = "#!/configuration/assetClass";
                };

                resourceFactory
                    .assetClass(vm.assetClassId)
                    .remove()
                    .$promise
                    .then(successCallback)
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            vm.validate = function () {
                var doesFormHaveErrors = false;
                if (vm.assetClass == null) {
                    doesFormHaveErrors = true;
                }
                else {
                    doesFormHaveErrors |= !assetClassValidator.validate(vm.assetClass).isValid;
                }

                return !doesFormHaveErrors;
            };
        }
    ]);