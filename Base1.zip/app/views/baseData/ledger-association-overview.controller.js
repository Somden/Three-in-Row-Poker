﻿"use strict";

angular
    .module("LeadApp")
    .controller("LedgerAssociationOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;

            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;

                vm.new = openPageForNewEntity;
                vm.toggleArchived = toggleArchived;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_BASEDATA_LEDGERASSOCIATIONS_ARCHIVED" : "ITEM_SUB_BASEDATA_LEDGERASSOCIATIONS");

                kendoGridBuilder(
                    "/odata/LedgerAssociation?$expand=Ledger%2CLedgerType%2CCompany%2CAssetClass",
                    "LedgerAssociation",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openPageForNewEntity() {
                location.href = "#!/configuration/ledgerAssociation/new";
            };

            function openEntity(entityId) {
                location.href = "#!/configuration/ledgerAssociation/" + entityId + "/edit";
            };

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/ledgerAssociation";
                }
                else {
                    location.href = "#!/configuration/ledgerAssociation/" + keywords.ARCHIVE;
                }
            };

            function canCreate() {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);