﻿"use strict";

angular
    .module("LeadApp")
    .controller("AssetClassOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;
            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;

                vm.new = openPageForNewEntity;
                vm.toggleArchived = toggleArchived;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_CONFIGURATION_ASSETCLASS_ARCHIVED" : "ITEM_SUB_CONFIGURATION_ASSETCLASS");

                kendoGridBuilder(
                    "/odata/AssetClass?$expand=Company",
                    "AssetClass",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openPageForNewEntity() {
                location.href = "#!/configuration/assetClass/new";
            };

            function openEntity(entityId) {
                location.href = "#!/configuration/assetClass/" + entityId + "/edit";
            };

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/assetClass";
                }
                else {
                    location.href = "#!/configuration/assetClass/" + keywords.ARCHIVE;
                }
            };

            function canCreate() {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);