﻿"use strict";

angular
    .module("LeadApp")
    .controller("PartnerController", [
        "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "partnerValidator",
        function ($rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, partnerValidator) {
            var vm = this;
            pageFactory.setTitle("TITLE_PARTNER_DETAILS", "/configuration/partner/all");

            vm.partnerId = $routeParams.partnerId;
            vm.isNew = vm.partnerId == null || vm.partnerId == "undefined" || vm.partnerId.trim().length == 0;

            vm.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };

            if (vm.isNew) {
                vm.partner = {
                    Id: -1,
                    IsActive: true,
                    IsAdmin: false,
                };
            }
            else {
                vm.partnerId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_PARTNER");
                resourceFactory
                    .partner(vm.partnerId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.partner = resp.Payload;

                        var title = (resp.Payload.Contact != null ? resp.Payload.Contact + " " : "") + resp.Payload.CompanyName;
                        var backUrl = "/configuration/partner/" + (vm.partner.IsDeleted ? keywords.ARCHIVE : "");
                        pageFactory.setTitle(title, backUrl);
                    })
                    .catch(function () { location.href = "#!/configuration/partner"; })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            }

            vm.partnerDataSource = {
                type: "odata-v4",
                serverFiltering: true,
                transport: {
                    read: {
                        url: "/odata/Partner"
                    }
                }
            };

            vm.save = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_PARTNER");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_PARTNER_SAVED");
                    location.href = "#!/configuration/partner";
                };

                if (vm.isNew) {
                    resourceFactory
                        .partner()
                        .create(vm.partner)
                        .$promise
                        .then(successCallback)
                            .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
                else {
                    resourceFactory
                        .partner(vm.partnerId)
                        .update(vm.partner)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
            };

            vm.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_PARTNER");

                resourceFactory
                    .partner(vm.partnerId)
                    .remove(vm.partner)
                    .$promise
                    .then(function () {
                        messageFactory.showSuccessMessage("MESSAGE_PARTNER_REMOVED");
                        location.href = "#!/configuration/partner";
                    })
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            vm.validate = function () {
                var doesFormHaveErrors = false;

                if (vm.partner == null) {
                    doesFormHaveErrors = true;
                }
                else {
                    doesFormHaveErrors = false;
                    doesFormHaveErrors |= !partnerValidator.validate(vm.partner).isValid;
                }

                return !doesFormHaveErrors;
            };

            vm.removeCompnay = function (partnerId) {
                removePartnerFromPermissions(partnerId);
            };

            vm.isFormReadonly = function () {
                if (vm.partner == null) return true;

                return vm.partner.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };
        }
    ]);