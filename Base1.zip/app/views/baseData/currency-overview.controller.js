﻿"use strict";

angular
    .module("LeadApp")
    .controller("CurrencyOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;

            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;

                vm.new = openPageForNewEntity;
                vm.toggleArchived = toggleArchived;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_BASEDATA_CURRENCIES_ARCHIVED" : "ITEM_SUB_BASEDATA_CURRENCIES");

                kendoGridBuilder(
                    "/odata/Currency",
                    "Currency",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openPageForNewEntity() {
                location.href = "#!/configuration/currency/new";
            };

            function openEntity(entityId) {
                location.href = "#!/configuration/currency/" + entityId + "/edit";
            };

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/currency";
                }
                else {
                    location.href = "#!/configuration/currency/" + keywords.ARCHIVE;
                }
            };

            function canCreate () {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);