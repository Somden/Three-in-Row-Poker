﻿"use strict";

angular
    .module("LeadApp")
    .controller("CurrencyController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "currencyValidator",
        function ($scope, $rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, currencyValidator) {
            pageFactory.setTitle("TITLE_CURRENCY_DETAILS", "/configuration/currency/all");
            var vm = this;
            $scope.currencyId = $routeParams.currencyId;
            $scope.isNew = $scope.currencyId == null || $scope.currencyId == "undefined" || $scope.currencyId.trim().length == 0;
            $scope.hasError = false;

            $scope.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };

            if ($scope.isNew) {
                vm.currency = {
                    Id: -1
                };
            }
            else {
                $scope.currencyId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_CURRENCY");
                resourceFactory
                    .currency($scope.currencyId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.currency = resp.Payload;

                        pageFactory.setTitle(resp.Payload.Name, "/configuration/currency/" + (vm.currency.IsDeleted ? keywords.ARCHIVE : ""));
                    })
                    .catch(function () {
                        location.href = "#!/configuration/currency";
                    })
                    .finally(function () {
                        messageFactory.loadingMessage.hide(loadingId);
                    });
            }

            $scope.save = function () {
                if (!$scope.validate()) {
                    return;
                }
                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_CURRENCY");
                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_CURRENCY_SAVED");
                    location.href = "#!/configuration/currency";
                };

                if ($scope.isNew) {
                    resourceFactory
                        .currency()
                        .create(vm.currency)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) {
                            $scope.resourceErrors = { list: resp.data.ValidationErrors }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                }
                else {
                    resourceFactory
                        .currency($scope.currencyId)
                        .update(vm.currency)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { $scope.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });

                }
            };
            vm.isFormReadonly = function () {
                if (vm.currency == null) return true;
                return vm.currency.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };
            $scope.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_CURRENCY");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_CURRENCY_REMOVED");
                    location.href = "#!/configuration/currency";
                };
                resourceFactory
                    .currency($scope.currencyId)
                    .remove(vm.currency)
                    .$promise
                    .then(successCallback)
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            $scope.validate = function () {
                if (vm.currency == null) {
                    $scope.doesFormHaveErrors = true;
                } else {
                    $scope.doesFormHaveErrors = false;
                    $scope.doesFormHaveErrors |= !currencyValidator.validate(vm.currency).isValid;
                }
                return !$scope.doesFormHaveErrors;
            };

            $scope.$watch('vm.currency', function (newValue, oldValue) {
                $scope.validate();
            }, true);
        }
    ]);