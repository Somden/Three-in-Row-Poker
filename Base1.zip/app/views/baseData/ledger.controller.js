﻿"use strict";

angular
    .module("LeadApp")
    .controller("LedgerController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "ledgerValidator", "kendoDataSourceBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, ledgerValidator, kendoDataSourceBuilder) {
            pageFactory.setTitle("TITLE_LEDGER_DETAILS", "/configuration/ledger/all");
            var vm = this;
            $scope.ledgerId = $routeParams.ledgerId;
            $scope.isNew = $scope.ledgerId == null || $scope.ledgerId == "undefined" || $scope.ledgerId.trim().length == 0;
            $scope.hasError = false;           

            $scope.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };

            if ($scope.isNew) {
                vm.ledger = {
                    Id: -1
                };
            }
            else {
                $scope.ledgerId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_LEDGER");
                resourceFactory
                    .ledger($scope.ledgerId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.ledger = resp.Payload;

                        pageFactory.setTitle(resp.Payload.Name, "/configuration/ledgers/" + (vm.ledger.IsDeleted ? keywords.ARCHIVE : ""));
                    })
                    .catch(function () {
                        location.href = "#!/configuration/ledgers";
                    })
                    .finally(function () {
                        messageFactory.loadingMessage.hide(loadingId);
                    });
            }

            $scope.save = function () {
                if (!$scope.validate()) {
                    return;
                }
                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_LEDGER");
                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_LEDGER_SAVED");
                    location.href = "#!/configuration/ledgers";
                };

                if ($scope.isNew) {
                    resourceFactory
                        .ledger()
                        .create(vm.ledger)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) {
                            $scope.resourceErrors = { list: resp.data.ValidationErrors }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                }
                else {
                    resourceFactory
                        .ledger($scope.ledgerId)
                        .update(vm.ledger)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { $scope.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });

                }
            };
            vm.isFormReadonly = function () {
                if (vm.ledger == null) return true;
                return vm.ledger.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };
            $scope.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_LEDGER");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_LEDGER_REMOVED");
                    location.href = "#!/configuration/ledgers";
                };
                resourceFactory
                    .ledger($scope.ledgerId)
                    .remove(vm.ledger)
                    .$promise
                    .then(successCallback)
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            $scope.validate = function () {
                if (vm.ledger == null) {
                    $scope.doesFormHaveErrors = true;
                } else {
                    $scope.doesFormHaveErrors = false;
                    $scope.doesFormHaveErrors |= !ledgerValidator.validate(vm.ledger).isValid;
                }
                return !$scope.doesFormHaveErrors;
            };

            $scope.$watch('vm.ledger', function (newValue, oldValue) {
                $scope.validate();
            }, true);
        }
    ]);