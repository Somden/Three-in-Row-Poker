﻿"use strict";

angular
    .module("LeadApp")
    .controller("PartnerOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;

            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;

                vm.new = openPageForNewEntity;
                vm.toggleArchived = toggleArchived;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_CONFIGURATION_PARTNERS_ARCHIVED" : "ITEM_SUB_CONFIGURATION_PARTNERS");

                kendoGridBuilder(
                    "/odata/Partner",
                    "Partner",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openPageForNewEntity() {
                location.href = "#!/configuration/partner/new";
            };

            function openEntity(entityId) {
                location.href = "#!/configuration/partner/" + entityId + "/edit";
            };

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/partner";
                }
                else {
                    location.href = "#!/configuration/partner/" + keywords.ARCHIVE;
                }
            };

            function canCreate () {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);