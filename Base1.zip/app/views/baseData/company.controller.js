﻿"use strict";

angular
    .module("LeadApp")
    .controller("CompanyController", [
        "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "companyValidator", "kendoDataSourceBuilder",
        function ($rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, companyValidator, kendoDataSourceBuilder) {
            pageFactory.setTitle("TITLE_COMPANY_DETAILS", "/configuration/company/all");

            var vm = this;
            vm.companyId = $routeParams.companyId;
            vm.isNew = vm.companyId == null || vm.companyId.trim().length == 0;
            vm.validator = companyValidator;

            vm.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };
            if (vm.isNew) {
                vm.companyId = -1;
                vm.company = {
                    Id: -1,
                    IsActive: true,
                    IsTemplate: false,
                    AssetClasses: []
                };
                vm.currencyDataSource = kendoDataSourceBuilder("/odata/Currency").withoutDeleted();
            }
            else {
                vm.companyId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_COMPANY");

                resourceFactory
                    .company(vm.companyId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.company = resp.Payload;
                        retrocycle(vm.company);

                        if (vm.company.DefaultCurrency != null) {
                         vm.currencyDataSource = kendoDataSourceBuilder("/odata/Currency", { pageSize: 10000 })
                                .withoutDeleted()
                                .orHasId(vm.company.DefaultCurrency.Id);
                        }

                        pageFactory.setTitle(resp.Payload.Name, "/configuration/company/" + (vm.company.IsDeleted ? keywords.ARCHIVE : ""));
                    })
                    .catch(function () { location.href = "#!/configuration/company"; })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            }

            vm.save = function () {
                if (!vm.validate()) {
                    return;
                }

                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_COMPANY");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_COMPANY_SAVED");
                    location.href = "#!/configuration/company";
                };

                var decycledCompany = decycle(vm.company);

                if (vm.isNew) {
                    resourceFactory
                        .company()
                        .create(decycledCompany)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
                else {
                    resourceFactory
                        .company(vm.companyId)
                        .update(decycledCompany)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
            };

            vm.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_COMPANY");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_COMPANY_REMOVED");
                    location.href = "#!/configuration/company";
                };

                resourceFactory
                    .company(vm.companyId)
                    .remove()
                    .$promise
                    .then(successCallback)
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            vm.isFormReadonly = function () {
                if (vm.company == null) return true;

                return vm.company.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };

            vm.validate = function () {
                var doesFormHaveErrors = false
                if (vm.company == null) {
                    doesFormHaveErrors = true;
                }
                else {
                    doesFormHaveErrors = false;
                    doesFormHaveErrors |= !companyValidator.validate(vm.company).isValid;
                }

                return !doesFormHaveErrors;
            };
        }
    ]);