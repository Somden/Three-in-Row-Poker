﻿"use strict";

angular
    .module("LeadApp")
    .controller("CompanyOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;

            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;

                vm.new = openPageForNewEntity;
                vm.toggleArchived = toggleArchived;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_CONFIGURATION_COMPANIES_ARCHIVED" : "ITEM_SUB_CONFIGURATION_COMPANIES");

                kendoGridBuilder(
                    "/odata/Company?$expand=DefaultCurrency",
                    "Company",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openPageForNewEntity() {
                location.href = "#!/configuration/company/new";
            };

            function openEntity(entityId) {
                location.href = "#!/configuration/company/" + entityId + "/edit";
            };

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/company";
                }
                else {
                    location.href = "#!/configuration/company/" + keywords.ARCHIVE;
                }
            };

            function canCreate () {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);