﻿"use strict";

angular
    .module("LeadApp")
    .controller("ChangePasswordController", [
        "$scope", "pageFactory", "messageFactory", "resourceFactory", "$translate", "$window",
        function ($scope, pageFactory, messageFactory, resourceFactory, $translate, $window) {
            pageFactory.setTitle("ITEM_SUB_CHANGE_PASSWORD");

            $scope.password = {
                OldPassword: "",
                NewPassword: "",
                ConfirmPassword: "",
            };
            $scope.passwordsDoNotMatch = false;
            $scope.doesFormHaveErrors = function () {
                if ($scope.password.NewPassword
                    && $scope.password.ConfirmPassword
                    && $scope.password.NewPassword != $scope.password.ConfirmPassword) {
                    $scope.passwordsDoNotMatch = true;
                }
                else {
                    $scope.passwordsDoNotMatch = false;
                }
                if ($scope.password.OldPassword
                    && $scope.password.NewPassword
                    && $scope.password.ConfirmPassword
                    && $scope.password.OldPassword.length > 8
                    && $scope.password.NewPassword.length > 8
                    && $scope.password.ConfirmPassword.length > 8
                    && $scope.password.NewPassword == $scope.password.ConfirmPassword) {
                    return false;
                }
                else {
                    return true;
                }
            }

            $scope.save = function () {
                resourceFactory
                    .userAccount()
                    .changePassword($scope.password)
                    .$promise
                    .then(function () {
                        messageFactory.showSuccessMessage($translate.instant("MESSAGE_PASSWORD_CHANGED"));
                        $scope.$apply(function () {
                            let isInitialChange = globalConfig.currentUser.MustChangePassword;
                            globalConfig.currentUser.MustChangePassword = false;
                            $scope.password.OldPassword = "";
                            $scope.password.NewPassword = "";
                            $scope.password.ConfirmPassword = "";
                            if (isInitialChange) {
                                $scope.$parent.isSideBarVisible = true;
                                $window.location = "#!/";
                            }
                        });
                    })
                    .catch(function (e, f) {
                        messageFactory.showErrorMessage($translate.instant("MESSAGE_PASSWORD_CHANGED_ERROR"));
                        $scope.$apply(function () {
                            $scope.password.OldPassword = "";
                            $scope.password.NewPassword = "";
                            $scope.password.ConfirmPassword = "";
                        });
                        console.log(e);
                    });
            }
        }
    ]);