﻿"use strict";

angular
    .module("LeadApp")
    .controller("UserOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;

            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;
                vm.totalCount = 0;
                vm.count = 0;
                vm.filterEnabled = false;

                vm.toggleArchived = toggleArchived;
                vm.new = openPageForNewEntity;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_CONFIGURATION_USERS_ARCHIVED" : "ITEM_SUB_CONFIGURATION_USERS");

                kendoGridBuilder(
                    "/odata/User",
                    "User",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function(){
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openEntity(entityId) {
                location.href = "#!/configuration/user/" + entityId + "/edit";
            }

            function openPageForNewEntity() {
                location.href = "#!/configuration/user/new";
            }

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/user";
                }
                else {
                    location.href = "#!/configuration/user/" + keywords.ARCHIVE;
                }
            }

            function canCreate() {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);