﻿"use strict";

angular
    .module("LeadApp")
    .controller("LogController", [
        "$scope", "$rootScope", "$translate", "pageFactory", "messageFactory",
        function ($scope, $rootScope, $translate, pageFactory, messageFactory) {
            pageFactory.setTitle("ITEM_SUB_CONFIGURATION_LOG");

            var loadingId = messageFactory.loadingMessage.show("LOADING_LOGS");
            $scope.gridOptions = {
                dataSource: new kendo.data.DataSource({
                    type: "odata-v4",
                    transport: {
                        read: {
                            url: "/odata/Log",
                            dataType: "json"
                        }
                    },
                    error: function (e) {
                        console.log(e.status + " : " + e.errorThrown);
                        messageFactory.loadingMessage.hide(loadingId, $rootScope);
                    },
                    sort: [
                        { field: "Id", dir: "desc" }
                    ],
                    requestEnd: function (e) {
                        messageFactory.loadingMessage.hide(loadingId, $rootScope);
                    },
                    schema: {
                        data: "value",
                        total: function (data) {
                            return data['@odata.count'];
                        },
                        model: {
                            fields: {
                                Id: { type: "number" },
                                TimeStamp: { type: "date" },
                                level: { type: "string" },
                                Message: { type: "string" },
                                logger: { type: "string" },
                            }
                        }
                    },
                    pageSize: 50,
                    page: 1,
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    serverGrouping: false,
                    serverAggregates: true,
                }),
                groupable: true,
                sortable: true,
                pageable: {
                    pageSize: 10,
                    refresh: true,
                    buttonCount: 5,
                    pageSizes: [10, 20, 50]
                },
                filterable: {
                    mode: "menu",
                    messages: {
                        info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                        isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                        isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                    }
                },
                scrollable: false,
                columns: [
                    {
                        field: "Id",
                        title: "{{ 'TABLE_LOG_ID' | translate }}",
                        width: 50
                    },
                    {
                        field: "TimeStamp",
                        template: "#=renderDateTime(TimeStamp)#",
                        title: "{{ 'TABLE_LOG_TIMESTAMP' | translate }}"
                    },
                    {
                        field: "level",
                        title: "{{ 'TABLE_LOG_LEVEL' | translate }}"
                    },
                    {
                        field: "Message",
                        title: "{{ 'TABLE_LOG_MESSAGE' | translate }}"
                    },
                    {
                        field: "logger",
                        title: "{{ 'TABLE_LOG_LOGGER' | translate }}"
                    }
                ]
            };
        }
    ]);
