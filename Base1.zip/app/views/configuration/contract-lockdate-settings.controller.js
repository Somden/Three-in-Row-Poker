﻿"use strict";

angular
    .module("LeadApp")
    .controller("ContractLockdateSettingsController", [
        "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "kendoDataSourceBuilder",
        function ($rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, kendoDataSourceBuilder) {
            pageFactory.setTitle("TITLE_CONTRACTLOCKDATESETTINGS_DETAILS", "/configuration/contractLockDateSetting/all");

            var vm = this;
            vm.contractLockDateSettingId = $routeParams.contractLockDateSettingId;
            vm.isNew = vm.contractLockDateSettingId == null || vm.contractLockDateSettingId.trim().length == 0;
            vm.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();

            vm.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };
            if (vm.isNew) {
                vm.contractLockDateSettingId = -1;
                vm.contractLockDateSetting = {
                    Id: -1,
                    
                };
            }
            else {
                vm.contractLockDateSettingId *= 1;
                var loadingId = messageFactory.loadingMessage.show("LOADING_CONTRACTLOCKDATESETTINGS");

                resourceFactory
                    .contractLockDateSettings(vm.contractLockDateSettingId)
                    .getById()
                    .$promise
                    .then(function (resp) {
                        vm.contractLockDateSetting = resp.Payload;
                        retrocycle(vm.contractLockDateSetting);

                        if (vm.contractLockDateSetting.Company != null) {
                            vm.companyDataSource = kendoDataSourceBuilder("/odata/Company")
                                .withoutDeleted()
                                .orHasId(vm.contractLockDateSetting.Company.Id);
                        }

                        pageFactory.setTitle(resp.Payload.Name, "/configuration/contractLockDateSettings/" + (vm.contractLockDateSetting.IsDeleted ? keywords.ARCHIVE : ""));
                    })
                    .catch(function () { location.href = "#!/configuration/contractLockDateSettings"; })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            }

            vm.save = function () {
                if (!vm.validate()) {
                    return;
                }

                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_CONTRACTLOCKDATESETTINGS");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_CONTRACTLOCKDATESETTINGS_SAVED");
                    location.href = "#!/configuration/contractLockDateSettings";
                };

                var decycledSetting = decycle(vm.contractLockDateSetting);

                if (vm.isNew) {
                    resourceFactory
                        .contractLockDateSettings()
                        .create(decycledSetting)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
                else {
                    resourceFactory
                        .contractLockDateSettings(vm.contractLockDateSettingId)
                        .update(decycledSetting)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
            };

            vm.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_CONTRACTLOCKDATESETTINGS");

                var successCallback = function () {
                    messageFactory.showSuccessMessage("MESSAGE_CONTRACTLOCKDATESETTINGS_REMOVED");
                    location.href = "#!/configuration/contractLockDateSettings";
                };

                resourceFactory
                    .contractLockDateSettings(vm.contractLockDateSettingId)
                    .remove()
                    .$promise
                    .then(successCallback)
                    .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            vm.isFormReadonly = function () {
                if (vm.contractLockDateSetting == null) return true;

                return vm.contractLockDateSetting.IsDeleted || !$rootScope.currentUser.IsAdmin;
            };

            vm.validate = function () {
                return true;
            };
        }
    ]);