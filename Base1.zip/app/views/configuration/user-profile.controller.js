﻿"use strict";

angular
    .module("LeadApp")
    .controller("UserProfileController", [
        "$scope", "$rootScope", "pageFactory", "messageFactory", "resourceFactory", "$translate",
        function ($scope, $rootScope, pageFactory, messageFactory, resourceFactory, $translate) {
            pageFactory.setTitle("TITLE_USER_PROFILE_DETAILS");
            $scope.expanded = [];

            var isHelpVisible = false;
            $scope.isHelpVisible = function (newValue) {
                if (newValue != null) {
                    isHelpVisible = newValue;
                }

                return isHelpVisible;
            };

            $scope.toggleShowHelp = function () {
                isHelpVisible = !isHelpVisible;

                if (isHelpVisible) {
                    messageFactory.showSuccessMessage($translate.instant("MESSAGE_TOOLTIPS_ACTIVATED"));
                }
            };
            resourceFactory.fieldFormatterHelper().get().$promise.then(function (arg) {
                $scope.fieldConfiguration = JSON.parse(arg.value);
                $scope.fieldConfigurationitems = {};
                $scope.fieldConfigurationDataSource = new kendo.data.DataSource({
                    data: $scope.fieldConfiguration.fieldFormatItems,

                });

            }).catch(function (e) {
                console.log(e.status + " : " + e.errorThrown);
            });
            $scope.$watch(function ($scope) {
                if (angular.isDefined($scope.userSetting) && angular.isDefined($scope.userSetting.ReportFieldSettings))
                    return $scope.userSetting.ReportFieldSettings;
                //.map(function (obj) { return obj.FieldType });
            }, function (newVal, oldValue) {
                for (var id in newVal) {
                    if (newVal[id].FieldType == "Boolean_CSV") {
                        newVal[id].OutputType = "csv";
                    } else
                        if (newVal[id].FieldType != "String") {
                            delete newVal[id].Maxlength;
                        }
                }
            }, true);
            $scope.addSetting = function () {
                var newItem = {
                    FieldType: "",
                    FieldTypeObject: [],
                    Format: "",
                    FormatObject: {},
                    Language: "",
                    OutputType: "",
                };
                $scope.userSetting.ReportFieldSettings.push(newItem);
            };

            $scope.removeSetting = function (index) {
                $scope.userSetting.ReportFieldSettings.splice(index, 1);
                if ($scope.userSetting.ReportFieldSettings.length == 0) {
                    $scope.addSetting();
                }

            };

            $scope.userId = $rootScope.currentUser.Id;

            $scope.resourceErrors = {
                list: [],
                shouldShowAllResourceErrors: false
            };

            $scope.userId *= 1;

            var loadingId = messageFactory.loadingMessage.show("LOADING_USER");

            resourceFactory
                .user($scope.userId)
                .getById()
                .$promise
                .then(function (resp) {
                    $scope.user = resp.Payload;

                    $scope.userSetting = JSON.parse($scope.user.Settings);

                    if ($scope.userSetting != null) {
                        if (angular.isDefined($scope.userSetting.ReportFieldSettings)) {
                            for (var i in $scope.userSetting.ReportFieldSettings) {
                                var field = $scope.userSetting.ReportFieldSettings[i];
                                if (field != null) {
                                    for (var g in $scope.fieldConfiguration.fieldFormatItems) {
                                        if ($scope.fieldConfiguration.fieldFormatItems[g].key == field.FieldType) {
                                            field.FieldTypeObject = $scope.fieldConfiguration.fieldFormatItems[g];
                                            for (var obj in field.FieldTypeObject.fieldFormatParser) {
                                                if (field.FieldTypeObject.fieldFormatParser[obj].key == field.Format) {
                                                    field.FormatObject = field.FieldTypeObject.fieldFormatParser[obj];
                                                    break;
                                                }
                                            }
                                            break;
                                        }
                                    }
                                } else {
                                    delete $scope.userSetting.ReportFieldSettings[i];
                                }
                            }
                        }
                    } else {
                        $scope.userSetting = {
                            ReportFieldSettings: []
                        };
                    }
                    if (!angular.isDefined($scope.userSetting.ReportFieldSettings[0]) && $scope.userSetting.ReportFieldSettings.length > 0) {
                        $scope.removeSetting(0);
                    }
                    if ($scope.userSetting.ReportFieldSettings.length == 0) {
                        $scope.addSetting();
                    }
                    var title = resp.Payload.FirstName + " " + resp.Payload.LastName;
                    pageFactory.setTitle(title);
                })
                .catch(function (ex) {
                    location.href = "#!/contract";
                })
                .finally(function () {
                    messageFactory.loadingMessage.hide(loadingId);
                });

            $scope.save = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_USER");
                $scope.userSetting.ReportFieldSettings = $scope.userSetting.ReportFieldSettings.filter(function (field) {
                    return angular.isDefined(field.FieldType) && field.FieldType != null && field.FieldType != "";
                });
                $scope.userSetting.ReportFieldSettings.forEach(function (field) {
                    if (!angular.isDefined(field.FormatObject) || !angular.isDefined(field.FormatObject.key)) {
                        if (field.FieldTypeObject.fieldFormatParser.length > 0) {
                            field.FormatObject = field.FieldTypeObject.fieldFormatParser[0];
                            field.Format = field.FormatObject.key;
                        } else {
                            delete field.FormatObject;
                            delete field.Format;
                        }
                    }
                });
                var cp = angular.copy($scope.userSetting);

                $scope.userSetting.ReportFieldSettings.forEach(function (field) {
                    if (angular.isDefined(field.FieldTypeObject))
                        delete field.FieldTypeObject;
                    if (angular.isDefined(field.FormatObject))
                        delete field.FormatObject;
                });
                $scope.user.Settings = JSON.stringify($scope.userSetting);
                
                var successCallback = function (arg) {
                    messageFactory.showSuccessMessage("MESSAGE_USER_SAVED");
                    $rootScope.currentUser = arg.Payload;
                };

                if ($scope.isNew) {
                    resourceFactory
                        .user()
                        .create($scope.user)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) {
                            $scope.resourceErrors = {
                                list: resp.data.ValidationErrors
                            }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                }
                else {
                    resourceFactory
                        .user($scope.userId)
                        .update($scope.user)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) {
                            $scope.resourceErrors = {
                                list: resp.data.ValidationErrors
                            }
                        })
                        .finally(function () {
                            messageFactory.loadingMessage.hide(loadingId);
                        });
                }
            };

            $scope.doesFormHaveErrors = function () {
                return false;
            }

        }
    ]);