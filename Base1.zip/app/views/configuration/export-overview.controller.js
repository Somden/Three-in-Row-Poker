﻿"use strict";

angular
    .module("LeadApp")
    .controller("ExportOverviewController", [
        "$scope", "pageFactory", "messageFactory", "resourceFactory",
        function ($scope, pageFactory, messageFactory, resourceFactory) {
            pageFactory.setTitle("TITLE_EXPORT_OVERVIEW");

            var vm = this;

            (function initialize() {
                vm.filter = {
                    IsMoreThan12HoursAgo: false
                };

                vm.addExportWatch = addExportWatch;
                vm.refresh = refresh;

                refresh();
            })();

            function onOverviewReceived(resp) {
                var twelveHoursAgo = new Date();
                twelveHoursAgo.setHours(twelveHoursAgo.getHours() - 12);

                resp.forEach(function (x) {
                    x.CreatedDate = new Date(x.CreatedDate);
                    x.IsMoreThan12HoursAgo = x.CreatedDate < twelveHoursAgo;
                });

                vm.exportFiles = resp;
            }

            function addExportWatch(exportId) {
                messageFactory
                    .exportNotificationMessage
                    .addExportWatchByExportId(exportId, resourceFactory);
            }

            function refresh() {
                var loadingId = messageFactory.loadingMessage.show("LOADING");
                vm.exportFiles = [];
                resourceFactory
                    .reportProgress()
                    .getOverview()
                    .$promise
                    .then(onOverviewReceived)
                    .catch(function (e) { console.error(e); })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            }
        }
    ]);