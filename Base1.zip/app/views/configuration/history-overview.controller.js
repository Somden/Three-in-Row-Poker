﻿"use strict";

angular
    .module("LeadApp")
    .controller("HistoryController", [
        "$rootScope", "$translate", "pageFactory", "messageFactory",
        function ($rootScope, $translate, pageFactory, messageFactory) {
            var vm = this;

            pageFactory.setTitle("ITEM_SUB_CONFIGURATION_HISTORY");

            var loadingId = messageFactory.loadingMessage.show("LOADING_HISTORY");
            vm.gridOptions = {
                dataSource: new kendo.data.DataSource({
                    type: "odata-v4",
                    transport: {
                        read: {
                            url: "/odata/History",
                            dataType: "json",
                            beforeSend: function (e, request) {
                                console.log(request.url);
                            }
                        }
                    },
                    error: function (e) {
                        console.log(e.status + " : " + e.errorThrown);
                        messageFactory.loadingMessage.hide(loadingId, $rootScope);
                    },
                    sort: [
                        { field: "Id", dir: "desc" }
                    ],
                    requestEnd: function (e) {
                        messageFactory.loadingMessage.hide(loadingId, $rootScope);
                    },
                    schema: {
                        data: "value",
                        total: function (data) {
                            return data['@odata.count'];
                        },
                        model: {
                            fields: {
                                Id: { type: "number" },
                                Action: { type: "string" },
                                CreatedDate: { type: "date" },
                                ObjectName: { type: "string" },
                                ObjectId: { type: "number" },
                                Changes: { type: "string" },
                                CreatedBy: { type: "string" },
                            }
                        }
                    },
                    pageSize: 50,
                    page: 1,
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    serverGrouping: false,
                    serverAggregates: true,
                }),
                groupable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    buttonCount: 5,
                    pageSizes: [10, 20, 50]
                },
                filterable: {
                    mode: "menu",
                    messages: {
                        info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                        isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                        isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                    }
                },
                scrollable: false,
                columns: [
                    {
                        field: "CreatedDate",
                        template: "#=renderDateTime(CreatedDate)#",
                        title: "{{ 'TABLE_HISOTRY_TIMESTAMP' | translate }}"
                    },
                    {
                        field: "CreatedBy",
                        title: "{{ 'TABLE_HISTORY_LOGGER' | translate }}",
                        hidden: globalConfig.hideUserSpecificNames || false
                    },
                    {
                        field: "Action",
                        title: "{{ 'TABLE_HISOTRY_ACTION' | translate }}"
                    },
                    {
                        field: "ObjectName",
                        title: "{{ 'TABLE_HISTORY_OBJECTNAME' | translate }}"
                    },
                    {
                        field: "ObjectId",
                        title: "{{ 'TABLE_HISTORY_OBJECTID' | translate }}"
                    },
                    {
                        field: "Changes",
                        title: "{{ 'TABLE_HISOTRY_CHANGES' | translate }}",
                        template: function (dataItem) {
                            if (dataItem.Action == "Delete") {
                                return "{{ 'TABLE_HISOTRY_DELETED' | translate }}";
                            }
                            if (dataItem.Action == "Create") {
                                return "{{ 'Create' | translate }}";
                            }
                            var obj = JSON.parse(dataItem.Changes);
                            var changes = obj.Changes;
                            var retv = "";
                            for (var change in changes) {
                                var object = changes[change];
                                if (object.Field == "ChangedDate")
                                    continue;
                                var oldvalue = "<strong>" + object.OldValue + "</strong>";
                                if (object.OldValue.length == 0) {
                                    oldvalue = "<i><font color='LightGray'>{{ 'TABLE_HISOTRY_EMPTY' | translate }}</font></i>";
                                }
                                var newvalue = "<strong>" + object.NewValue + "</strong>";
                                if (object.NewValue.length == 0) {
                                    newvalue = "<i><font color='LightGray'>{{ 'TABLE_HISOTRY_EMPTY' | translate }}</font></i>";
                                }
                                retv += object.Field + ":&emsp;" + oldvalue + "&emsp;=> " + newvalue + "<br>";
                            }
                            return retv;
                        }
                    }
                ]
            };
        }
    ]);