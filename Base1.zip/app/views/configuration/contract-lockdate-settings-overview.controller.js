﻿"use strict";

angular
    .module("LeadApp")
    .controller("contractLockDateSettingsOverviewController", [
        "$scope", "$rootScope", "$routeParams", "pageFactory", "kendoGridBuilder",
        function ($scope, $rootScope, $routeParams, pageFactory, kendoGridBuilder) {
            var vm = this;

            (function initialize() {
                vm.showArchived = $routeParams.range == keywords.ARCHIVE;

                vm.new = openPageForNewEntity;
                vm.toggleArchived = toggleArchived;
                vm.canCreate = canCreate;

                pageFactory.setTitle(vm.showArchived ? "ITEM_SUB_CONFIGURATION_CONTRACTLOCKDATESETTINGS_ARCHIVED" : "ITEM_SUB_CONFIGURATION_CONTRACTLOCKDATESETTINGS");

                kendoGridBuilder(
                    "/odata/ContractLockDateSetting?$expand=Company",
                    "ContractLockDateSetting",
                    vm.showArchived,
                    openEntity,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                        });
                    });
            })();

            function openPageForNewEntity() {
                location.href = "#!/configuration/contractLockDateSettings/new";
            };

            function openEntity(entityId) {
                location.href = "#!/configuration/contractLockDateSettings/" + entityId + "/edit";
            };

            function toggleArchived() {
                if (vm.showArchived) {
                    location.href = "#!/configuration/contractLockDateSettings";
                }
                else {
                    location.href = "#!/configuration/contractLockDateSettings/" + keywords.ARCHIVE;
                }
            };

            function canCreate () {
                return $rootScope.currentUser.IsAdmin;
            };
        }
    ]);