"use strict";

angular
    .module("LeadApp")
    .controller("UserController", [
        "$rootScope", "$routeParams", "pageFactory", "messageFactory", "resourceFactory", "userValidator", "$timeout", "kendoDataSourceBuilder",
        function ($rootScope, $routeParams, pageFactory, messageFactory, resourceFactory, userValidator, $timeout, kendoDataSourceBuilder) {
            var vm = this;

            pageFactory.setTitle("TITLE_USER_DETAILS", "/configuration/user/all");
            vm.passwordsDoNotMatch = false;
            vm.showChangePasswordSection = false;
            function initialize() {
                vm.userId = $routeParams.userId;
                vm.domainNameForNewUser = $routeParams.domainName;
                vm.isNew = vm.userId == null || vm.userId.trim().length == 0;

                vm.resourceErrors = {
                    list: [],
                    shouldShowAllResourceErrors: false
                };

                if (vm.isNew) {
                    vm.user = {
                        Id: 0,
                        IsActive: true,
                        IsAdmin: false,
                        DomainName: vm.domainNameForNewUser
                    };

                    initializeCompanyDropdown();
                }
                else {
                    vm.userId *= 1;
                    var loadingId = messageFactory.loadingMessage.show("LOADING_USER");
                    resourceFactory
                        .user(vm.userId)
                        .getById()
                        .$promise
                        .then(function (resp) {
                            vm.user = resp.Payload;
                            if (vm.user == null) throw "User-Payload is null";

                            var title = resp.Payload.FirstName + " " + resp.Payload.LastName;
                            pageFactory.setTitle(title, "/configuration/user/all/" + (vm.user.IsDeleted ? keywords.ARCHIVE : ""));
                            retrocycle(vm.user);
                            initializeCompanyDropdown();
                        })
                        .catch(function (e) { console.error(e); location.href = "#!/configuration/user/all"; })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
            };

            vm.save = function () {
                vm.resourceErrors.list = [];
                var loadingId = messageFactory.loadingMessage.show("LOADING_SAVING_USER");
                if (!vm.showChangePasswordSection) {
                    vm.user.Password = null;
                    vm.user.ConfirmPassword = null;
                }
                var successCallback = function (resp) {
                    messageFactory.showSuccessMessage("MESSAGE_USER_SAVED");
                    location.href = "#!/configuration/user/" + resp.Payload.Id + "/edit";
                };

                var userToSend = decycle(vm.user);
                
                if (vm.isNew) {
                    vm.user.MustChangePassword = true;
                    resourceFactory
                        .user()
                        .create(userToSend)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) { vm.resourceErrors = { list: resp.data.ValidationErrors } })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
                else {
                    resourceFactory
                        .user(vm.userId)
                        .update(userToSend)
                        .$promise
                        .then(successCallback)
                        .catch(function (resp) {
                            if (resp.data.ValidationErrors) {
                                vm.resourceErrors = { list: resp.data.ValidationErrors };
                            }
                            else if (resp.data.length > 0) {
                                vm.resourceErrors = { list: resp.data };
                            }
                        })
                        .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
                }
            };

            vm.remove = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_REMOVING_USER");

                resourceFactory
                    .user(vm.userId)
                    .remove()
                    .$promise
                    .then(function () {
                        messageFactory.showSuccessMessage("MESSAGE_USER_REMOVED");
                        location.href = "#!/configuration/user/all";
                    })
                    .finally(function () { messageFactory.loadingMessage.hide(loadingId); });
            };

            vm.validate = function () {
                var doesFormHaveErrors = false;
                if (vm.user == null) {
                    doesFormHaveErrors = true;
                }
                else {
                    doesFormHaveErrors |= !userValidator.validate(vm.user).isValid;

                    if (vm.user.CanChangePassword && vm.showChangePasswordSection) {
                        if (!vm.user.Password || !vm.user.ConfirmPassword ||
                            (vm.user.Password != vm.user.ConfirmPassword || vm.user.ConfirmPassword.length < 8 || vm.user.Password.length < 8)) {
                            vm.passwordsDoNotMatch = true;
                        }
                        else {
                            vm.passwordsDoNotMatch = false;
                        }
                        doesFormHaveErrors |= vm.passwordsDoNotMatch;
                    }
                }
                return !doesFormHaveErrors;
            };

            vm.removeCompany = function (companyId) {
                removeCompanyFromPermissions(companyId);
            };

            vm._onSelectedCompanyChanged = function (e) {
                if (e == null) return;

                var companyToAdd = e.dataItem;
                addCompanyToPermissions(companyToAdd);
            };

            function removeCompanyFromPermissions(companyId) {
                for (var f in vm.user.UserCompanies) {
                    var userCompany = vm.user.UserCompanies[f];
                    if (userCompany.Company != null && userCompany.Company.Id == companyId) {
                        vm.user.UserCompanies.splice(f, 1);
                        return;
                    }
                }

                return false;
            }

            function addCompanyToPermissions(companyToAdd) {
                vm.user.UserCompanies = vm.user.UserCompanies || [];
                let alreadyContainsCompany = false;
                for (let i = 0; i < vm.user.UserCompanies.length; i++) {
                    if (vm.user.UserCompanies[i].Company.Id == companyToAdd.Id) {
                        alreadyContainsCompany = true;
                        break;
                    }
                }
                if (!alreadyContainsCompany) {
                    vm.user.UserCompanies.push({
                        Id: -1,
                        CanModify: false,
                        Company: companyToAdd
                    });
                }
                vm.isCompanyDropdownVisible = false;

                initializeCompanyDropdown();
            }

            function getFirstOrDefault(arr, propertyName, value) {
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i][propertyName] == value) return arr[i];
                }
                return {};
            }

            function initializeCompanyDropdown() {
                var dataSource = kendoDataSourceBuilder("/odata/Company?$expand=DefaultCurrency&$orderby=Name")
                    .withoutDeleted();

                // TODO: Fix this, with 16 companies, it causes odata error 'The node count limit of '100' has been exceeded'
                //if (vm.user.UserCompanies != null) {
                //    var companyIds = vm.user.UserCompanies.map(function (userCompany) { return userCompany.Company.Id; });
                //    for (var f in companyIds) {
                //        dataSource = dataSource.andHasNotId(companyIds[f]);
                //    }
                //}

                vm.companiesDataSource = dataSource;
            }

            initialize();
        }
    ]);