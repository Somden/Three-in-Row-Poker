﻿"use strict";

angular
    .module("LeadApp")
    .controller("CompanySummaryReportController", [
        "$scope", "$rootScope", "pageFactory", "$translate", "messageFactory", "reportCompanySummaryValidator", "resourceFactory","exportFactory","kendoGridBuilder","kendoDataSourceBuilder",
        function ($scope, $rootScope, pageFactory, $translate, messageFactory, reportCompanySummaryValidator, resourceFactory, exportFactory ,kendoGridBuilder,kendoDataSourceBuilder) {
            pageFactory.setTitle("ITEM_SUB_REPORT_COMPANY_SUMMARY_REPORT");

            var vm = $scope;

            (function initialize() {
                vm.reportConfig = {};
                vm.showGrid = false;
                vm.exportFactory = exportFactory;
                vm.validate = validate;
                vm.totalCount = 0;
                vm.count = 0;
                vm.showFormat = false;

                vm.generateReport = generateReport;
                vm.getReportParameters = getReportParameters;

                initializeDropDowns();
            })();

            function validate() {
                var result = reportCompanySummaryValidator.validate(vm.reportConfig);

                return result.isValid;
            };

            function getReportParameters() {
                var parameters = {
                    companyId: $scope.reportConfig.selectedCompany.Id,
                    contractState: $scope.reportConfig.contractState.state
                };

                if (angular.isDefined($scope.reportConfig.evaluationStart) && $scope.reportConfig.evaluationStart != null && angular.isDefined($scope.reportConfig.evaluationEnd) && $scope.reportConfig.evaluationEnd != null) {
                    parameters.evaluationStart = $scope.reportConfig.evaluationStart.getFullYear() + "-" + ($scope.reportConfig.evaluationStart.getMonth() + 1) + "-" + $scope.reportConfig.evaluationStart.getDate();
                    parameters.evaluationEnd = $scope.reportConfig.evaluationEnd.getFullYear() + "-" + ($scope.reportConfig.evaluationEnd.getMonth() + 1) + "-" + $scope.reportConfig.evaluationEnd.getDate();
                }

                return parameters;
            };

            function getReportUrl() {
                var parameters = getReportParameters();
                if (parameters.evaluationStart != null && parameters.evaluationEnd != null) {
                    return "/odata/CompanySummaryReport/Lead.Get("
                        + "companyId=" + parameters.companyId + ","
                        + "contractState='" + parameters.contractState + "'"
                        + "evaluationStart='" + parameters.evaluationStart + "',"
                        + "evaluationEnd='" + parameters.evaluationEnd + "'"+
                        ")";
                } else {
                    return "/odata/CompanySummaryReport/Lead.Get("
                        + "companyId=" + parameters.companyId + ","
                        + "contractState='" + parameters.contractState + "'"
                        + "evaluationStart=null,"
                        + "evaluationEnd=null" +
                        ")";
                }
                
            };

            function generateReport() {
                vm.showGrid = false;

                var options = {
                    preloadAllResults: true
                };

                kendoGridBuilder(
                    getReportUrl(),
                    "CompanySummaryReport",
                    null,
                    null,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                            vm.showGrid = true;
                        });
                    }, options);
            };

            function initializeDropDowns() {
                vm.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();
                vm.contractStateDataSource = [
                    { state: "" },
                    { state: "AllValid" },
                    { state: "ValidatedPending" },
                    { state: "Validated" },
                    { state: "Terminated" },
                    { state: "Completed" }
                ];
              
            }
        }
    ]);