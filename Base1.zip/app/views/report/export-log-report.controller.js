﻿"use strict";

angular
    .module("LeadApp")
    .controller("ExportLogReportController", [
        "$scope", "$rootScope", "pageFactory", "$translate", "messageFactory", "exportLogReportValidator", "resourceFactory", "kendoDataSourceBuilder",
        function ($scope, $rootScope, pageFactory, $translate, messageFactory, exportLogReportValidator, resourceFactory, kendoDataSourceBuilder) {
            pageFactory.setTitle("REPORTS_EXPORT_LOGS_TITLE");
            $scope.showFormat = false;
            $scope.reportLoaded = false;
            $scope.kendoHelpers = $rootScope.kendoHelpers;
            $scope.showGrid = false;
            $scope.totalCount = 0;
            $scope.count = 0;
            $scope.reportConfig = {
                isAllEntries: false
            };

            $scope.reportLoaded = false;
            
            $scope.$watch("reportConfig", function validate() {
                if($scope.reportConfig == null) return;

                exportLogReportValidator.validate($scope.reportConfig);
            }, true);

            $scope.$watch("reportConfig.isAllEntries", function validate() {
                if ($scope.reportConfig == null || $scope.reportConfig.isAllEntries == null) return;

                if ($scope.reportConfig.isAllEntries) {
                    $scope.reportConfig.evaluationDate = null;
                }
            });

            $scope.$watch("reportConfig.evaluationDate", function validate() {
                if ($scope.reportConfig == null || $scope.reportConfig.evaluationDate == null) return;

                if ($scope.reportConfig.evaluationDate) {
                    $scope.reportConfig.isAllEntries = false;
                }
            });

            $scope.generateReport = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_SERIES_REPORT");
                $scope.showGrid = false; // Hide the grid, so the grid will be reinitialized if it's already loaded
                resourceFactory
                    .exportLogReport($scope.reportConfig)
                    .getResults()
                    .$promise
                    .then(function (resp) {
                        var results = resp.value;
                        $scope.reportLoaded = results.length > 0;
                        initializeKendoGrid(results);
                    })
                    .catch(function (resp) {
                        console.log('error caught', resp);
                    })
                    .finally(function (a) {
                        messageFactory.loadingMessage.hide(loadingId);
                    });
            };

            var initializeKendoGrid = function (results) {
                var tableWidth = 1210;
                var columnCount = 5;
                $scope.showGrid = true;

                $scope.totalCount = results.length;

                $scope.gridOptions = {
                    dataSource:
                        {
                            data: results,
                            schema: {
                                model: {
                                    fields: {
                                        ReportName: { type: "string" },
                                        ReportParameters: { type: "string" }, 
                                        ExportType: { type: "string" },
                                        CreatedDate: { type: "date" }
                                    }
                                }
                            },
                            pageSize: 50,
                            page: 1
                        },
                    sortable: true,
                    pageable: {
                        refresh: true,
                        buttonCount: 5,
                        pageSizes: [10, 20, 50],
                        messages: {
                            display: $translate.instant("KENDO_GRID_DISPLAY"),
                            empty: $translate.instant("KENDO_GRID_EMPTY"),
                            page: $translate.instant("KENDO_GRID_PAGE"),
                            allPages: $translate.instant("KENDO_GRID_ALLPAGES"),
                            of: $translate.instant("KENDO_GRID_OF"),
                            itemsPerPage: $translate.instant("KENDO_GRID_ITEMSPERPAGE"),
                            first: $translate.instant("KENDO_GRID_FIRST"),
                            previous: $translate.instant("KENDO_GRID_PREVIOUS"),
                            next: $translate.instant("KENDO_GRID_NEXT"),
                            last: $translate.instant("KENDO_GRID_LAST"),
                            refresh: $translate.instant("KENDO_GRID_REFRESH")
                        }
                    },
                    filterable: {
                        mode: "menu",
                        messages: {
                            info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                            isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                            isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                        }
                    },
                    scrollable: false,
                    columns: [
                        {
                            field: "CreatedDate",
                            width: tableWidth / columnCount,
                            title: "{{'REPORT_EXPORT_LOG_REPORT_TIMESTAMP' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(CreatedDate || "", "' + $rootScope.dateFormat + '")#</div>'
                        },
                        {
                            field: "ReportName",
                            width: tableWidth / columnCount,
                            title: "{{'REPORT_EXPORT_LOG_REPORT_NAME' | translate}}"
                        },
                        {
                            field: "ReportParameters",
                            width: tableWidth / columnCount,
                            title: "{{'REPORT_EXPORT_LOG_REPORT_PARAMETERS' | translate}}"
                        },
                        {
                            field: "ExportType",
                            width: tableWidth / columnCount,
                            title: "{{'REPORT_EXPORT_LOG_EXPORT_TYPE' | translate}}"
                        },
                        {
                            field: "Company.Name",
                            width: tableWidth / columnCount,
                            title: "{{'REPORT_EXPORT_LOG_COMPANY_NAME' | translate}}",
                            template: "{{ dataItem.Company ? dataItem.Company.Name : \"\" }}"
                        },
                    ]
                };
            };
        }
    ]);