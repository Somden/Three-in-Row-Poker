﻿"use strict";

angular
    .module("LeadApp")
    .controller("AssetListReportController", [
        "$scope", "$rootScope", "$timeout", "pageFactory", "$translate", "messageFactory", "reportAssetListValidator", "resourceFactory", "exportFactory", "kendoDataSourceBuilder",
        function ($scope, $rootScope, $timeout, pageFactory, $translate, messageFactory, reportAssetListValidator, resourceFactory, exportFactory, kendoDataSourceBuilder) {
            pageFactory.setTitle("REPORTS_ASSET_LIST_TITLE");

            $scope.totalCount = 0;
            $scope.count = 0;
            $scope.showFormat = false;

            $scope.kendoHelpers = $rootScope.kendoHelpers;
            $scope.exportFactory = exportFactory;
            $scope.showGrid = false;
            $scope.reportConfig = {};

            $scope.accountingStandardDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                .whereEquals("EnumType", "AccountingStandardType");
            $scope.companyDataSource = kendoDataSourceBuilder("/odata/Company")
                .withoutDeleted();
            $scope.contractStateDataSource = [
                { state: "" },
                { state: "AllValid" },
                { state: "ValidatedPending" },
                { state: "Validated" },
                { state: "Terminated" },
                { state: "Completed" }
            ];

            $scope.reportConfig.accountingStandard = {
                EnumType: "AccountingStandardType",
                Value: "IFRS",
            };

            $scope.$watch("reportConfig", function validate() {
                if ($scope.reportConfig == null) return;

                reportAssetListValidator.validate($scope.reportConfig);
            }, true);

            $scope.generateReport = function () {
                $scope.showGrid = false; // Hide the grid, so the grid will be reinitialized if it's already loaded

                $timeout(function () {
                    initializeKendoGrid();
                }, 0);
            };

            $scope.getReportParameters = function () {
                var parameters = {
                    companyId: $scope.reportConfig.selectedCompany.Id,
                    revisionState: $scope.reportConfig.contractState.state,
                    accountingStandard: $scope.reportConfig.accountingStandard.Value
                };

                if (angular.isDefined($scope.reportConfig.evaluationStart) && $scope.reportConfig.evaluationStart != null && angular.isDefined($scope.reportConfig.evaluationEnd) && $scope.reportConfig.evaluationEnd != null) {
                    parameters.evaluationStart = $scope.reportConfig.evaluationStart.getFullYear() + "-" + ($scope.reportConfig.evaluationStart.getMonth() + 1) + "-" + $scope.reportConfig.evaluationStart.getDate();
                    parameters.evaluationEnd = $scope.reportConfig.evaluationEnd.getFullYear() + "-" + ($scope.reportConfig.evaluationEnd.getMonth() + 1) + "-" + $scope.reportConfig.evaluationEnd.getDate();
                }

                return parameters;
            };

            $scope.getReportUrl = function () {
                var parameters = $scope.getReportParameters();
                if (parameters.evaluationStart != null && parameters.evaluationEnd != null) {
                    return "/odata/AssetListReport/Lead.Get("
                            + "CompanyId=" + parameters.companyId + ","
                            + "RevisionState='" + parameters.revisionState + "',"
                            + "AccountingStandard='" + parameters.accountingStandard + "',"
                            + "EvaluationStart='" + parameters.evaluationStart + "',"
                            + "EvaluationEnd='" + parameters.evaluationEnd + "'"
                        + ")";
                }
                else {
                    return "/odata/AssetListReport/Lead.Get("
                            + "CompanyId=" + parameters.companyId + ","
                            + "RevisionState='" + parameters.revisionState + "',"
                            + "AccountingStandard='" + parameters.accountingStandard + "',"
                            + "EvaluationStart=null,"
                            + "EvaluationEnd=null"
                        + ")";
                }
            };

            var initializeKendoGrid = function () {
                $scope.showGrid = true;

                //$scope.totalCount = results.length;

                $scope.gridOptions = {
                    dataSource: new kendo.data.DataSource(
                        {
                            type: "odata-v4",
                            transport: {
                                read: {
                                    url: $scope.getReportUrl(),
                                    dataType: "json",
                                    beforeSend: function (e, request) {
                                        $scope.loadingId = messageFactory.loadingMessage.show("LOADING_SERIES_REPORT");
                                        $scope.odataSourceUrl = request.url;
                                        $scope.dataSourceUrl = request.url;
                                        $scope.ReportUrl = request.url;
                                    }
                                }
                            },
                            error: function (e) {
                                console.log(e.errorThrown);
                                console.log(e.sender);
                                console.log(e.status);
                                console.log(e.xhr);

                                $scope.$apply(function () {
									messageFactory.loadingMessage.hide($scope.loadingId, $rootScope);
									if (typeof (e) !== "undefined" && e !== null && typeof (e.xhr) !== "undefined" &&
										e.xhr !== null && typeof (e.xhr.responseText) !== "undefined" && e.xhr.responseText !== null &&
										e.xhr.responseText.toUpperCase() === "NO CONTRACT FOUND") {
										messageFactory.showWarningMessage("REPORT_NO_CONTRACT_FOUND_MATCHING_CRITERIA");
									}
									else {
										messageFactory.showErrorMessage("MESSAGE_REQUEST_ERROR");
									}
                                });
                            },
                            requestEnd: function (e) {
                                $scope.$apply(function () { messageFactory.loadingMessage.hide($scope.loadingId, $rootScope); });
                            },

                            schema: {
                                data: function (data) {
                                    return data.value;
                                },
                                total: function (data) {
                                    return data['@odata.count'];
                                },
                                pageSize: "pageSize",
                                skip: "skip",

                                model: {
                                    fields: {
                                        EvaluationPeriodStart: { type: "date" },
                                        EvaluationPeriodEnd: { type: "date" },
                                        //EvaluationPeriodMonth: { type: "number" },
                                        //EvaluationPeriodYear: { type: "year" },
                                        ContractId: { type: "number" },
                                        ContractName: { type: "string" },
                                        Currency: { type: "string" },
                                        CalcSumOperateSpecialDepreciationPeriod: { type: "number" },
                                        CalcOperateSpecialValueStartPeriod: { type: "number" },
                                        CalcOperateSpecialValueEndPeriod: { type: "number" },
                                        CalcOperateSpecialDiffInPeriod: { type: "number" },
                                        CalcOperateSpecialValueRetirementDate: { type: "number" },
                                        AssetId: { type: "number" },
                                        AssetName: { type: "string" },
                                        CalcSumAssetDepreciationPeriod: { type: "number" },
                                        AssetComponentId: { type: "number" },
                                        ContractComponentId: { type: "number" },
                                        AssetComponentName: { type: "sring" },
                                        IsLimited: { type: "boolean" },
                                        ValueDelta: { type: "number" },
                                        EconomicalUsefulLifeEndDate: { type: "Date" },
                                        FairValue: { type: "number" },
                                        AssetShare: { type: "number" },
                                        CalcAssetClass: { type: "string" },
                                        CalcAssetValueRevisionDifference: { type: "number" },
                                        CalcSumAssetComponentDepreciationPeriod: { type: "number" },
                                        CalcAssetComponentValueStartPeriod: { type: "number" },
                                        CalcAssetComponentValueEndPeriod: { type: "number" },
                                        CalcAssetComponentDiffInPeriod: { type: "number" },
                                        CalcAssetComponentValueRetirementDate: { type: "number" },
                                        CalcUsefulLifeEndDate: { type: "date" },
                                        CalcUsefulLifeEndDay: { type: "number" }
                                    }
                                }
                            },
                            serverPaging: true,
                            pageSize: 10,
                            page: 1,
                            serverSorting: false,
                            serverFiltering: false,
                            serverAggregates: false,
                            serverGrouping: false
                        }),
                    sortable: true,
                    groupable: true,
                    pageable: {
                        refresh: true,
                        buttonCount: 5,
                        pageSizes: [10, 20, 50],
                        messages: {
                            display: $translate.instant("KENDO_GRID_DISPLAY"),
                            empty: $translate.instant("KENDO_GRID_EMPTY"),
                            page: $translate.instant("KENDO_GRID_PAGE"),
                            allPages: $translate.instant("KENDO_GRID_ALLPAGES"),
                            of: $translate.instant("KENDO_GRID_OF"),
                            itemsPerPage: $translate.instant("KENDO_GRID_ITEMSPERPAGE"),
                            first: $translate.instant("KENDO_GRID_FIRST"),
                            previous: $translate.instant("KENDO_GRID_PREVIOUS"),
                            next: $translate.instant("KENDO_GRID_NEXT"),
                            last: $translate.instant("KENDO_GRID_LAST"),
                            refresh: $translate.instant("KENDO_GRID_REFRESH")
                        }
                    },
                    filterable: {
                        mode: "menu",
                        messages: {
                            info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                            isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                            isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                        }
                    },
                    scrollable: false,
                    columns: [

                        {
                            field: "ContractId",
                            title: "{{'REPORTS_ASSET_LIST_CONTRACT_ID' | translate}}",
                            template: '<div class="text-right">{{ dataItem.ContractId }}</div>'
                        },
                        {
                            field: "ContractName",
                            title: "{{'REPORTS_ASSET_LIST_CONTRACT_NAME' | translate}}"
                        },
                        {
                            field: "Currency",
                            title: "{{'REPORTS_ASSET_LIST_CURRENCY' | translate}}"
                        },
                        {
                            field: "AssetId",
                            title: "{{'REPORTS_ASSET_LIST_ASSET_ID' | translate}}",
                            template: '<div class="text-right">{{ dataItem.AssetId }}</div>'
                        },
                        {
                            field: "AssetName",
                            title: "{{'REPORTS_ASSET_LIST_ASSET_NAME' | translate}}"
                        },
                        {
                            field: "AssetComponentId",
                            title: "{{'REPORTS_ASSET_LIST_ASSET_COMPONENT_ID' | translate}}",
                            template: '<div class="text-right">{{ dataItem.AssetComponentId }}</div>'
                        },
                        {
                            field: "ContractComponentId",
                            title: "{{'REPORTS_ASSET_LIST_CONTRACT_COMPONENT_ID' | translate}}",
                            template: '<div class="text-right">{{ dataItem.ContractComponentId }}</div>'
                        },
                        {
                            field: "AssetComponentName",
                            title: "{{'REPORTS_ASSET_LIST_ASSET_COMPONENT_NAME' | translate}}"
                        },
                        {
                            field: "CalcSumOperateSpecialDepreciationPeriod",
                            title: "{{'REPORTS_ASSET_LIST_SUM_OPERATE_SPECIAL_DEPRECIATION_IN_PERIOD' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcSumOperateSpecialDeprecationPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcOperateSpecialValueStartPeriod",
                            title: "{{'REPORTS_ASSET_LIST_OPERATE_SPECIAL_START' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcOperateSpecialValueStartPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcOperateSpecialDiffInPeriod",
                            title: "{{'REPORTS_ASSET_LIST_OPERATE_SPECIAL_DIFF_IN_PERIOD' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcOperateSpecialDiffInPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcOperateSpecialValueRetirementDate",
                            title: "{{'REPORTS_ASSET_LIST_OPERATE_SPECIAL_AT_RETIREMENT_DATE' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(CalcOperateSpecialValueRetirementDate || "", "' + $rootScope.dateFormat + '")#</div>'
                        },

                        {
                            field: "IsLimited",
                            title: "{{'REPORTS_ASSET_LIST_IS_LIMITTED' | translate}}"
                        },
                        {
                            field: "ValueDelta",
                            title: "{{'REPORTS_ASSET_LIST_VALUE_DELTA' | translate}}",
                            template: '<div class="text-right">{{ dataItem.ValueDelta || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "EconomicalUsefulLifeEndDate",
                            title: "{{'REPORTS_ASSET_LIST_ECONOMICAL_USEFULLIFE_ENDDATE' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(EconomicalUsefulLifeEndDate || "", "' + $rootScope.dateFormat + '")#</div>'
                        },
                        {
                            field: "FairValue",
                            title: "{{'REPORTS_ASSET_LIST_FAIRVALUE' | translate}}",
                            template: '<div class="text-right">{{ dataItem.FairValue || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "AssetShare",
                            title: "{{'REPORTS_ASSET_LIST_ASSETSHARE' | translate}}",
                            template: '<div class="text-right">{{ dataItem.AssetShare | cultureFormat }}%</div>'
                        },
                        {
                            field: "CalcAssetClass",
                            title: "{{'REPORTS_ASSET_LIST_ASSETCLASS' | translate}}"
                        },
                        {
                            field: "CalcAssetValueRevisionDifference",
                            title: "{{'REPORTS_ASSET_LIST_REVISION_DIFFERENCE' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcAssetValueRevisionDifference || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcSumAssetDepreciationPeriod",
                            title: "{{'REPORTS_ASSET_LIST_SUM_ASSET_DEPRECIATION_IN_PERIOD' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcSumAssetDeprecationPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcSumAssetComponentDepreciationPeriod",
                            title: "{{'REPORTS_ASSET_LIST_SUM_ASSET_COMPONENT_DEPRECIATION_IN_PERIOD' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcSumAssetComponentDeprecationPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcAssetComponentValueStartPeriod",
                            title: "{{'REPORTS_ASSET_LIST_DEPRECIATION_AT_START' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcAssetComponentValueStartPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcAssetComponentValueEndPeriod",
                            title: "{{'REPORTS_ASSET_LIST_DEPRECIATION_AT_END' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcAssetComponentValueEndPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcAssetComponentDiffInPeriod",
                            title: "{{'REPORTS_ASSET_LIST_DEPRECIATION_DIFF_IN_PERIOD' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcAssetComponentDiffInPeriod || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcAssetComponentValueRetirementDate",
                            title: "{{'REPORTS_ASSET_LIST_DEPRECIATION_RETIREMENT_DATE' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcAssetComponentValueRetirementDate || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "CalcUsefulLifeEndDate",
                            title: "{{'REPORTS_ASSET_LIST_USEFULLIFE_ENDDATE' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(CalcUsefulLifeEndDate || "", "' + $rootScope.dateFormat + '")#</div>'
                        },
                        {
                            field: "CalcUsefulLifeEndDay",
                            title: "{{'REPORTS_ASSET_LIST_USEFULLIFE_ENDDAY' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CalcUsefulLifeEndDay || 0 | cultureFormat }} {{ CurrencyCode }}</div>'
                        },
                        {
                            field: "EvaluationPeriodStart",
                            title: "{{'REPORTS_ASSET_LIST_PIRIOD_START' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(EvaluationPeriodStart || "", "' + $rootScope.dateFormat + '")#</div>'
                        },
                        {
                            field: "EvaluationPeriodEnd",
                            title: "{{'REPORTS_ASSET_LIST_PIRIOD_END' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(EvaluationPeriodEnd || "", "' + $rootScope.dateFormat + '")#</div>'
                        }
                    ]
                };
            };
        }
    ]);