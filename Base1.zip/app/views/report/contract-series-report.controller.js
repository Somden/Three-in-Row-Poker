﻿"use strict";

angular
    .module("LeadApp")
    .controller("ContractSeriesReportController", [
        "$scope", "$rootScope", "pageFactory", "reportContractSeriesValidator", "exportFactory", "kendoGridBuilder", "kendoDataSourceBuilder",
        function ($scope, $rootScope, pageFactory, reportContractSeriesValidator, exportFactory, kendoGridBuilder, kendoDataSourceBuilder) {
            pageFactory.setTitle("ITEM_SUB_REPORT_CONTRACT_SERIES_REPORT");
            var vm = this;

            (function initialize() {
                vm.reportConfig = {};
                vm.showGrid = false;
                vm.exportFactory = exportFactory;
                vm.validate = validate;

                vm.generateReport = generateReport;
                vm.getReportParameters = getReportParameters;

                initializeDropDowns();
            })();

            function validate() {
                var result = reportContractSeriesValidator.validate(vm.reportConfig);

                return result.isValid;
            };

            function getReportParameters() {
                var parameters = {
                    contractId: vm.reportConfig.selectedContract.Id,
                    revision: vm.reportConfig.revision.Revision,
                    accountingStandard: vm.reportConfig.accountingStandard.Value
                };

                if (angular.isDefined(vm.reportConfig.component) && vm.reportConfig.component != null && angular.isDefined(vm.reportConfig.component.ContractComponentId)) {
                    parameters.assetComponentId = vm.reportConfig.component.ContractComponentId;
                }

                return parameters;
            };

            function getReportUrl() {
                var parameters = getReportParameters();

                if (parameters.assetComponentId != null) {
                    return "/odata/ContractSeriesReport/Lead.GetComponentByRevision("
                            + "ContractId=" + parameters.contractId + ","
                            + "Revision=" + parameters.revision + ","
                            + "AccountingStandard='" + parameters.accountingStandard + "',"
                            + "AssetComponentId=" + parameters.assetComponentId
                        + ")";
                }
                else {
                    return "/odata/ContractSeriesReport/Lead.GetComponentByRevision("
                            + "ContractId=" + parameters.contractId + ","
                            + "Revision=" + parameters.revision + ","
                            + "AccountingStandard='" + parameters.accountingStandard + "',"
                            + "AssetComponentId=null"
                        + ")";
                }
            };

            function generateReport() {
                vm.showGrid = false;

                var options = {
                    preloadAllResults: true
                };

                kendoGridBuilder(
                    getReportUrl(),
                    "ContractSeriesReportView",
                    null,
                    null,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            vm.gridOptions = gridDefinition;
                            vm.showGrid = true;
                        });
                    }, options);
            };

            function initializeDropDowns() {
                vm.accountingStandardDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                    .whereEquals("EnumType", "AccountingStandardType");

                vm.reportConfig.accountingStandard = {
                    EnumType: "AccountingStandardType",
                    Value: "IFRS",
                };

                var previousFilterValue = null;
                vm.contractsDataSource = kendoDataSourceBuilder("/odata/Contract")
                    .withoutDeleted();

                $scope.$watch("vm.reportConfig.selectedContract", function () {
                    if (vm.reportConfig.selectedContract == null) return;

                    vm.componentDataSource = null;
                    vm.revisionDataSource = kendoDataSourceBuilder("/odata/ContractRevision?$expand=ContractRevisionState,ModificationType")
                        .withoutDeleted()
                        .whereEquals("Contract/Id", vm.reportConfig.selectedContract.Id);

                    vm.reportConfig.component = null;
                    vm._revisionFilterChanged();
                });

                $scope.$watch("vm.reportConfig.revision", vm._revisionFilterChanged = function () {
                    if (vm.reportConfig.revision == null) return;

                    vm.componentDataSource = kendoDataSourceBuilder("/odata/AssetComponent")
                        .withoutDeleted()
                        .whereEquals("Asset/RightOfUseAsset/ContractRevision/Contract/Id", vm.reportConfig.selectedContract.Id)
                        .whereEquals("Asset/RightOfUseAsset/ContractRevision/Revision", vm.reportConfig.revision.Revision);
                });
            }
        }
    ]);