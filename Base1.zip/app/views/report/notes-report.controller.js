﻿"use strict";

angular
    .module("LeadApp")
    .controller("NotesReportController", [
        "$scope", "$rootScope", "pageFactory", "$translate", "messageFactory", "notesReportValidator", "resourceFactory", "kendoDataSourceBuilder",
        function ($scope, $rootScope, pageFactory, $translate, messageFactory, notesReportValidator, resourceFactory, kendoDataSourceBuilder) {
            pageFactory.setTitle("REPORTS_NOTES_TITLE");
            $scope.showFormat = false;
            $scope.reportLoaded = false;
            $scope.kendoHelpers = $rootScope.kendoHelpers;
            $scope.showGrid = false;
            $scope.totalCount = 0;
            $scope.count = 0;
            $scope.reportConfig = {
                isShortTermLeaseFilter: false,
                isLowValueFilter: false
            };

            $scope.companyDataSource = kendoDataSourceBuilder("/odata/Company")
                .withoutDeleted();
            
            // ContractRevisionState an Feld binden

            $scope.reportLoaded = false;
            
            $scope.$watch("reportConfig", function validate() {
                if($scope.reportConfig == null) return;

                notesReportValidator.validate($scope.reportConfig);
            }, true);

            $scope.generateReport = function () {
                var loadingId = messageFactory.loadingMessage.show("LOADING_SERIES_REPORT");
                $scope.showGrid = false; // Hide the grid, so the grid will be reinitialized if it's already loaded
                resourceFactory
                    .notesReport($scope.reportConfig)
                    .getResults()
                    .$promise
                    .then(function (resp) {
                        var results = resp.value;
                        $scope.reportLoaded = results.length > 0;
                        initializeKendoGrid(results);
                    })
                    .catch(function (resp) {
                        console.log('error caught', resp);
                    })
                    .finally(function (a) {
                        messageFactory.loadingMessage.hide(loadingId);
                    });
            };

            var initializeKendoGrid = function (results) {
                $scope.showGrid = true;

                $scope.totalCount = results.length;

                $scope.gridOptions = {
                    dataSource:
                        {
                            data: results,
                            schema: {
                                model: {
                                    fields: {
                                        ContractId: { type: "number" },
                                        CompanyId: { type: "number" },
                                        ContractName: { type: "string" },
                                        StartDate: { type: "date" },
                                        EndDate: { type: "date" },
                                        ManagementUnit: { type: "number" },
                                        InterestShareInPeriod: { type: "number" },
                                        AllPaymentsInPeriod: { type: "number" },
                                        TotalLiability: { type: "number" },
                                        Liability_1Y: { type: "number" },
                                        Liability_5Y: { type: "number" },
                                        Liability_1YTo5Y: { type: "number" },
                                    }
                                }
                            },
                            pageSize: 50,
                            page: 1
                        },
                    sortable: true,
                    pageable: {
                        refresh: true,
                        buttonCount: 5,
                        pageSizes: [10, 20, 50],
                        messages: {
                            display: $translate.instant("KENDO_GRID_DISPLAY"),
                            empty: $translate.instant("KENDO_GRID_EMPTY"),
                            page: $translate.instant("KENDO_GRID_PAGE"),
                            allPages: $translate.instant("KENDO_GRID_ALLPAGES"),
                            of: $translate.instant("KENDO_GRID_OF"),
                            itemsPerPage: $translate.instant("KENDO_GRID_ITEMSPERPAGE"),
                            first: $translate.instant("KENDO_GRID_FIRST"),
                            previous: $translate.instant("KENDO_GRID_PREVIOUS"),
                            next: $translate.instant("KENDO_GRID_NEXT"),
                            last: $translate.instant("KENDO_GRID_LAST"),
                            refresh: $translate.instant("KENDO_GRID_REFRESH")
                        }
                    },
                    filterable: {
                        mode: "menu",
                        messages: {
                            info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                            isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                            isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                        }
                    },
                    scrollable: false,
                    columns: [
                        {
                            field: "ContractId",
                            title: "{{'REPORT_CONTRACT_LIST_CONTRACT_ID' | translate}}",
                            template: '<div class="text-right">{{ dataItem.ContractId }}</div>'
                        },
                        {
                            field: "CompanyId",
                            title: "{{'REPORT_CONTRACT_LIST_COMPANY_ID' | translate}}",
                            template: '<div class="text-right">{{ dataItem.CompanyId }}</div>'
                        },
                        {
                            field: "StartDate",
                            title: "{{'REPORT_CONTRACT_LIST_EVALUATION_START' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(StartDate || "", "' + $rootScope.dateFormat + '")#</div>'
                        },
                        {
                            field: "EndDate",
                            title: "{{'REPORT_CONTRACT_LIST_EVALUATION_END' | translate}}",
                            template: '<div class="text-right">#=renderDateTime(EndDate || "", "' + $rootScope.dateFormat + '")#</div>'
                        },
                        {
                            field: "ManagementUnit",
                            title: "{{'REPORT_CONTRACT_LIST_MANAGEMENT_UNIT' | translate}}"
                        },
                        {
                            field: "InterestShareInPeriod",
                            title: "{{'REPORT_CONTRACT_LIST_INTEREST_SHARE_IN_PERIOD' | translate}}",
                            template: '<div class="text-right">{{ dataItem.InterestShareInPeriod || 0 | cultureFormat }}%</div>'
                        },
                        {
                            field: "AllPaymentsInPeriod",
                            title: "{{'REPORT_CONTRACT_SUM_ALL_PAYMENTS' | translate}}",
                            template: '<div class="text-right">{{ dataItem.AllPaymentsInPeriod || 0 | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                        },
                        {
                            field: "Liability_1Y",
                            title: "{{'REPORT_CONTRACT_TOTAL_LIABILITY_FIRST_YEAR' | translate}}",
                            template: '<div class="text-right">{{ dataItem.Liability_1Y || 0 | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                        },
                        {
                            field: "Liability_5Y",
                            title: "{{'REPORT_CONTRACT_TOTAL_LIABILITY_LESS_THEN_FIVE_YEARS' | translate}}",
                            template: '<div class="text-right">{{ dataItem.Liability_5Y || 0 | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                        },
                        {
                            field: "Liability_1YTo5Y",
                            title: "{{'REPORT_CONTRACT_TOTAL_LIABILITY_MORE_THEN_FIVE_YEAR' | translate}}",
                            template: '<div class="text-right">{{ dataItem.Liability_1YTo5Y || 0 | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                        },
                        {
                            field: "TotalLiability",
                            title: "{{'REPORT_CONTRACT_TOTAL_LIABILITY' | translate}}",
                            template: '<div class="text-right">{{ dataItem.TotalLiability || 0 | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                        }
                    ]
                };
            };
        }
    ]);