﻿"use strict";

angular
	.module("LeadApp")
	.controller("ContractListReportController", [
		"$scope", "$rootScope", "$timeout", "pageFactory", "$translate", "messageFactory", "reportContractListValidator", "resourceFactory", "exportFactory", "kendoDataSourceBuilder","kendoGridBuilder",
		function ($scope, $rootScope, $timeout, pageFactory, $translate, messageFactory, reportContractListValidator, resourceFactory, exportFactory, kendoDataSourceBuilder,kendoGridBuilder) {
			pageFactory.setTitle("Contract List Report");

			$scope.totalCount = 0;
			$scope.count = 0;
			$scope.showFormat = false;

			$scope.kendoHelpers = $rootScope.kendoHelpers;
			$scope.exportFactory = exportFactory;
			$scope.showGrid = false;
			$scope.reportConfig = {};

			$scope.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();
			$scope.contractStateDataSource = [
				{ state: "" },
				{ state: "AllValid" },
				{ state: "ValidatedPending" },
				{ state: "Validated" },
				{ state: "Terminated" },
				{ state: "Completed" }
			];

			$scope.$watch("reportConfig", function validate() {
				if ($scope.reportConfig == null) return;

				reportContractListValidator.validate($scope.reportConfig);
			}, true);

			$scope.generateReport = function () {
				$scope.showGrid = false; // Hide the grid, so the grid will be reinitialized if it's already loaded

			    var options = {
			        preloadAllResults: true
			    };

			    kendoGridBuilder(
			        $scope.getReportUrl(),
			        "ContractListReport",
			        null,
			        null,
			        function (gridDefinition) {
			            $scope.$apply(function () {
			                $scope.gridOptions = gridDefinition;
			                $scope.showGrid = true;
			            });
			        }, options);
			};

			$scope.getReportParameters = function () {
				var parameters = {
					companyId: $scope.reportConfig.selectedCompany.Id,
					revisionState: $scope.reportConfig.contractState.state
				};

				if (angular.isDefined($scope.reportConfig.evaluationStart) && $scope.reportConfig.evaluationStart != null && angular.isDefined($scope.reportConfig.evaluationEnd) && $scope.reportConfig.evaluationEnd != null) {
					parameters.evaluationStart = $scope.reportConfig.evaluationStart.getFullYear() + "-" + ($scope.reportConfig.evaluationStart.getMonth() + 1) + "-" + $scope.reportConfig.evaluationStart.getDate();
					parameters.evaluationEnd = $scope.reportConfig.evaluationEnd.getFullYear() + "-" + ($scope.reportConfig.evaluationEnd.getMonth() + 1) + "-" + $scope.reportConfig.evaluationEnd.getDate();
				}

				return parameters;
			};

			$scope.getReportUrl = function () {
				var parameters = $scope.getReportParameters();

				if (parameters.evaluationStart != null && parameters.evaluationEnd != null) {
					return "/odata/ContractListReport/Lead.Get("
							+ "CompanyId=" + parameters.companyId + ","
							+ "RevisionState='" + parameters.revisionState + "',"
							+ "EvaluationStart='" + parameters.evaluationStart + "',"
							+ "EvaluationEnd='" + parameters.evaluationEnd + "'"
						+ ")";
				}
				else {
					return "/odata/ContractListReport/Lead.Get("
							+ "CompanyId=" + parameters.companyId + ","
							+ "RevisionState='" + parameters.revisionState + "',"
							+ "EvaluationStart=null,"
							+ "EvaluationEnd=null"
						+ ")";
				}
			};

			
		}
	]);