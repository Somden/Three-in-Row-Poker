﻿"use strict";

angular
    .module("LeadApp")
    .controller("PaymentRulesReportController", [
        "$scope", "$rootScope", "pageFactory", "exportFactory", "kendoGridBuilder", "kendoDataSourceBuilder",
        function ($scope, $rootScope, pageFactory, exportFactory, kendoGridBuilder, kendoDataSourceBuilder) {
            pageFactory.setTitle("REPORTING_PAYMENTRULES");

            $scope.companyDataSource = kendoDataSourceBuilder("/odata/Company").withoutDeleted();

            $scope.generateReport = generateReport;
            $scope.getReportParameters = getReportParameters;

            $scope.kendoHelpers = $rootScope.kendoHelpers;
            $scope.exportFactory = exportFactory;
            $scope.showGrid = false;
            $scope.reportConfig = {
                selectedCompany: null
            };

            function generateReport() {
                $scope.showGrid = false;

                kendoGridBuilder(
                    getReportUrl(),
                    "PaymentRulesReport",
                    null,
                    null,
                    function (gridDefinition) {
                        $scope.$apply(function () {
                            $scope.gridOptions = gridDefinition;
                            $scope.showGrid = true;
                        });
                    });
            };

            function getReportParameters() {
                return {
                    companyId: $scope.reportConfig.selectedCompany.Id
                };
            };

            function getReportUrl() {
                var parameters = $scope.getReportParameters();

                return "/odata/PaymentRulesReport?CompanyId=" + parameters.companyId;
            };
        }
    ]);