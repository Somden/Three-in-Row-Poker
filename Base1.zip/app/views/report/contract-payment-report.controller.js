﻿"use strict";

angular
    .module("LeadApp")
    .controller("ContractPaymentReportController", [
        "$scope", "$rootScope", "$timeout", "pageFactory", "$translate", "messageFactory", "reportContractPaymentValidator", "exportFactory", "kendoDataSourceBuilder",
        function ($scope, $rootScope, $timeout, pageFactory, $translate, messageFactory, reportContractPaymentValidator, exportFactory, kendoDataSourceBuilder) {
            var vm = this;

            (function initialize() {
                pageFactory.setTitle("Contract Payments Report");

                vm.exportFactory = exportFactory;
                vm.getReportParameters = getReportParameters;
                vm.generateReport = generateReport;

                vm.showGrid = false;
                vm.reportConfig = {};
                vm.gridOptions = null;

                initialiteDataSources();
            })();

            function initialiteDataSources() {
                var previousFilterValue = null;
                vm.contractsDataSource = kendoDataSourceBuilder("/odata/Contract").withoutDeleted();

                $scope.$watch("vm.reportConfig.selectedContract", function () {
                    if (vm.reportConfig.selectedContract == null) return;

                    vm.revisionDataSource = kendoDataSourceBuilder("/odata/ContractRevision?$expand=ModificationType,ContractRevisionState")
                        .withoutDeleted()
                        .whereEquals("Contract/Id", vm.reportConfig.selectedContract.Id);
                });
            }

            $scope.$watch("vm.reportConfig", function validate() {
                if (vm.reportConfig == null) return;

                reportContractPaymentValidator.validate(vm.reportConfig);
            }, true);

            function getReportParameters() {
                var parameters = {
                    contractId: vm.reportConfig.selectedContract.Id,
                    revision: vm.reportConfig.revision.Revision
                };

                return parameters;
            };

            function getReportUrl() {
                var parameters = vm.getReportParameters();

                return "/odata/ContractPaymentReport/Lead.GetByRevision("
                        + "ContractId=" + parameters.contractId + ","
                        + "Revision=" + parameters.revision
                    + ")";
            };

            function generateReport() {
                var tableWidth = 1210;
                var columnCount = 5;

                vm.showGrid = false; // Hide the grid, so the grid will be reinitialized if it's already loaded
                $timeout(function () {
                    var loadingId = messageFactory.loadingMessage.show("LOADING_SERIES_REPORT");
                    vm.showGrid = true;
                    vm.gridOptions = {
                        dataSource: new kendo.data.DataSource({
                            type: "odata-v4",
                            transport: {
                                read: {
                                    url: getReportUrl(),
                                    dataType: "json"
                                }
                            },
                            error: function (e) {
                                console.log(e.status + " : " + e.errorThrown);
                                messageFactory.loadingMessage.hide(loadingId, $rootScope);
                            },
                            requestEnd: function (e) {
                                messageFactory.loadingMessage.hide(loadingId, $rootScope);
                            },
                            schema: {
                                data: function (data) {
                                    return data.value;
                                },
                                total: function (data) {
                                    return data['@odata.count'];
                                },
                                model: {
                                    fields: {
                                        PaymentDate: { type: "date" },
                                        DaysFromStart: { type: "number" },
                                        NominalValue: { type: "number" },
                                        PresentValue: { type: "number" },
                                        PaymentType: { type: "text" }
                                    }
                                }
                            },
                            pageSize: 50,
                            page: 1,
                            serverPaging: true,
                            serverSorting: true,
                            serverFiltering: true,
                            serverAggregates: true,
                            serverGrouping: true
                        }),
                        sortable: true,
                        pageable: {
                            refresh: true,
                            buttonCount: 5,
                            pageSizes: [10, 20, 50],
                            messages: {
                                display: $translate.instant("KENDO_GRID_DISPLAY"),
                                empty: $translate.instant("KENDO_GRID_EMPTY"),
                                page: $translate.instant("KENDO_GRID_PAGE"),
                                allPages: $translate.instant("KENDO_GRID_ALLPAGES"),
                                of: $translate.instant("KENDO_GRID_OF"),
                                itemsPerPage: $translate.instant("KENDO_GRID_ITEMSPERPAGE"),
                                first: $translate.instant("KENDO_GRID_FIRST"),
                                previous: $translate.instant("KENDO_GRID_PREVIOUS"),
                                next: $translate.instant("KENDO_GRID_NEXT"),
                                last: $translate.instant("KENDO_GRID_LAST"),
                                refresh: $translate.instant("KENDO_GRID_REFRESH")
                            }
                        },
                        filterable: {
                            mode: "menu",
                            messages: {
                                info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                                isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                                isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                            }
                        },
                        scrollable: false,
                        columns: [
                            {
                                field: "PaymentDate",
                                width: tableWidth / columnCount,
                                title: "{{ 'REPORT_CONTRACT_PAYMENTS_PAYMENT_DATE' | translate }}",
                                template: '<div class="text-right">#=renderDateTime(PaymentDate, "' + $rootScope.dateFormat + '")#</div>'
                            },
                            {
                                field: "DaysFromStart",
                                width: tableWidth / columnCount,
                                title: "{{ 'REPORT_CONTRACT_PAYMENTS_DAYS_FROM_START' | translate }}",
                                template: '<div class="text-right">{{ dataItem.DaysFromStart | cultureFormat }}</div>'
                            },
                            {
                                field: "NominalValue",
                                width: tableWidth / columnCount,
                                title: "{{ 'REPORT_CONTRACT_PAYMENTS_NOMINAL_VALUE' | translate }}",
                                template: '<div class="text-right">{{ dataItem.NominalValue | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                            },
                            {
                                width: tableWidth / columnCount,
                                field: "PresentValue",
                                title: "{{ 'REPORT_CONTRACT_PAYMENTS_PRESENT_VALUE' | translate }}",
                                template: '<div class="text-right">{{ dataItem.PresentValue | cultureFormat }} {{ dataItem.CurrencyCode }}</div>'
                            },
                            {
                                field: "PaymentType",
                                width: tableWidth / columnCount,
                                title: "{{ 'REPORT_CONTRACT_PAYMENTS_DESCRIPTION' | translate }}",
                                template: '<span>{{dataItem.PaymentType | translate }}</span>'
                            }
                        ]
                    };
                }, 0);
            };
        }
    ]);