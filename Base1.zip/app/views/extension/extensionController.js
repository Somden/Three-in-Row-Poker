﻿"use strict";

angular
    .module("LeadApp")
    .controller("ExtensionController", [
        "$scope", "$routeParams", "pageFactory",
        function ($scope, $routeParams, pageFactory) {
            pageFactory.setTitle("");
            var extensionName = $routeParams.extensionName;
            var entityId = $routeParams.entityId;

            $scope.extensionName = extensionName;
            $scope.entityId = entityId;
        }
    ]);