﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "BUTTON_TOGGLE_HELP_TOOLTIPS",
        en: "Show help tooltips",
        de: "Hilfstooltips anzeigen"
    },
    {
        key: "MESSAGE_TOOLTIPS_ACTIVATED",
        en: "Go over the fields with your mouse to show help.",
        de: "Fahre mit der Maus über die Eingabefelder um Hilfe zu sehen"
    },

    {
        key: "HELPTEXT_ID",
        en: "This is an unique identifier for the contract",
        de: "Das ist eine eindeutige Id für den Vertrag"
    },
    {
        key: "HELPTEXT_CONTRACT_REVISION_REVISION",
        en: "The number of the current contract revision",
        de: "Die Revions-Nummer der aktuellen Vertragsrevision"
    },
    {
        key: "HELPTEXT_CONTRACT_REVISION_LEGAL_ENTITY",
        en: "Enter the assigned legal entity to the asset.",
        de: "Geben Sie die dem Vermögenswert zugeordnete juristische Person ein."
    },
    {
        key: "HELPTEXT_CONTRACT_REVISION_COST_CENTER",
        en: "Enter the 10-digit SAP cost center number for the appropriate asset. The cost center represents the location where costs are incurred (deduction for depreciation, expense for disposal etc.). The entry is obligatory for the correct posting reports.",
        de: "Tragen Sie die 10-stellige SAP-Kostenstellennummer zu der entsprechenden Anlage ein. Die Kostenstelle steht für den Ort der Kostenentstehung (AfA, Aufwand beim Abgang etc.) in der Kostenrechnung. Die Eingabe ist für die richtigen Verbuchungsreports zwingend."
    },
    {
        key: "HELPTEXT_CONTRACT_REVISION_PROFIT_CENTER",
        en: "Enter the 10-digit SAP profit center number for the appropriate asset. The entry is obligatory for the correct posting reports.",
        de: "Tragen Sie die 10-stellige SAP-Profitcenternummer zu der betroffenen Anlage ein. Eingabe ist für die richtigen Verbuchungsreports zwingend."
    },
    {
        key: "HELPTEXT_MANAGEMENT_UNIT",
        en: "Enter the two-digit SAP Management Unit identification.",
        de: "Tragen Sie die zweistellige Kennung der dem Vertrag zuzuordnenden SAP-Management-Unit ein."
    },
    {
        key: "HELPTEXT_NAME",
        en: "A short description for the contract",
        de: "Eine kurze Beschreibung des Vertrags"
    },
    {
        key: "HELPTEXT_CONTRACT_TYPE",
        en: "Select the contract type or your lease perspective.",
        de: "Wählen Sie die Vertragsart/ Vertragsperspektive."
    },
    {
        key: "HELPTEXT_CURRENCY",
        en: "Select a currency for this contract",
        de: "Wählen Sie eine Währung für diesen Vertrag"
    },
    {
        key: "HELPTEXT_COMPANY",
        en: "Company code the contract is allocated to. When creating a user it will automatically get assigned to a company.",
        de: "Buchungskreis dem der Vertrag zuzuordnen ist. Mit der Anlage des Benutzers wird diesem automatisch ein Buchungskreis zugewiesen.",
    },
    {
        key: "HELPTEXT_PARTNER",
        en: "Select the contract partner representing the contracting party of the lease contract. The contractual partners can be entered under the main menu tab “Partners” tab in the main menu, and can then be selected from this field.",
        de: "Auswahl des Vertragspartners, welcher die Kontraktpartei des Leasingvertrags darstellt. Die Vertragspartner werden über den Hauptmenüpunkt Partner zuerst angelegt und können dann in diesem Feld ausgewählt werden."
    },
    {
        key: "HELPTEXT_CONCLUSION_DATE",
        en: "Enter the contractually defined date of the end of usage of the leased asset (excluded extension or termination options). If there is no end of use defined in the contract, the end of the use is to be estimated.",
        de: "Tragen Sie den vertraglich definierten Zeitpunkt des Nutzungsendes des Leasingobjekts ein (Datum). Dieser berücksichtigt keine Verlängerungs- oder Kürzungsoptionen. Sollte ein Vertrag kein festgeschriebenes Nutzungsende beinhalten, ist ein etwaiges Nutzungsende zu schätzen."
    },
    {
        key: "HELPTEXT_COMMENCEMENT_DATE",
        en: "Enter the contractual defined commencement date (initial date of usage of the right-of-use-asset). If the contract does not include a commencement date, this is to be defined by the actual commencement date (e.g. takeover of a store for use or expiration of a deadline after signing). The commencement date defines the starting point for the amortization and the calculation of the present value.",
        de: "Tragen Sie den vertraglich definierten Zeitpunkt des Nutzungsbeginns des Leasingobjekts als Datum ein. Ist dieser nicht vertraglich festgeschrieben ist auf den tatsächlichen Nutzungsbeginn abzuzielen (z.B. Übernahme der Filiale zur Nutzung oder Ablauf einer gewissen Frist nach der Unterzeichnung). Das Datum des Nutzungsbeginns markiert den Tag auf den die Leasingverbindlichkeit berechnet wird und die Abschreibung beginnt."
    },
    {
        key: "HELPTEXT_IS_INTERNAL_CONTRACT",
        en: "Choose whether this is an internal contract or not",
        de: "Wählen Sie, ob dies ein interner Vertrag ist oder nicht."
    },
    {
        key: "HELPTEXT_IS_LIMITED",
        en: "Is the contract limited?",
        de: "Ist der Vertrag limitiert?"
    },
    {
        key: "HELPTEXT_EXTERNAL_CONTRACT",
        en: "Reference to an external contract",
        de: "Referenz zu einem externen Vertrag"
    },
    {
        key: "HELPTEXT_ACCOUNTING_STANDARD_IFRS",
        en: "Choose a leasing type for IFRS to enable IFRS as an accounting standard",
        de: "Wählen einen Leasingtyp für IFRS, um IFRS als Bilanzierungsnorm zu aktivieren"
    },
    {
        key: "HELPTEXT_ACCOUNTING_STANDARD_USGAAP",
        en: "Choose a leasing type for US-GAAP to enable US-GAAP as an accounting standard",
        de: "Wähle einen Leasingtyp für US-GAAP, um US-GAAP als Bilanzierungsnorm zu aktivieren"
    },
    {
        key: "HELPTEXT_REVISION_REVISION_DESCRIPTION",
        en: "Describe this revision",
        de: "Beschreibe diese Revision"
    },
    {
        key: "HELPTEXT_REVISION_END_OF_LEASETERM",
        en: "Enter the contractually defined date of the end of usage of the leased asset (excluded extension or termination options). If there is no end of use defined in the contract, the end of the use is to be estimated.",
        de: "Tragen Sie den vertraglich definierten Zeitpunkt des Nutzungsendes des Leasingobjekts ein (Datum). Dieser berücksichtigt keine Verlängerungs- oder Kürzungsoptionen. Sollte ein Vertrag kein festgeschriebenes Nutzungsende beinhalten, ist ein etwaiges Nutzungsende zu schätzen."
    },
    {
        key: "HELPTEXT_REVISION_INTEREST_RATE",
        en: "The interest rate implicit in the lease is the discounting rate, which corresponds to the expected return of the lessor. If this interest rate is indicated in the contract, its use is mandatory and it has to be entered in this field.",
        de: "Der Grenzfremdkapitalzinssatz des Leasingnehmers ist der Zinssatz, den der Leasingnehmer bei einer fiktiven Fremdfinanzierung mit gleicher Betragshöhe und gleicher Laufzeit anzunehmen hätte. Ist im Vertrag kein impliziter Zinssatz angeführt, so ist der Grenzfremdkapitalzinssatz zu verwenden. Die zu verwendenden Grenzfremdkapitalzinssätze werden durch IFA bekannt gegeben."
    },
    {
        key: "HELPTEXT_REVISION_ACTIVATE_DATE",
        en: "The date this revision should be activated. In the initial revision, this is the same as the commencement date.",
        de: "Der Tag an dem diese Revision aktiv werden soll. In der initialen Revision ist es gleich dem Abschlussdatum."
    },
    {
        key: "HELPTEXT_PAYMENT_PAYMENT_START_DATE",
        en: "Enter the maturity date of the initial fixed or quasi fixed lease rate. This date (day) determines the monthly payment maturity in the subsequent period.",
        de: "Geben Sie hier das Datum ein, an dem die erste monatlich fixe bzw. quasi-fixe Leasingrate fällig wird. Der Tag der Zahlung markiert das regelmäßige Zahlungsdatum in der Folgezeit (15.1., 15.2., 15.3. usw.)."
    },

    {
        key: "HELPTEXT_ROU_CONTRACT_INITIATION_COSTS",
        en: "Enter the amount of initial direct costs accrued in the course of concluding the contract.",
        de: "Geben Sie hier die anfänglichen direkten Kosten, die mit der Vertragsschließung einhergehen, ein. Diese fallen vor dem eigentlichen Nutzungsbeginn an."
    },
    {
        key: "HELPTEXT_ROU_CONTRACT_INITIATION_COSTS_PAYMENT_DATE",
        en: "Enter the date when the option has to be paid. The payment date is for informative purposes.",
        de: "Tragen Sie den Zeitpunkt der Zahlung der Option ein. Das Zahlungsdatum ist für informative Zwecke."
    },
    {
        key: "HELPTEXT_ROU_OTHER_INITIAL_COSTS",
        en: "Payments made by the lessee before the initial date of the lease are classified as additional acquisition costs added to the right-of-use-asset.",
        de: "Vor dem Nutzungsbeginn durch den Leasingnehmer geleistete Zahlungen sind als zusätzliche Anschaffungskosten im Nutzungsrecht zu erfassen."
    },
    {
        key: "HELPTEXT_ROU_OTHER_INITIAL_COSTS_PAYMENT_DATE",
        en: "Enter the payment date. The payment date is for informative purposes.",
        de: "Tragen Sie den Zeitpunkt der Begleichung sonstiger Zahlungen ein. Das Zahlungsdatum ist für informative Zwecke."
    },
    {
        key: "HELPTEXT_ROU_GRANTS",
        en: "Enter the amount of government grants received.",
        de: "Tragen Sie den Betrag der erhaltenen öffentlichen Zuwendungen ein, falls solche Zuschüsse erhalten wurden."
    },
    {
        key: "HELPTEXT_ROU_GRANTS_PAYMENT_DATE",
        en: "Enter the payment date of the government grants. The payment date is for informative purposes",
        de: "Tragen Sie den Zeitpunkt der Zahlung der öffentlichen Zuwendungen ein. Das Zahlungsdatum ist für informative Zwecke."
    },
    {
        key: "HELPTEXT_ROU_LEASE_INCENTIVES_RECEIVED_AMOUNT",
        en: "Lease incentives given to a lessee by a lessor before the initial date of a lease relationship, reduce the acquisition costs of the right-of-use asset. Enter the amount of the incentives received.",
        de: "Anreizleistungen, die der Leasingnehmer vor oder zu Beginn des Leasingverhältnisses erhält, reduzieren die Anschaffungskosten des Nutzungsrechts. Tragen Sie sofern existent den Betrag der erhaltenen  Anreize ein."
    },
    {
        key: "HELPTEXT_ROU_LEASE_INCENTIVES_RECEIVED_AMOUNT_DATE",
        en: "Enter the payment date. The payment date is for informative purposes",
        de: "Tragen Sie den Zeitpunkt der Zahlung ein. Das Zahlungsdatum ist für informative Zwecke."
    },
    {
        key: "HELPTEXT_ASSET_NAME",
        en: "The name for the asset",
        de: "Ein Name für den Vermögenswert"
    },
    {
        key: "HELPTEXT_ASSET_DEFAULT_ASSET_CLASS",
        en: "The default asset class for this asset",
        de: "Die Standard Vermögenswert Klasse für diesen Vermögenswert"
    },
    {
        key: "HELPTEXT_ASSET_DESCRIPTION",
        en: "A description for this asset",
        de: "Eine Beschreibung für den Vermögenswert"
    },
    {
        key: "HELPTEXT_ASSET_NUMBER",
        en: "An optional SAP number for this asset",
        de: "Eine optionale SAP Nummer für diesen Vermögenswert"
    },
    {
        key: "HELPTEXT_ASSET_SUB_NUMBER",
        en: "An optional SAP subnumber for this asset",
        de: "Eine optionale SAP Unternummer für diesen Vermögenswert"
    },

    {
        key: "HELPTEXT_ASSET_COMPONENT_NAME",
        en: "The name for the asset component",
        de: "Ein Name für die Vermögenswert-Komponente"
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_IS_LIMITED",
        en: "Whether the asset component is limited or not",
        de: "Ob die Vermögenswert-Komponente limitiert ist oder nicht"
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_VALUE_DELTA",
        en: "", // TODO: Fill with helptext
        de: ""
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_ECONOMICAL_USEFUL_LIFE_ENDDATE",
        en: "", // TODO: Fill with helptext
        de: ""
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_FAIR_VALUE",
        en: "", // TODO: Fill with helptext
        de: ""
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_ASSET_SHARE",
        en: "", // TODO: Fill with helptext
        de: ""
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_AMOUNT_CHANGE",
        en: "", // TODO: Fill with helptext
        de: ""
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_ASSET_CLASS",
        en: "", // TODO: Fill with helptext
        de: ""
    },

    {
        key: "HELPTEXT_LEASING_PERIOD_START_DATE",
        en: "The start date of the contract leasing period is the same as the commencement date of the contract",
        de: "Das Startdatum der Leasingperiode ist das gleiche wie das Abschlussdatums des Vertrags"
    },
    {
        key: "HELPTEXT_LEASING_PERIOD_END_DATE",
        en: "When should the initial contract leasing period end?",
        de: "Wann soll die Haupt-Leasingperiode enden?"
    },
    {
        key: "HELPTEXT_LEASING_PERIOD_DURATION",
        en: "Define how long the initial leasing period should last",
        de: "Bestimmen Sie die Dauer der ersten Leasingperiode"
    },
    {
        key: "HELPTEXT_LEASING_PERIOD_EXECUTION_VALUE",
        en: "Enter a value if the execution of the initial leasing period is bound to a value",
        de: "Wenn die Ausübung der ersten Leasing Periode an einen Barwert gebunden sein soll, dann geben Sie hier diesen Wert ein"
    },
    {
        key: "HELPTEXT_LEASING_PERIOD_EXECUTION_DATE",
        en: "If you entered an execution value, then define the date of payment for this value",
        de: "Wenn Sie einen Ausübungspreis haben, dann geben Sie an, wann dieser gezahlt werden soll"
    },
    {
        key: "HELPTEXT_TERMINATION_OPTION_DURATION",
        en: "Define how many months this termination option should reduce the contract",
        de: "Geben Sie hier an um wie viel Monate die Verkürzungsoption den Vertrag verkürzen soll"
    },
    {
        key: "HELPTEXT_HAS_TERMINATION_OPTION",
        en: "Enable this to be able to configure an option for terminating the contract earlier",
        de: "Wenn Sie das aktivieren, dann können Sie die Verkürzungsoption konfigurieren, mit der der Vertrag frühzeitig beendet werden kann"
    },
    {
        key: "HELPTEXT_TERMINATION_EXECUTION_VALUE",
        en: "How much should be payed to execute the termination option?",
        de: "Wieviel muss gezahlt werden, damit die Verkürzungsoption ausgeübt werden kann?"
    },
    {
        key: "HELPTEXT_TERMINATION_EXECUTION_DATE",
        en: "When should the execution value be paid?",
        de: "Wann soll die Gebühr für die Verkürzung gezahlt werden?"
    },
    {
        key: "HELPTEXT_TERMINATION_IS_EXPECTED_EXECUTED",
        en: "Tick this if the termination option will be executed",
        de: "Haken Sie diese Option an, falls sie angewandt wird."
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_DESCRIPTION",
        en: "Describe the payment rule. By default, an auto-description will be generated.",
        de: "Beschreiben Sie hier die Zahlungsregel. Standardmäßig wird eine Beschreibung automatisch generiert."
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_PAYMENT_INTERVAL",
        en: "Define in what interval the payment should be executed",
        de: "Definieren Sie, in welchem Intervall die Zahlung erfolgen soll."
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_PAYMENT_FREQUENCY",
        en: "This is a multiplier for the interval. E.g. an interval monthly with frequency 2 means: Payment every 2 months.",
        de: "Die Frequenz multipliziert das Intervall. Z.B. bedeuteutet ein monatliches Intervall mit Frequenz 2: Zahlung alle 2 Monate."
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_PAYMENT_START_DATE",
        en: "When should the payment/s start?",
        de: "Wann soll/en die Zahlung/en starten?"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_PAYMENT_END_DATE",
        en: "When should the payment/s end?",
        de: "Wann soll/en die Zahlung/en enden?"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_PAYMENT_VALUE",
        en: "The payment value that will be paid",
        de: "Der Zahlungsbetrag der bei jedem Mal gezahlt werden soll."
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_IN_SUBSTANCE_PAYMENT_VALUE",
        en: "This value will be added to the payment value",
        de: "Dieser Wert wird auf den Zahlungsbetrag draufgerechnet"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_INDEXED_BASED",
        en: "Mark this payment as an index-based payment",
        de: "Diese Zahlung als indexbasiert markieren"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_SCALING_ENABLED",
        en: "Enable this to let the payment value scale up over time",
        de: "Aktivieren Sie dies, wenn die Zahlung mit der Zeit nach oben skalieren soll"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_SCALING_FREQUENCY",
        en: "How often should the payment be scaled up? This frequency needs to be the same or a multiple of the payment frequency",
        de: "Wie oft soll der Zahlungsbetrag erhöht werden? Es muss genauso oder ein Vielfaches sein wie die Zahlungsfrequenz"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_ABSOLUTE_SCALING_VALUE",
        en: "The amount that will be added to the payment value every time",
        de: "Der Betrag der jedes Mal zum Zahlungsbetrag dazugerechnet wird"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_PERCENTAGE_SCALING_VALUE",
        en: "The payment value will be scaled up every time with this percentage",
        de: "Der Zahlungsbetrag wird jedes Mal um diesen prozentualen Wert erhöht"
    },
    {
        key: "HELPTEXT_PAYMENT_RULE_HAS_SCALING_IN_PERCENTAGE",
        en: "Click this to switch between an absolute value and a percentual value for scaling up",
        de: "Klicken Sie hier um zwischen der Erhöhung um einen absoluten Wert und einem prozentualen Wert zu tauschen"
    },

    {
        key: "HELPTEXT_REVISION_IS_LOW_VALUE",
        en: "Low Value",
        de: "Geringwertausnahme"
    },
    {
        key: "HELPTEXT_REVISION_IS_SHORT_TERM_LEASE",
        en: "Short Term Lease",
        de: "Kurzfristausnahme"
    },
    {
        key: "HELPTEXT_REVISION_TRANSFER_OF_OWNERSHIP",
        en: "Transfer of ownership",
        de: "Automatischer Eigentumsübergang"
    },
    {
        key: "HELPTEXT_REVISION_RESIDUAL_VALUE",
        en: "Guaranteed residual value",
        de: "Restwert"
    },
    {
        key: "HELPTEXT_REVISION_RESIDUAL_DATE",
        en: "Payment date for residual value",
        de: "Zahlungsdatum für den Restwert"
    },
    {
        key: "HELPTEXT_REVISION_PURCHASE_OPTION_ISEXECUTED",
        en: "Is executed",
        de: "Ausübung"
    },
    {
        key: "HELPTEXT_REVISION_PURCHASE_OPTION_PAYMENTDATE",
        en: "Payment date",
        de: "Datum"
    },
    {
        key: "HELPTEXT_REVISION_PURCHASE_OPTION_PAYMENTVALUE",
        en: "Value",
        de: "Betrag"
    },
    {
        key: "HELPTEXT_COMPLETE_CONTRACT_DESCRIPTION",
        en: "", // TODO: ...
        de: "" // TODO: ...
    },

    {
        key: "HELPTEXT_TERMINATE_CONTRACT_DESCRIPTION",
        en: "", // TODO: ...
        de: "" // TODO: ...
    },
    {
        key: "HELPTEXT_CONTRACT_TERMINATION_OPTION_END_DATE",
        en: "", // TODO: ...
        de: "" // TODO: ...
    },
    {
        key: "HELPTEXT_ROU_RESTORATION_VALUE",
        en: "", // TODO: ...
        de: "" // TODO: ...
    },
    {
        key: "HELPTEXT_ROU_RESTORATION_VALUE_DATE",
        en: "", // TODO: ...
        de: "" // TODO: ...
    },
    {
        key: "HELPTEXT_ASSET_COMPONENT_SAP_BOOKING_STATE",
        en: "", // TODO: ...
        de: "" // TODO: ...
    },
    {
        key: "HELPTEXT_LEASING_PERIOD_IS_EXPECTED_EXECUTED",
        en: "", // TODO: ...
        de: "" // TODO: ...
    }            
]);