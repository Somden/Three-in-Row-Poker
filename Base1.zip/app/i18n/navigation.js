﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ITEM_MAIN_CONTRACTS",
        en: "Contracts",
        de: "Verträge"
    },
    {
        key: "ITEM_MAIN_REPORTS",
        en: "Reports",
        de: "Reports"
    },
    {
        key: "ITEM_MAIN_SETTINGS",
        en: "Settings",
        de: "Einstellungen"
    },
    {
        key: "ITEM_MAIN_BASE_DATA",
        en: "Base Data",
        de: "Stammdaten"
    },
    {
        key: "ITEM_SUB_CONTRACTS_ALL",
        en: "All Contracts",
        de: "Alle Verträge"
    },
    {
        key: "ITEM_SUB_CONTRACTS_TEMPLATES",
        en: "All Templates",
        de: "Alle Vorlagen"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_COMPANIES",
        en: "Companies",
        de: "Buchungskreise"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_COMPANIES_ARCHIVED",
        en: "Archived Companies",
        de: "Archivierte Buchungskreise"
    },
    {
        key: "ITEM_SUB_REPORT_CONTRACT_OVERVIEW_REPORT",
        en: "Contract Overview Report",
        de: "Vertragsübersicht Report"
    },
    {
        key: "ITEM_SUB_REPORT_CONTRACT_SERIES_REPORT",
        en: "Contract Series Report",
        de: "Vertragsserien Report"
    },
    {
        key: "ITEM_SUB_REPORT_CONTRACT_PAYMENTS_REPORT",
        en: "Contract Payments Report",
        de: "Vertragszahlungen Report"
    },
    {
        key: "ITEM_SUB_REPORT_CONTRACT_LIST_REPORT",
        en: "Contract List Report",
        de: "Vertragslisten Report"
    },
    {
        key: "ITEM_SUB_REPORT_COMPANY_SUMMARY_REPORT",
        en: "Company Summary Report",
        de: "Unternehmenszusammenfassung Report"
    },
    {
        key: "ITEM_SUB_REPORT_ABATEMENT_REPORT",
        en: "Abatement Report",
        de: "Minderungen Report"
    },
    {
        key: "ITEM_SUB_REPORT_PAYMENTRULES_REPORT",
        en: "Paymentrules Report",
        de: "Zahlungsregeln Report"
    },
    {
        key: "ITEM_SUB_REPORT_ABAO_TOOLKIT_REPORT",
        en: "ABAO Toolkit Report",
        de: "ABAO Toolkit Report"
    },
    {
        key: "ITEM_SUB_REPORT_ASSET_LIST_REPORT",
        en: "Asset List Report",
        de: "Asset List Report"
    },
    {
        key: "ITEM_SUB_REPORT_NOTES_REPORT",
        en: "Notes Report",
        de: "Anhangangaben Report"
    },
    {
        key: "ITEM_SUB_REPORT_EXPORT_LOG_REPORT",
        en: "Export Logs Report",
        de: "Protokoll Exportieren Report"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_USERS",
        en: "Users",
        de: "Benutzer"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_USERS_ARCHIVED",
        en: "Archived Users",
        de: "Archivierte Benutzer"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_PARTNERS",
        en: "Partner",
        de: "Partner",
    },
    {
        key: "ITEM_SUB_CONFIGURATION_PARTNERS_ARCHIVED",
        en: "Archived Partner",
        de: "Archivierte Partner",
    },
    {
        key: "ITEM_SUB_BASEDATA_CURRENCY",
        en: "Currency",
        de: "Währung",
    },
    {
        key: "ITEM_SUB_BASEDATA_ASSETCLASS",
        en: "AssetClass",
        de: "Anlagenklassen"
    },
    {
        key: "ITEM_SUB_BASEDATA_LEDGER",
        en: "Ledger",
        de: "Konten"
    },
    {
        key: "ITEM_SUB_BASEDATA_LEDGERASSOCIATION",
        en: "Ledger Association",
        de: "Kontozuordnungen"
    },
    {
        key: "ITEM_SUB_CHANGE_PASSWORD",
        en: "Change password",
        de: "Passwort ändern"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_CONTRACTLOCKDATESETTINGS",
        en: "Contract lock date settings",
        de: "Contract lock date settings"
    },
    {
        key: "ITEM_SUB_REPORT_BOOKING_ENTIRES_REPORT",
        en: "Booking Entries Report",
        de: "Buchungssätze Report",
    },
    {
        key: "ITEM_SUB_REPORT_BOOKING_ENTIRES_MONTHLY_REPORT",
        en: "Monthly Booking Entries Report",
        de: "Monatlicher Buchungssätze Report",
    },
    {
        key: "ITEM_SUB_REPORT_BOOKING_ENTIRES_QUARTERLY_REPORT",
        en: "Quarterly Booking Entries Report",
        de: "Quartalsweiser Buchungssätze Report",
    },
    {
        key: "ITEM_SUB_REPORT_BOOKING_ENTIRES_YEARLY_REPORT",
        en: "Yearly Booking Entries Report",
        de: "Jährlicher Buchungssätze Report",
    },
    {
        key: "ITEM_SUB_REPORT_CONTRACT_BOOKING_OVERALL",
        en: "Contracts Controlling Booking Overall",
        de: "Verträge Controlling Buchung Insgesamt",
    }
]);