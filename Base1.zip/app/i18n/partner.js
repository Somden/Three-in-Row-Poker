﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_PARTNER_DETAILS",
        en: "Partner Details",
        de: "Partner Details"
    },

    {
        key: "LOADING_PARTNER",
        en: "Loading Partner",
        de: "Partner wird geladen"
    },
    {
        key: "LOADING_PARTNERS",
        en: "Partner will be loaded",
        de: "Partner werden geladen"
    },
    {
        key: "LOADING_SAVING_PARTNER",
        en: "Saving Partner",
        de: "Partner wird gespeichert"
    },
    {
        key: "LOADING_REMOVING_PARTNER",
        en: "Removing Partner",
        de: "Partner wird entfernt"
    },

    {
        key: "BUTTON_NEW_PARTNER",
        en: "Add new Partner",
        de: "Partner hinzufügen"
    },

    {
        key: "MESSAGE_PARTNER_SAVED",
        en: "Partner saved",
        de: "Partner gespeichert"
    },
    {
        key: "MESSAGE_PARTNER_REMOVED",
        en: "Partner removed",
        de: "Partner entfernt"
    },
    {
        key: "MESSAGE_PARTNER_IS_DELETED",
        en: "This partner is marked as deleted. You can not modify it and you can not choose it in contracts. But it will stay visible in contracts that have this partner selected.",
        de: "Dieser Partner ist als gelöscht markiert. Es kann weder editiert werden, noch kann es in Verträgen gewählt werden. Es bleibt aber sichtbar in Verträgen, die diesen Partner bereits gewählt haben."
    },

    {
        key: "TABLE_PARTNERS_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_PARTNERS_PARTNER_CODE",
        en: "Code",
        de: "Code"
    },
    {
        key: "TABLE_PARTNERS_NAME",
        en: "Partner",
        de: "Partner"
    },
    {
        key: "TABLE_PARTNERS_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "TABLE_PARTNERS_PARTNERCODE",
        en: "Partner Code",
        de: "Buchungskreis"
    },
    {
        key: "TABLE_PARTNERS_ISACTIVE",
        en: "Is Active",
        de: "Ist Aktiv"
    },
     {
         key: "TABLE_PARTNERS_COMPANYNAME",
         en: "Company",
         de: "Firma"
     },
     {
         key: "TABLE_PARTNERS_CONTACT",
         en: "Contact",
         de: "Kontakt"
     },
       
    {
        key: "FORM_PARTNER_CODE",
        en: "Partner Code",
        de: "Buchungskreis"
    },
    {
        key: "FORM_PARTNER_COMPANYNAME",
        en: "Company",
        de: "Firma"
    },
    {
        key: "FORM_PARTNER_STREET",
        en: "Street",
        de: "Straße"
    },
    {
        key: "FORM_PARTNER_STREETNUMBER",
        en: "Streetnumber",
        de: "Haus Nr."
    },
    {
        key: "FORM_PARTNER_POSTALCODE",
        en: "Postal Code",
        de: "PLZ."
    },
    {
        key: "FORM_PARTNER_TOWN",
        en: "Town",
        de: "Ort"
    },
   
    {
        key: "TABLE_PARTNERS_EXTERNAL_ID",
        en:"Partner nr.",
        de:"Partnernummer"
    }
]);