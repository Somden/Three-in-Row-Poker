﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ITEM_SUB_BASEDATA_LEDGERASSOCIATIONS_ARCHIVED",
        en: "Archived Ledger Associations",
        de: "Archivierte Kontozuordnungen"
    },
    {
        key: "ITEM_SUB_BASEDATA_LEDGERASSOCIATIONS",
        en: "Ledger Associations",
        de: "Kontozuordnungen"
    },
    {
        key: "TABLE_LEDGERASSOCIATION_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_LEGERASSOCIATION_DESCRIPTION",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "TABLE_LEDGERTYPE_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "TABLE_COMPANY_COMPANYCODE",
        en: "Company code",
        de: "Buchungskreiscode"
    },
    {
        key: "TABLE_ASSETCLASS_NAME",
        en: "Asset class",
        de: "Anlagenklassen"
    },
    {
        key: "TITLE_LEDGERASSOCIATION_DETAILS",
        en: "Ledger association details",
        de: "Kontozuordnungsdetails"
    },
    {
        key: "LOADING_LEDGERASSOCIATION",
        en: "Loading ledger association details",
        de: "Lädt Kontozuordnungsdetails"
    },
    {
        key: "LOADING_SAVING_LEDGERASSOCIATION",
        en: "Saving ledger association",
        de: "Speichert Kontozuordnung"
    },
    {
        key: "MESSAGE_LEDGERASSOCIATION_SAVED",
        en: "Ledger association saved",
        de: "Kontozuordnung gespeichert"
    },
    {
        key: "LOADING_REMOVING_LEDGERASSOCIATION",
        en: "Removing ledger association",
        de: "Kontozuordnung wird entfernt"
    },
    {
        key: "MESSAGE_LEDGERASSOCIATION_REMOVED",
        en: "Ledger association removed",
        de: "Kontozuordnung entfernt"
    },
    {
        key: "MESSAGE_COULD_NOT_SAVE_LEDGERASSOCIATION",
        en: "Ledger association could not be saved",
        de: "Kontozuordnung konnte nicht gespeichert werden"
    },
    {
        key: "MESSAGE_LEDGERASSOCIATION_IS_DELETED",
        en: "Ledger association is deleted",
        de: "Kontozuordnung ist gelöscht"
    },
    {
        key: "VALIDATION_LEDGER_ASSOCIATION_COMPANY_REQUIRED",
        en: "The choosen ledger type requires a company.",
        de: "Der gewählte Kontotyp erfordert einen Buchungskreis."
    },
    {
        key: "VALIDATION_LEDGER_ASSOCIATION_ASSET_CLASS_REQUIRED",
        en: "The choosen ledger type requires an asset class.",
        de: "Der gewählte Kontotyp erfordert eine Assetklasse."
    },
    {
        key: "FORM_LEDGERTYPE",
        en: "Ledger type",
        de: "Kontotyp"
    },
    {
        key: "FORM_LEDGER",
        en: "Ledger",
        de: "Konto"
    },
    {
        key: "FORM_DESCRIPTION",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "FORM_COMPANY",
        en: "Company",
        de: "Buchungskreis"
    },
    {
        key: "FORM_ASSETCLASS",
        en: "Asset class",
        de: "Assetklasse"
    },
    {
        key: "LEDGERASSOCIATION_UNIQUE_CONSTRAINT_VIOLATION",
        en: "There is already a ledger association with your choosen ledger type, company and asset class.\nThe combination of ledger type, company and asset class must be unique.",
        de: "Es liegt bereits eine Kontozuordnung mit ihrem gewählen Kontotyp, Buchungskreis und Assetklasse vor.\nDie Kombination aus Kontotyp, Buchungskreis und Assetklasse darf nur einmal vorkommen."
    }
]);