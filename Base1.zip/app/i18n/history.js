﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ITEM_SUB_CONFIGURATION_HISTORY",
        en: "History",
        de: "Historie"
    },
    {
        key: "LOADING_HISTORY",
        en: "Loading History",
        de: "Historie wird geladen"
    },
    {
        key: "TABLE_HISTORY_ID",
        en: "Id",
        de: "id"
    },
    {
        key: "TABLE_HISOTRY_TIMESTAMP",
        en: "ChangedDate",
        de: "Änderungsdatum"
    },
    {
        key: "TABLE_HISOTRY_CHANGES",
        en: "Changes",
        de: "Änderungen"
    },
    {
        key: "TABLE_HISTORY_OBJECTNAME",
        en:"Type of Item",
        de:"Eintragstyp"
    },
    {
        key: "TABLE_HISTORY_OBJECTID",
        en: "Item ID",
        de: "Eintragsid"
    },
    {
        key: "TABLE_HISOTRY_ACTION",
        en:"Action",
        de:"Aktion"
    },
    {
        key:"TABLE_HISTORY_LOGGER",
        en:"User",
        de:"Benutzer"
    },
    {
        key: "TABLE_HISOTRY_DELETED",
        en:"Deleted",
        de:"gelöscht"
    },
    {
        key: "TABLE_HISOTRY_EMPTY",
        en: "Empty",
        de: "k.a"
    },

]);