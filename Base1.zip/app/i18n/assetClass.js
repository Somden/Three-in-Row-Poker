﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_ASSETCLASS_DETAILS",
        en: "AssetClass Details",
        de: "Assetklasse Details"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_ASSETCLASS",
        en: "Asset Classes",
        de: "Assetklassen"
    },
      {
          key: "ITEM_SUB_ASSETCLASS_NUMBER",
          en: "Numbers",
          de: "Nummer"
      },
    {
        key: "ITEM_SUB_CONFIGURATION_ASSETCLASS_ARCHIVED",
        en: "Archived Asset Classes",
        de: "Archivierte Assetklassen"
    },
    {
        key: "BUTTON_NEW_ASSETCLASS",
        en: "Add new AssetClass",
        de: "Assetklasse hinzufügen"
    },

    {
        key: "LOADING_ASSETCLASS",
        en: "AssetClass will be loaded",
        de: "Assetklassen werden geladen"
    },
    {
        key: "LOADING_SAVING_ASSETCLASS",
        en: "Saving Assetclass",
        de: "Assetklasse wird gespeichert"
    },
    {
        key: "LOADING_REMOVING_ASSETCLASS",
        en: "Removing asset class",
        de: "Assetklasse wird entfernt"
    },

    {
        key: "TABLE_ASSETCLASS_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_ASSETCLASS_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "TABLE_ASSETCLASS_COMPANY",
        en: "Company name",
        de: "Buchungskreisname"
    },
    {
        key: "MESSAGE_ASSETCLASS_SAVED",
        en: "Assetclass saved",
        de: "Assetklasse gespeichert"
    },
    {
        key: "MESSAGE_ASSETCLASS_REMOVED",
        en: "Assetclass will removed",
        de: "Assetklasse entfernt"
    },
    {
        key: "MESSAGE_ASSET_CLASS_IS_DELETED",
        en: "This asset class is marked as deleted. You can not modify it and you can not choose it in contracts. But it will stay visible in contracts that have this asset class selected.",
        de: "Diese Asset-Klasse ist als gelöscht markiert. Sie kann weder editiert werden, noch kann es in Verträgen gewählt werden. Sie bleibt aber sichtbar in Verträgen, die diese Assetklasse bereits gewählt haben."
    },
    {
        key: "FORM_ASSET_CLASS_EXTERNAL_ID",
        en: "Object-Type ID",
        de: "Objekt-Typ ID"
    }

    
]);