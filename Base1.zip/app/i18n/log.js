﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ITEM_SUB_CONFIGURATION_LOG",
        en: "Logs",
        de: "Logs"
    },
    {
        key: "LOADING_LOGS",
        en: "Loading Logs",
        de: "Logging-Informationen werden geladen"
    },
    {
        key: "TABLE_LOG_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_LOG_TIMESTAMP",
        en: "TimeStamp",
        de: "Datum"
    },
    {
        key: "TABLE_LOG_MESSAGE",
        en: "Message",
        de: "Eintrag"
    },
    {
        key: "TABLE_LOG_LEVEL",
        en: "Loglevel",
        de: "Loglevel"
    },
    {
        key: "TABLE_LOG_LOGGER",
        en: "Logger",
        de: "Quelle"
    }
]);