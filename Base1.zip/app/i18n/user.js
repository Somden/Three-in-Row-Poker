﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_USER_DETAILS",
        en: "User Details",
        de: "Benutzer Details"
    },

    {
        key: "LOADING_USERS",
        en: "Loading users",
        de: "Benutzer werden geladen"
    },
    {
        key: "LOADING_USER",
        en: "Loading user",
        de: "Benutzer wird geladen"
    },
    {
        key: "LOADING_SAVING_USER",
        en: "Saving user",
        de: "Benutzer wird gespeichert"
    },
    {
        key: "LOADING_REMOVING_USER",
        en: "Removing user",
        de: "Benutzer wird entfernt"
    },

    {
        key: "MESSAGE_USER_SAVED",
        en: "User saved",
        de: "Benutzer gespeichert"
    },
    {
        key: "MESSAGE_USER_REMOVED",
        en: "User removed",
        de: "Benutzer wurde entfernt"
    },
    {
        key: "MESSAGE_USER_IS_DELETED",
        en: "This user is marked as deleted. You can not modify it and you can not choose it in contracts. But it will stay visible in contracts that have this user selected.",
        de: "Dieser user ist als gelöscht markiert. Er kann weder editiert werden, noch kann er in Verträgen gewählt werden. Er bleibt aber sichtbar in Verträgen, die diesen bereits gewählt haben."
    },

    {
        key: "INFO_COMPANIES_EMPTY",
        en: "Add companies to give this user access to contracts.",
        de: "Füge Unternehmen hinzu um diesem Benutzer Zugriff auf Verträge zu gewähren."
    },

    {
        key: "BUTTON_NEW_USER",
        en: "Add new user",
        de: "Neuen Benutzer anlegen"
    },

    {
        key: "FORM_HEADER_CONTRACT_COMPANY_PERMISSIONS",
        en: "User can see all contracts of following companies",
        de: "Benutzer kann die Verträge folgender Buchungskreise sehen"
    },

    {
        key: "TABLE_USERS_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_USERS_FIRST_NAME",
        en: "First Name",
        de: "Vorname"
    },
    {
        key: "TABLE_USERS_LAST_NAME",
        en: "Last Name",
        de: "Nachname"
    },
    {
        key: "TABLE_USERS_DOMAIN_NAME",
        en: "Domain Name",
        de: "Domain Name"
    },

    {
        key: "TABLE_USERS_FIRST_NAME",
        en: "First Name",
        de: "Vorname"
    },
    {
        key: "TABLE_USERS_LAST_NAME",
        en: "Last Name",
        de: "Nachname"
    },

    {
        key: "FORM_IS_ADMIN",
        en: "Administrator",
        de: "Administrator"
    },
    {
        key: "FORM_FIRST_NAME",
        en: "First Name",
        de: "Vorname"
    },
    {
        key: "FORM_LAST_NAME",
        en: "Last Name",
        de: "Nachname"
    },
    {
        key: "FORM_DOMAIN_NAME",
        en: "Domain Name",
        de: "Domain Name"
    },
    {
        key: "FORM_ADD_PERMISSIONS",
        en: "Add new permissions",
        de: "Neue Berechtigungen hinzufügen"
    },
    {
        key: "FORM_COMPANY_TO_ADD",
        en: "Select a company",
        de: "Wähle ein Unternehmen"
    },

    {
        key: "FORM_COMPANY_PERMISSIONS_IS_NOT_ACTIVE",
        en: "not active",
        de: "nicht aktiv"
    },
    {
        key: "FORM_COMPANY_PERMISSIONS_CAN_MODIFY",
        en: "Can manage contracts",
        de: "Darf Verträge verwalten"
    },
    {
        key: "FORM_USER_ENTER_CURRENT_PASSWORD",
        en: "Enter your current password",
        de: "Geben Sie ihr aktuelles Passwort ein"
    },
    {
        key: "FORM_USER_ENTER_NEW_PASSWORD",
        en: "Set a new password",
        de: "Neues Passwort setzen"
    },
    {
        key: "FORM_USER_CURRENT_PASSWORD",
        en: "Your current password",
        de: "Ihr aktuelles Passwort"
    },
    {
        key: "FORM_USER_NEW_PASSWORD",
        en: "New password",
        de: "Neues Passwort"
    },
    {
        key: "FORM_USER_REPEAT_NEW_PASSWORD",
        en: "Confirm new password",
        de: "Bestätigung neues Passwort"
    },
    {
        key: "BUTTON_SET_NEW_PASSWORD",
        en: "Set new password",
        de: "Neues Passwort setzen"
    },
    {
        key: "MESSAGE_PASSWORD_CHANGED",
        en: "Password successfully changed",
        de: "Passwort wurde geändert"
    },
    {
        key: "MESSAGE_PASSWORD_CHANGED_ERROR",
        en: "Password could not be changed",
        de: "Passwort konnte nicht geändert werden"
    },
    {
        key: "FORM_USER_PASSWORD_CHANGE_FIRST_LOGIN_TOOLTIP",
        en: "When logging in the first time you need to change your password",
        de: "Bei der erstmaligen Anmeldung müssen Sie ein neues Passwort festlegen"
    },
    {
        key: "FORM_USER_PASSWORD_RULE_NOT_SAME_TOOLTIP",
        en: "The new password must be different from the old one",
        de: "Das neue Passwort muss sich vom alten unterscheiden"
    },
    {
        key: "FORM_USER_PASSWORD_RULE_CONFIRM",
        en: "Enter the new password again",
        de: "Geben Sie das neue Passwort erneut ein"
    },
    {
        key: "FORM_USER_PASSWORD_POLICY",
        en: "The following password policy rules apply:",
        de: "Für das Passwort gelten folgende Regeeln:"
    },
    {
        key: "FORM_USER_PASSWORD_POLICY1",
        en: "- A minimum of 12 characters",
        de: "- Mindestens 12 Zeichen"
    },
    {
        key: "FORM_USER_PASSWORD_POLICY2",
        en: "- One uppercase character, one lowercase, one number, one special character",
        de: "- Ein Großbuchstabe, ein Kleinbuchstabe, eine Zahl, ein Sonderzeichen"
    },
]);