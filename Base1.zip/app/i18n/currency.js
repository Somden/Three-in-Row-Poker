﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "TITLE_CURRENCY_DETAILS",
        en: "Currency Details",
        de: "Währung Details"
    },
    {
        key: "LOADING_CURRENCY",
        en: "Loading Currency",
        de: "Währung wird geladen"
    },
    {
        key: "LOADING_SAVING_CURRENCY",
        en: "Saving currency",
        de: "währung wird gespeichert"
    },
    {
        key: "MESSAGE_CURRENCY_SAVED",
        en: "Currency saved",
        de: "Währung gespeichert"
    },
    {
        key: "MESSAGE_COULD_NOT_SAVE_CURRENCY",
        en: "Currency could not be saved",
        de: "Währung konnte nicht gespeichert werden"
    },
    {
        key: "BUTTON_NEW_CURRENCY",
        en: "Add new Currency",
        de: "Währung hinzufügen"
    },
    {
        key: "ITEM_SUB_BASEDATA_CURRENCIES",
        en: "Currencies",
        de: "Währungen"
    },
    {
        key: "ITEM_SUB_BASEDATA_CURRENCIES_ARCHIVED",
        en: "Archived Currencies",
        de: "Archivierte Währungen"
    },
    {
        key: "TABLE_CURRENCIES_ID",
        en: "Id",
        de: "Id"
    }
    ,
    {
        key: "TABLE_CURRENCIES_CODE",
        en: "Code",
        de: "Code"
    }
    ,
    {
        key: "TABLE_CURRENCIES_NAME",
        en: "Name",
        de: "Name"
    }
    ,
    {
        key: "TABLE_CURRENCIES_ISACTIVE",
        en: "Is Active",
        de: "Ist Aktiv"
    },
    {
        key:"LOADING_CURRENCIES",
        en: "Currencies will be loaded",
        de: "Währungen werden geladen"
    },

    {
        key: "MESSAGE_CURRENCY_REMOVED",
        en: "Currency removed",
        de: "Währung entfernt"
    },
    {
        key: "MESSAGE_CURRENCY_IS_DELETED",
        en: "This currency is marked as deleted. You can not modify it and you can not choose it in contracts. But it will stay visible in contracts that have this currency selected.",
        de: "Diese Währung ist als gelöscht markiert. Sie kann weder editiert werden, noch kann sie in Verträgen gewählt werden. Sie bleibt aber sichtbar in Verträgen, die diese Währung bereits gewählt haben."
    }
]);