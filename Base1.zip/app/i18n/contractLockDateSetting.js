﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ITEM_SUB_CONFIGURATION_CONTRACTLOCKDATESETTINGS_ARCHIVED",
        en: "Archived contract lock date settings",
        de: "Archived contract lock date settings"
    },
    {
        key: "ITEM_SUB_CONFIGURATION_CONTRACTLOCKDATESETTINGS",
        en: "Contract lock date settings",
        de: "Contract lock date settings"
    }, 
    {
        key: "TABLE_CONTRACTLOCKDATESETTINGS_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_CONTRACTLOCKDATESETTINGS_LOCKINGDATE",
        en: "Locking date",
        de: "Locking date"
    },
    {
        key: "TABLE_CONTRACTLOCKDATESETTINGS_COMPANYNAME",
        en: "Company name",
        de: "Company name"
    },



    {
        key: "TABLE_SETTINGS_LOCKDATE",
        en: "Contracts Lock date",
        de: "Contracts Lock date"
    },
    {
        key: "TITLE_CONTRACTLOCKDATESETTINGS_DETAILS",
        en: "Settings Details",
        de: "Settings Details"
    },

    {
        key: "LOADING_CONTRACTLOCKDATESETTINGS",
        en: "Loading Settings",
        de: "Loading Settings"
    },
    {
        key: "LOADING_CONTRACTLOCKDATESETTINGS",
        en: "Settings will be loaded",
        de: "Settings will be loaded"
    },
    {
        key: "LOADING_SAVING_CONTRACTLOCKDATESETTINGS",
        en: "Saving setting",
        de: "Saving setting"
    },
    {
        key: "LOADING_REMOVING_CONTRACTLOCKDATESETTINGS",
        en: "Removing setting",
        de: "Removing setting"
    },

    {
        key: "BUTTON_NEW_CONTRACTLOCKDATESETTINGS",
        en: "Add new setting",
        de: "Add new setting"
    },

    {
        key: "MESSAGE_CONTRACTLOCKDATESETTINGS_SAVED",
        en: "Setting saved",
        de: "Setting saved"
    },
    {
        key: "MESSAGE_CONTRACTLOCKDATESETTINGS_REMOVED",
        en: "Setting removed",
        de: "Setting removed"
    },
    {
        key: "MESSAGE_CONTRACTLOCKDATESETTINGS_IS_DELETED",
        en: "This setting is marked as deleted.",
        de: "This setting is marked as deleted"
    },

]);