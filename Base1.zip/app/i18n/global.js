﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "BOOLEAN_TRUE",
        en: "Yes",
        de: "Ja"
    },
    {
        key: "BOOLEAN_FALSE",
        en: "No",
        de: "Nein"
    },

    {
        key: "BUTTON_LANG",
        en: "Language",
        de: "Sprache"
    },
    {
        key: "BUTTON_CANCEL",
        en: "Cancel",
        de: "Abbrechen"
    },
    {
        key: "BUTTON_OK",
        en: "Ok",
        de: "Ok"
    },
    {
        key: "BUTTON_SAVE",
        en: "Save",
        de: "Speichern"
    },
    {
        key: "BUTTON_ADD",
        en: "Add",
        de: "Hinzufügen"
    },
    {
        key: "BUTTON_DELETE",
        en: "Delete",
        de: "Entfernen"
    },
    {
        key: "BUTTON_EDIT",
        en: "Edit",
        de: "Bearbeiten"
    },
    {
        key: "BUTTON_UPDATE",
        en: "Update",
        de: "Aktualisieren"
    },
    {
        key: "BUTTON_UNDO",
        en: "Restore",
        de: "Wiederherstellen"
    },
    {
        key: "BUTTON_LOAD_RESULTS",
        en: "Load Results",
        de: "Ergebnisse laden"
    },
    {
        key: "BUTTON_NEW",
        en: "New",
        de: "Neu"
    },

    {
        key: "MESSAGE_CHANGED_LANGUAGE",
        en: "New language saved in your user settings",
        de: "Eine neue Sprache wurde in deinen Einstellungen gespeichert"
    },
    {
        key: "MESSAGE_REQUEST_ERROR",
        en: "Request failed!",
        de: "Request fehlgeschlagen!"
    },
    {
        key: "MESSAGE_REQUEST_401",
        en: "You are not authorized. Please reload the page.",
        de: "Du scheinst nicht eingeloggt zu sein. Bitte lade die Seite neu."
    },
    {
        key: "MESSAGE_COULD_NOT_SAVE",
        en: "Could not be saved",
        de: "Es konnte nicht gespeichert werden"
    },

    {
        key: "LOADING",
        en: "Loading",
        de: "Wird Geladen"
    },
    {
        key: "LOADING_USER_SETTINGS",
        en: "Loading User Settings",
        de: "Benutzereinstellungen werden geladen"
    },
    {
        key: "LOADING_EXTENSION",
        en: "Loading extension",
        de: "Erweiterung wird geladen"
    },

	{
	    key: "FORM_ID",
	    en: "Id",
	    de: "Id"
	},
	{
	    key: "FORM_NAME",
	    en: "Name",
	    de: "Name"
	},
    {
        key: "FORM_CONTRACT_REVISION_NAVIGATOR",
        en: "Select Contract Revision",
        de: "Vertragsrevision auswählen"
    },
    {
        key: "FORM_IS_ACTIVE",
        en: "Is active",
        de: "Ist aktiv"
    },

    {
        key: "USER_PROFILE",
        en: "Settings",
        de: "Einstellungen"
    },
    {
        key: "USER_CHANGE_PASSWORD",
        en: "Change Password",
        de: "Passwort ändern"
    },
    {
        key: "USER_ACCOUNT_MANAGEMENT",
        en: "Account Management",
        de: "Account Management"
    },
    {
        key: "USER_EXPORT_OVERVIEW",
        en: "Export Overview",
        de: "Export Übersicht"
    },
    {
        key: "USER_LOGOUT",
        en: "Sign Out",
        de: "Abmelden"
    },

	{
	    key: "SHOW_MORE",
	    en: "Show more...",
	    de: "Mehr..."
	},
	{
	    key: "DISABLE",
	    en: "disable",
	    de: "deaktivieren"
	},

	{
	    key: "MONTHS",
	    en: "Months",
	    de: "Monate"
	},
	{
	    key: "YEARS",
	    en: "Years",
	    de: "Jahre"
	},
	{
	    key: "STARTING_AT",
	    en: "Beginning at",
	    de: "Ab dem"
	},
	{
	    key: "FROM",
	    en: "From",
	    de: "Von"
	},
	{
	    key: "TO",
	    en: "to",
	    de: "bis"
	},
	{
	    key: "FOR",
	    en: "for",
	    de: "für"
	},
	{
	    key: "AT",
	    en: "at",
	    de: "am"
	},
	{
	    key: "EVERY",
	    en: "Every",
	    de: "Alle"
	},

    {
        key: "COMPANY",
        en: "Company",
        de: "Buchungskreis"
    },

    {
        key: "ERROR_MISSING_CONTRACT_RIGHT_READ",
        en: "You are missing the right to read contracts from the contracts company",
        de: "Dir fehlt das Recht zum Lesen für den Buchungskreis dieses Vertrages",
    },
    {
        key: "ERROR_MISSING_CONTRACT_RIGHT_UPDATE",
        en: "You are missing the right to update contracts from the contracts company",
        de: "Dir fehlt das Recht zum Ändern für den Buchungskreis dieses Vertrages",
    },
    {
        key: "ERROR_MISSING_CONTRACT_RIGHT_DELETE",
        en: "You are missing the right to delete contracts from the contracts company",
        de: "Dir fehlt das Recht zum Löschen für den Buchungskreis dieses Vertrages",
    },
    {
        key: "ERROR_MISSING_CONTRACT_RIGHT_CREATE",
        en: "You are missing the right to create contracts from the contracts company",
        de: "Dir fehlt das Recht zum Anlegen für den Buchungskreis dieses Vertrages",
    },
    {
        key: "ERROR_MISSING_RIGHT_READ",
        en: "not enough rights to call this action",
        de: "Du hast nicht genug Rechte, um diese Aktion aufzurufen",
    },
    {
        key: "ERROR_UNTRANSLATED_ERROR_MESSAGE",
        en: "Untranslated error message",
        de: "Unübersetzte Fehlermeldung",
    },

    {
        key: "FORM_COMPANY",
        en: "Company",
        de: "Buchungskreis"
    },

    {
        key: "FORM_CONTRACT_SEARCH_COMMENTS",
        en: "Search for comments...",
        de: "Suche nach Kommentaren..."
    },
    {
        key: "FORM_CONTRACT_SEARCH_TEXT",
        en: "Search...",
        de: "Textsuche..."
    },
    {
        key: "FORM_CONTRACT_SEARCH_COMMENTS_SEARCH_WHILE_TYPING",
        en: "Search while typing",
        de: "Während dem Tippen suchen"
    },
    {
        key: "FORM_CONTRACT_SEARCH_COMMENTS_PRESS_ENTER_TO_SEARCH",
        en: "Press enter to search",
        de: "Enter drücken zum Suchen"
    },

    {
        key: "TABLE_TOTAL",
        en: "Total",
        de: "Gesamt"
    },
    {
        key: "TABLE_EXPORT",
        en: "Export",
        de: "Exportieren"
    },
    {
        key: "TABLE_NUMBER",
        en: "Number",
        de: "Nummer"
    }
]);