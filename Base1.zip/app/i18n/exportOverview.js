﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_EXPORT_OVERVIEW",
        en: "Export Overview",
        de: "Export Übersicht"
    },
]);