﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_CONTRACT_REVISION_REVISION_DESCRIPTION_REQUIRED",
        en: "Revision description must not be empty",
        de: "Beschreibung der Revision darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REVISION_POSITIVE",
        en: "Revision number must be positive",
        de: "Die Revisionsnumemr muss positiv sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_INITIAL_ACTIVATE_DATE_NOT_EQUALS_COMMENCEMENT_DATE",
        en: "Activation Date of initial contract revision must be equal to commencement date",
        de: "Aktivierungsdatum muss in der initialen Revision gleich dem Abschlussdatum des Vertrags sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_NONINITIAL_ACTIVATE_DATE_EARLIER_COMMENCEMENT_DATE",
        en: "Activation Date must be higher as commencement date for reassment/modification revision",
        de: "Aktivierungsdatum muss größer sein als das Abschlussdatum der vorigen Revision"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REVISION_ZERO_FOR_INITIAL_ELSE_POSITIVE",
        en: "Initial revisions must have revision number 0, all other must be positive",
        de: "Die initiale Revision muss Revisons-Nummer 0 haben und alle weiteren müssen positiv sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_TERMINATED_OR_COMPLETED_NEEDS_RETIREMENT_DATE",
        en: "Retirement Date must set for revision state 'terminated'/'completed' else the date must be null",
        de: "Wenn die Revision terminiert or abgeschlossen werden soll, wird ein 'RetirementDate' benötigt"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_RESIDUAL_VALUE_MUST_BE_SET_IF_RESIDUAL_DATE_SET",
        en: "Residual value must be positive if residual date is set or zero if residual date is null",
        de: "Wenn das Datum des Restwerts gesetzt ist, dann muss auch der Restwert gesetzt und positiv sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_INTEREST_RATE_BETWEEN_ZERO_AND_ONE",
        en: "Interest rate must be between 0-1 if interest rate should be used, else zero",
        de: "Wenn angegeben wurde, dass eine Zinsrate benutzt werden soll, dann muss sie zwischen 0 und 1 liegen. Ansonsten soll sie bei 0 liegen."
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_INCREMENTAL_BORROWING_RATE_BETWEEN_ZERO_AND_ONE_IF_NO_INTEREST_RATE",
        en: "Incremental borrowing rate must be between 0-1 if interest rate should not be used, else zero",
        de: "Wenn angegeben wurde, dass KEIN Zinsrate benutzt werden soll, dann muss der Grenzfremdkapitalzinssatz zwischen 0 und 1 liegen. Ansonsten soll er bei 0 liegen."
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_PURCHASE_OPTION_MAX_ONE",
        en: "Only zero or one purchase options can be active",
        de: "Es kann maximal eine Kaufoption aktiv sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_PURCHASE_OPTION_DATES_MUST_BE_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "All purchase option dates must be higher than activate date of the reassessment/modification or if new the commencement date",
        de: "Das Datum der Kaufoption muss später sein als der Beginn des Vertrages oder im Falle eines Reassessments des Neubeurteilungsdatums"

    },
    {
        key: "VALIDATION_CONTRACT_REVISION_LESSEE_NEEDS_ROU_ASSET",
        en: "With contract type lessee, RoU asset needs to be set. Template contracts may have empty RoU Asset",
        de: "In Verträgen für Leasingnehmer muss ein Right of Use Asset existieren. Für Vorlagen kann dieser auch leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_LESSOR_NO_ROU_ASSET",
        en: "RoU Asset must be empty if lessor",
        de: "In Verträgen für Leasinggeber darf es kein Right of Use Asset geben"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_RESIDUAL_DATE_MUST_BE_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "Residual date must be higher than activate date of the reassessment/modification or if new the commencement date",
        de: "Das Datum der Restwertgarantie muss später sein als der Beginn des Vertrages oder im Falle eines Reassessments des Neubeurteilungsdatums"

    },
    {
        key: "VALIDATION_CONTRACT_REVISION_TEMPLATE_CONTRACT_NOT_PENDING",
        en: "Template contracts must remain in status 'pending'",
        de: "Vertragsvorlagen müssen im Status 'pending' bleiben"

    },
    {
        key: "VALIDATION_CONTRACT_REVISION_RETIREMENT_DATE_MUST_BE_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "Retirement date of terminated contract must be higher than activation date of revision",
        de: "Abgangsdatum eines terminierten Vertrages muß größer sein als das Aktivierungsdatum"

    },
    {
        key: "VALIDATION_CONTRACT_REVISION_MODIFICATION_TYPE_REASSESSMENTS_AMOUNT_CHANGE_NOT_ONE",
        en: "Having a reassessment the amount change for each asset component must be 1",
        de: "Bei Reassessments muss die Nutzungsänderung jeder Asset Komponente 1 betragen"
    },
]);