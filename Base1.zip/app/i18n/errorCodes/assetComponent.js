﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_SUM_OF_ASSET_SHARE_MUST_BE_100",
        en: "Sum of asset shares of all asset components must be 100%",
        de: "Die Summe aller Anteile der Asset Komponenten muss 100% ergeben"
    },
    {
        key: "VALIDATION_ASSET_ASSET_COMPONENTS_NOT_EMPTY",
        en: "Each assets needs asset components",
        de: "jedes Assets braucht Asset Komponenten"
    },
    {
        key: "VALIDATION_ASSET_COMPONENT_NAME_NOT_UNIQUE",
        en: "Name of asset component must be unique",
        de: "Der Name der Asset Komponente darf nur einmal vorkommen"
    }
]);