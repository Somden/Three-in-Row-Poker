﻿if (translations == null) {
	var translations = [];
}

translations = translations.concat([
	{
		key: "VALIDATION_PAYMENT_RULE_SCALING_CONFIG_WRONG",
		en: "Scaling-configuration of a payment rule is wrong",
		de: "Die Skalierung-Konfiguration einer Zahlungsregel stimmt nicht"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_SCALING_FREQUENCY_MUST_BE_MULTIPLE_OF_PAYMENT_FREQUENCY",
		en: "The scaling frequency needs to be a multiple of the payment frequency",
		de: "Die Skalierungsfrequenz muss ein Vielfaches der Zahlungsfrequenz sein"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_FREQUENCY_CANT_BE_NEGATIVE",
		en: "The payment frequency must not be negative",
		de: "Die Zahlungsfrequenz darf nicht negativ sein"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_VALUE_MUST_BE_SET",
		en: "The payment value needs to be set and positive",
		de: "Der Zahlungswert muss gesetzt sein und positiv"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_FREQUENCY_MUST_BE_POSITIVE",
		en: "Payment frequency needs to be bigger than zero",
		de: "Die Zahlungsfrequenz muss größer sein al Null"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_IF_ONCE_PAYMENT_START_MUST_EQUAL_END",
		en: "If payment is just once, then payment start and end needs to be the same",
		de: "Bei einer Einmalzahlung müssen Zahlungsstart und Ende gleich sein"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_PAYMENT_INTERVAL_MUST_BE_SET",
		en: "A payment interval needs to be set",
		de: "Ein Zahlungsintervall ist nötig"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_PAYMENT_STARTDATE_MUST_BE_NOT_BIGGER_THAN_PAYMENT_END_DATE",
		en: "The payment start date can't be bigger than the payment end date",
		de: "Das Startdatum einer Zahlungsregel kann nicht größer sein als das Enddatum"
	},
	{
		key: "VALIDATION_CONTRACT_PAYMENT_RULE_STARTDATE_MUST_BE_BIGGER_THAN_CONTRACT_COMMENCEMENT_DATE",
		en: "The payment start date must be bigger than the contract commencement date",
		de: "Das Startdatum einer Zahlungsregel muss größer sein als das Startdatum"
	},
	{
		key: "VALIDATION_CONTRACT_PAYMENT_RULE_STARTDATE_MUST_BE_BIGGER_THAN_ACTIVATE_DATE",
		en: "The payment start date must be bigger than the activation date",
		de: "Das Startdatum einer Zahlungsregel muss größer sein als das Aktivierungsdatum"
	},
	{
		key: "VALIDATION_CONTRACT_PAYMENT_RULE_STARTDATE_MUST_BE_BIGGER_THAN_LEASING_PERIOD_START_DATE",
		en: "The payment start date must be bigger than the leasing period start date",
		de: "Das Startdatum einer Zahlungsregel muss größer sein als das Startdatum der Leasingsperiode"
	},
	{
		key: "VALIDATION_FRONTEND_PAYMENT_END_MUST_BE_AFTER_START",
		en: "Must be later than start date",
		de: "Muss nach Startdatum liegen"
	},
	{
		key: "VALIDATION_MUST_BE_MULTIPLE_OF_INTERVAL",
		en: "Must be be a multiple of payment interval",
		de: "Muss Vielfaches des Zahlungsintervals sein"
	},
	{
		key: "VALIDATION_PAYMENT_RULE_PAYMENT_STARTDATE_MUST_BE_NOT_BIGGER_THAN_LEASING_PERIOD_START_DATE",
		en: "The payment start date can't be bigger than the leasing period start date",
		de: "Das Startdatum der Zahlung darf nicht größer sein als das Startdatum der Leasingperiode"
	}
]);