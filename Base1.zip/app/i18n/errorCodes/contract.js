﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_CONTRACT_USER_REQUIRED",
        en: "User must not be empty",
        de: "Benutzer darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_NAME_REQUIRED",
        en: "Name must not be empty",
        de: "Name darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_COMPANY_REQUIRED",
        en: "Company must not be empty",
        de: "Buchungskreis darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_COMMENCEMENT_DATE_REQUIRED",
        en: "Commencement date must not be empty",
        de: "Beginn des Leasingverhältnisses darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_CURRENCY_REQUIRED",
        en: "Currency must not be empty",
        de: "Währung darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_NAME_STRING_NOT_ALLOWED",
        en: "The contract name contains letters that are not allowed",
        de: "Der Vertragsname enthält Zeichen die nicht erlaubt sind"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_ACTIVATE_DATES_HIGHER_COMMENCEMENT_DATE",
        en: "All activate dates of revision must be higher or equal than commencement date",
        de: "Das Aktivierungsdatum aller Revisionen muss zeitgleich oder weiter in der Zukunft sein als das Beginndatum des Vertrags"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REVISION_UNIQUE",
        en: "There are two or more revisions with the same revisionnumber",
        de: "Es gibt zwei oder mehr Revisionen mit der gleichen Revisionsnummer"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_ACTIVATION_DATES_ORDER",
        en: "The activation date of a revision must be higher than the one of the revision before",
        de: "Das Aktivierungsdatum einer Revision muss größer sein als das der vorigen Revision"
    },

    {
        key: "VALIDATION_CONTRACT_CONTRACT_STATE_REQUIRED",
        en: "Contract state must not be empty",
        de: "Vertragsstatus darf nicht leer sein"
    },
    {
        key: "VALIDATION_CONTRACT_CONTRACT_TYPE_REQUIRED",
        en: "Contract type must not be empty",
        de: "Vertragsart darf nicht leer sein"
    },
    {
        key: "VALIDATION_AT_LEAST_ONE_ACCOUNTING_STANDARD",
        en: "Activate at least one accounting standard",
        de: "Aktiviere mindestens eines der Rechnungsstandards"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_END_DATE_MUST_BE_BIGGER_THAN_COMMENCEMENT_DATE",
        en: "Let this be bigger than the start date",
        de: "Das Enddatum sollte nach dem Startdatum liegen"
    }
]);