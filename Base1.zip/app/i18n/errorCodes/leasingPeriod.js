﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_LEASING_PERIOD_REQUIRED",
        en: "The contract leasing period needs to be set",
        de: "Für den Vertrag muss eine Leasing Periode gesetzt sein"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_MUST_BE_EXPECTED_TO_BE_EXECUTED",
        en: "Contract leasing period must be always expected to be executed",
        de: "Die Standard Leasing Periode für den Vertrag muss immer eine erwartete Ausführung haben"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_UNLIMITED_CONTRACTS_DONT_HAVE_EXTENSION_PERIODS",
        en: "No extension periods allowed for unlimited contracts",
        de: "Unlimitierte Verträge können keine Erweiterungsperiode enthalten"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_END_DATES_OF_LEASING_PERIODS_MUST_BE_HIGHER_THAN_COMMENCEMENT_DATES",
        en: "All end dates of leasing periods must be higher than commencement date",
        de: "Das Enddatum aller Leasing Perioden muss später sein als das Abschlussdatum der Vertrags und aller Revisionen"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_EXTENSION_LEASING_PERIODS_HAVE_GAPS_IN_EXPECTED_EXECUTION_FLAGS",
        en: "Extension leasing periods have gaps in expected execution flags",
        de: "Die Erweiterungs Leasingperioden haben Lücken in ihren Angaben zu ihrer erwarteten Ausführung"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_EXECUTION_VALUE_NEEDED_IF_DATE_SET",
        en: "Execution value must be positive if execution date is set or zero if residual date is null.",
        de: "Das Ausführungsdatum und der Ausführungswert für die Leasing Periode müssen entweder beide gesetzt oder beide leer sein."
    },
    {
        key: "VALIDATION_LEASING_PERIOD_PAYMENT_RULES_NEEDED",
        en: "Initial Contracts need payment rules for all leasing periods",
        de: "Verträge in der Erstanlage benötigen Zahlungsregeln in allen Leasingperioden"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_PAYMENT_RULE_START_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "All payment start dates of payment rules must be higher than activate date of the reassessment/modification or if new the commencement date",
        de: "Der Beginn einer jeden Zahlungsregel muss später sein als der Beginn des Vertrages oder im Falle eines Reassessments des Neubeurteilungsdatums"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_PAYMENT_RULE_END_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "All payment ends of payment rules must be higher than activate date of the reassessment/modification or if new the commencement date",
        de: "Das Ende einer jeden Zahlungsregel muss später sein als der Beginn des Vertrages oder im Falle eines Reassessments des Neubeurteilungsdatums"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_TERMINIATION_MUST_BE_LOWER_THAN_END_OF_LEASING_PERIOD",
        en: "Termination Option End Date must be lower than the leasing period end date",
        de: "Das Ende der Terminierungsoption muss früher sein als das normale Ende des Leasing Periode"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_TERMINIATION_MUST_BE_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "Termination option end date must be higher than activate date of the reassessment/modification or if new the commencement date",
        de: "Das Ende der Terminierungsoption muss später sein als der Beginn des Vertrages oder im Falle eines Reassessments des Neubeurteilungsdatums"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_ENDDATE_MUST_BE_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "Leasing period end date must be higher than activate date of the reassessment/modification or if new, the commencement date",
		de: "Das Ende einer Leasing-Periode muss später sein als das Datum des Neubewertung-Inkrafttretens oder, wenn neu, des Beginndatums"
    },
    {
        key: "VALIDATION_LEASING_PERIOD_EXECUTION_MUST_BE_HIGHER_THAN_REAS_ACTIVATE_DATE",
        en: "Paydate of an extensions leasing period must be higher than activate date of the reassessment/modification or if new the commencement date",
        de: "Der Zahltag des Ausübungspreises einer Verlängerung muss später sein als der Beginn des Vertrages oder im Falle eines Reassessments des Neubeurteilungsdatums"
	}, {
		key: "VALIDATION_LEASING_PERIOD_EXECUTION_MUST_BE_HIGHER_THAN_PREVIOUS_PERIOD_EXECUTION",
		en: "Leasing period execution option date must be higher than previous leasing period execution option date",
		de: "Das Ausführungsdatum der Leasingperiode muss höher sein als das Ausführungsdatum der vorherigen Leasingperiode"
	}


]);