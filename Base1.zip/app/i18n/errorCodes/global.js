﻿if (translations == null) {
	var translations = [];
}

translations = translations.concat([
	{
		key: "VALIDATION_FIELD_MUST_NOT_BE_EMPTY",
		en: "Fill this out",
		de: "Geben Sie etwas ein"
	},
	{
		key: "VALIDATION_SELECT_MUST_NOT_BE_EMPTY",
		en: "Select a value",
		de: "Wählen Sie etwas aus"
	},
	{
		key: "VALIDATION_DATE_MUST_NOT_BE_EMPTY",
		en: "Select a date",
		de: "Wählen Sie ein Datum"
	},
	{
		key: "VALIDATION_MUST_BE_BETWEEN_0_AND_100",
		en: "Value has to be between 0 and 100",
		de: "Wert muss zwischen 0 und 100 liegen"
	},
	{
		key: "VALIDATION_DOES_NOT_MATCH_ALLOW_STRING_REGEX",
		en: "Remove unallowed characters",
		de: "Entfernen Sie unerlaubte Zeichen"
	},
	{
		key: "VALIDATION_JUST_DIGITS",
		en: "Type in a number",
		de: "Geben Sie eine Zahl an"
	},
	{
		key: "VALIDATION_NEEDS_TWO_DIGITS",
		en: "Type in a two digit number",
		de: "Geben Sie eine zweistellige Zahl an"
	},
	{
		key: "VALIDATION_NEEDS_TEN_DIGITS",
		en: "Type in a ten digit number",
		de: "Geben Sie eine zehnstellige Zahl an"
	},
    {
        key: "VALIDATION_NEEDS_SIX_DIGITS",
        en: "Type in a six digit number",
        de: "Geben Sie eine sechsstellige Zahl an"
    },
	{
		key: "VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS",
		en: "E.g. 12.34",
		de: "Z.B. 12,34"
	},
    {
        key: "VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS",
        en: "E.g. 12.3456",
        de: "Z.B. 12,3456"
    },
	{
		key: "VALIDATION_LESS_THAN_OR_EQUAL_100_PERCENT",
		en: "Maximum 100%",
		de: "Maximal 100%"
	},
	{
		key: "VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX",
		en: "^\\d*[.]?\\d{1,2}$",
		de: "^\\d*[,]?\\d{1,2}$"
	},
	{
		key: "VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS_REGEX",
		en: "^\\d*[.]?\\d{1,4}$",
		de: "^\\d*[,]?\\d{1,4}$"
	},
	{
		key: "VALIDATION_DECIMAL_REGEX",
		en: "^\\d*[.]?\\d{1,10}$",
		de: "^\\d*[,]?\\d{1,10}$"
	}
]);