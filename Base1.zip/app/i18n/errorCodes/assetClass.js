﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_ASSET_CLASS_EXTERNAL_ID_NOT_UNIQUE",
        en: "External Id already used by another asset class",
        de: "External Id wird bereits verwendet bei einer anderen Asset Klasse"
    },
    {
        key: "VALIDATION_CAN_NOT_DELETE_ASSET_CLASS",
        en: "Could not delete assetclass because there are referenced contracts",
        de: "Asset kann nicht gelöscht werden da noch Verträge hiermit verknüpft sind"
    }
]);