﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_COMPANY_COMPANY_CODE_NOT_UNIQUE",
        en: "There is already another company with that company code",
        de: "Dieser Buchungskreis ist bereits vergeben"
    }
]);