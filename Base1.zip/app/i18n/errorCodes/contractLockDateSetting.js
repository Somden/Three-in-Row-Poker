﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_CONTRACTLOCKDATESETTING_NOT_UNIQUE",
        en: "Contract lock date Settings already exists",
        de: "Contract lock date Settings already exists"
    },
    {
        key: "CONTRACT_COMMENCEMENT_DATE_AFTER_CONTRACTLOCKINGDATE",
        en: "Commencement date should be after settings locking date",
        de: "Commencement date should be after settings locking date"
    },
]);