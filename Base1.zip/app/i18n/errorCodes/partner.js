﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_PARTNER_NR_NOT_UNIQUE",
        en: "Partner nr already used by another partner",
        de: "Die Partner nr wird bereits von einem anderen Partner verwendet"
    }
]);