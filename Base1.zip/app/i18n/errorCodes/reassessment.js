﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_PREVIOUS_REVISION_NOT_PRESENT",
        en: "One or more reassessments don't have a previous revision",
        de: "Eine odere meherere Neubewertungen haben keine Vorgängerrevision"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_INTERESTRATE_ORIGIN_NOT_CHANGEABLE",
        en: "Interest rate can not be changed in reassessment",
        de: "Die Zinsrate kann in einer Neubewertung nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_CONTRACT_LEASINGPERIOD_END_DATE_NOT_CHANGEABLE",
        en: "The end date of the contract leasingperiod can not be changed in reassessment",
        de: "Das Enddatum der Vertrags-Leasingperiode kann in einer Neubewertung nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_EXTENSION_LEASINGPERIOD_END_DATE_NOT_CHANGEABLE",
        en: "The end date of the extension leasingperiods can not be changed in reassessment",
        de: "Das Enddatum der Verlängerungsperioden kann in einer Neubewertung nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_EXTENSION_LEASINGPERIOD_EXECUTION_DATE_NOT_CHANGEABLE",
        en: "The execution date of the extension leasingperiods can not be changed in reassessment",
        de: "Das Zahlungsdatum der Verlängerungsperioden kann in einer Neubewertung nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_TERMINATION_OPTION_MUST_REMAIN",
        en: "In reassessment, the termination option cannot be added or removed",
        de: "In einer Neubewertung darf die Verkürzungsoption nicht hinzugefügt oder entfernt werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_TERMINATE_OPTION_EXECUTION_DATE_NOT_CHANGEABLE",
        en: "The execution date of a termination option can not be changed in reassessment",
        de: "Das Zahlungsdatum einer Verkürzungsoption kann in einer Neubewertung nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_TERMINATION_OPTION_END_DATE_NOT_CHANGEABLE",
        en: "The end date of a termination option can not be changed in reassessment",
        de: "Das Enddatum einer Verkürzungsoption kann in einer Neubewertung nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_ROUASSET_VALUES_AND_DATES_MUST_REMAIN",
        en: "In reassessment, the payment values and dates in the Right of Use asset cannot be changed",
        de: "In einer Neubewertung dürfen die Zahlungswerte und -daten der Right of Use Vermögenswerte nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_ROU_ADDITIONAL_PAYMENTS_NOT_CHANGEABLE",
        en: "In reassessment, the additional payment rules cannot be changed",
        de: "In einer Neubewertung dürfen die zusätzlichen Zahlungszeitpunkte nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_ASSET_STRUCTURE_NOT_CHANGEABLE",
        en: "The 'ContractComponentId' off all assets must not change in reassessment",
        de: "Die 'ContractComponentId' aller Vermögenswerte muss gleich bleiben bei einer Neubewertung"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_ASSETCOMPONENT_ASSETSHARE_NOT_CHANGEABLE",
        en: "The asset share of asset components must not change in a reassessment",
        de: "Die Vermögenswert-Anteile der Asset-Komponenten dürfen sich bei einer Neubewertung nicht ändern"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_REAS_ASSETCOMPONENT_ISLIMITED_NOT_CHANGEABLE",
        en: "Whether an asset component is limited, can not be changed in a reassessment",
        de: "Ob eine Vermögenswert-Komponente limitiert ist, kann bei einer Neubewertung nicht geändert werden"
    }
]);