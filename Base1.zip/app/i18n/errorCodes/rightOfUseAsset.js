﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_APPLICATION_CONFIGURED_JUST_ONE_ASSET_COMPONENT",
        en: "Application is configured to have only one asset component",
        de: "Die Applikation wurde so konfiguriert, dass nur eine Asset Komponente erlaubt ist"
    },
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_CONTRACT_INITIATION_COSTS_DATE_MUST_BE_SET",
        en: "Contract initation costs must be positive if date is set or zero if date is null",
        de: "Wenn eine Zahlung für die Vertragsanbahnung angegeben ist, dann muss es auch ein Zahldatum dafür geben"
    },
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_GRANTS_DATE_MUST_BE_SET",
        en: "Grants must be positive if date is set or zero if date is null",
        de: "Wenn eine Zahlung für öffentliche Zuschüsse angegeben ist, dann muss es auch ein Zahldatum dafür geben"
    },
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_OTHER_INITIAL_COSTS_DATE_MUST_BE_SET",
        en: "Other initial costs must be positive if date is set or zero if date is null",
        de: "Wenn eine Zahlung für andere initiale Kosten angegeben ist, dann muss es auch ein Zahldatum dafür geben"
    },
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_LEASE_INCENTIVES_RECEIVED_AMOUNT_DATE_MUST_BE_SET",
        en: "Lease incentives costs must be positive if date is set or zero if date is null",
        de: "Wenn eine Zahlung für erhaltene Leasinganreize angegeben ist, dann muss es auch ein Zahldatum dafür geben"
    },
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_RESTORATION_VALUE_DATE_MUST_BE_SET",
        en: "Restauration costs must be positive if date is set or zero if date is null",
        de: "Wenn eine Zahlung für Restaurationskosten angegeben ist, dann muss es auch ein Zahldatum dafür geben"
    },
    {
        key: "VALIDATION_RIGHT_OF_USE_ASSET_ASSET_NAME_MUST_BE_UNIQUE",
        en: "Name of asset must be unique",
        de: "Der Name eines Vermögenswerts darf nur einmal vorkommen"
    },
    {
        key: "VALIDATION_CAN_NOT_DELETE_RIGHT_OF_USE_ASSET",
        en: "Could not delete rou-asset because there are referenced assetclasses ",
        de: "Asset kann nicht gelöscht werden da noch Assetklassen hiermit verknüpft sind"
    }
    
]);