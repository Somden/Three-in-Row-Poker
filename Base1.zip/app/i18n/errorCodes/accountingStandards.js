﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_ACCOUNTING_STANDARDS_IFRS",
        en: "There must be exactly one accounting type IFRS (state inactive is allowed)",
        de: "Es muss für den Vertrag genau eine Rechnungsvorschrift vom Typ IFRS geben (ein inaktiver Status ist erlaubt)"
    },
    {
        key: "VALIDATION_ACCOUNTING_STANDARDS_USGAAP",
        en: "There must be exactly one accounting type US-GAAP (state inactive is allowed)",
        de: "Es muss für den Vertrag genau eine Rechnungsvorschrift vom Typ US-GAAP geben (ein inaktiver Status ist erlaubt)"
    },
    {
        key: "VALIDATION_ACCOUNTING_STANDARDS_NONE_ACTIVE",
        en: "Exactly one or two accounting standards must be active",
        de: "Es muss mindestens eine Rechnungsvorschrift aktiv sein"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_TEMPLATES_ONLY_INITIAL",
        en: "Template contracts can only have an initial revision",
        de: "Vertragsvorlagen können nur im Zustand Initial gespeichert werden"
    },
]);