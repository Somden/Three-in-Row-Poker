﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_CONTRACT_REVISION_MODI_PREVIOUS_REVISION_NOT_PRESENT",
        en: "One or more modifications don't have a previous revision",
        de: "Eine odere meherere Modifikationen haben keine Vorgängerrevision"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_MODI_ROUASSET_VALUES_AND_DATES_MUST_REMAIN",
        en: "In modification, the payment values and dates in the Right of Use asset cannot be changed",
        de: "In einer Modifikation dürfen die Zahlungswerte und -daten der Right of Use Vermögenswerte nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_MODI_ROU_ADDITIONAL_PAYMENTS_NOT_CHANGEABLE",
        en: "In modification, the additional payment rules cannot be changed",
        de: "In einer Modifikation dürfen die zusätzlichen Zahlungszeitpunkte nicht verändert werden"
    },
    {
        key: "VALIDATION_CONTRACT_REVISION_MODI_ASSET_STRUCTURE_NOT_CHANGEABLE",
        en: "The 'ContractComponentId' off all assets must not change in modification",
        de: "Die 'ContractComponentId' aller Vermögenswerte muss gleich bleiben bei einer Modifikation"
    }
]);