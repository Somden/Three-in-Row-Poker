﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_USER_DOMAIN_NAME_ALREADY_USED",
        en: "An other user already has this domain name!",
        de: "Ein anderer Benutzer benutzt bereits diesen DomainName"
    }
]);