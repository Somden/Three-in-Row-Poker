﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "VALIDATION_CURRENCY_CODE_REQUIRED",
        en: "The currency needs a code",
        de: "Die Währung benötigt einen Code"
    },
    {
        key: "VALIDATION_CURRENCY_CODE_THREE_CHARACTERS",
        en: "The currency code must have three letters",
        de: "Der Währungs-Code muss drei Buchstaben haben"
    },
    {
        key: "VALIDATION_CURRENCY_CODE_JUST_UPPERCASE_LETTERS",
        en: "The currency code must have just uppercase letters",
        de: "Der Währungs-Code darf nur aus Großbuchstaben bestehen"
    },
    {
        key: "VALIDATION_CURRENCY_NAME_REQUIRED",
        en: "The currency needs a name",
        de: "Die Währung benötigt einen Namen"
    },
    {
        key: "VALIDATION_CURRENCY_NAME_STRING_NOT_ALLOWED",
        en: "The currency name contains letters that are not allowed",
        de: "Der Währungs-Name enthält Zeichen die nicht erlaubt sind"
    },
    {
        key: "VALIDATION_CURRENCY_CODE_NOT_UNIQUE",
        en: "Currency code already used by another currency",
        de: "Currency code wird bereits verwendet bei einer anderen Währung"
    },
    {
        key: "VALIDATION_CAN_NOT_DELETE_CURRENCY",
        en: "Delete Currency is not possible. There are contracts and companies referenced to this currency",
        de: "Es ist nicht möglich diese Währung zu löschen, solange noch Verträge, und Buchungskreise hiermit verknüpft sind."
    }

]);