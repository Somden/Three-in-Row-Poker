﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "REPORTS_CONTRACT",
        en: "Contract (search by Id or name)",
        de: "Vertrag (suche nach Id oder Name)"
    },
    {
        key: "REPORTS_COMPANY",
        en: "Company",
        de: "Buchungskreis"
    },
    {
        key: "REPORTS_REVISION_NUMBER",
        en: "Revision Number",
        de: "Revisionsnummer"
    },
    {
        key: "REPORTS_ACCOUNTING_STANDARD",
        en: "Accounting standard",
        de: "Accounting Standard"
    },
    {
        key: "REPORTS_MONTHLY_RASTER_TYPE",
        en: "Monthly Raster Type",
        de: "Monthly Raster Typ"
    },
    {
        key: "REPORTS_SERIES_LEASING_TYPE",
        en: "Leasing type",
        de: "Leasing Art"
    },
    {
        key: "REPORTS_SERIES_COMPONENT",
        en: "Asset Component",
        de: "Vermögenswert Komponente"
    },
    {
        key: "REPORT_GENERATE",
        en: "Show results",
        de: "Ergebnisse anzeigen"
    },
    {
        key: "LOADING_SERIES_REPORT",
        en: "Loading",
        de: "Report wird geladen"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_COUNTER",
        en: "Counter",
        de: "Zähler"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_DAY",
        en: "Day",
        de: "Tag"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_MONTH",
        en: "Month",
        de: "Monat"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_YEAR",
        en: "Year",
        de: "Jahr"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_STARTINGLEASELIABILITY",
        en: "Starting lease liability",
        de: "Startverbindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_INTERESTSHARE",
        en: "Interest share",
        de: "Zinsanteil"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_PAYMENT",
        en: "Payment",
        de: "Zahlung"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_PRESENTVALUEOFPAYMENT",
        en: "Present value of payment",
        de: "Bezahlter Gegenwartswert"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_ENDINGLEASELIABILITY",
        en: "Ending lease liability",
        de: "Endverbindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_BEGINNINGROUASSET",
        en: "Beginning rou asset",
        de: "Start Rou Asset" // TODO: Translate
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_DEPRECIATION",
        en: "Depreciation",
        de: "Abschreibung"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_DEPRECIATION_SPECIAL_BEGINN",
        en: "Beginning special costs",
        de: "Spezialkosten Tagesbeginn"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_DEPRECIATION_SPECIAL",
        en: "Special costs at day",
        de: "Spezialkosten Tageswert"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_DEPRECIATION_SPECIAL_END",
        en: "End operate special costs",
        de: "Spezialkosten Tagesende"
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_ENDINGROUASSET",
        en: "Ending rou asset",
        de: "End Rou Asset" // TODO: Translate
    },
    {
        key: "REPORT_CONTRACT_SERIES_RESULT_TOTALLEASEEXPENSE",
        en: "Total lease expense",
        de: "Gesamtmietkosten"
    },
    {
        key: "REPORTS_CONTRACT_LIST_CONTRACT_STATE",
        en: "Contract state",
        de: "Vertragsstatus"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_ID",
        en: "Contract ID",
        de: "Vertrags ID"
    },
    {
        key: "REPORT_CONTRACT_LIST_COMPANY_ID",
        en: "Company ID",
        de: "Buchungskreis ID"
    },
    {
        key: "REPORT_CONTRACT_LIST_EVALUATION_START",
        en: "Evaluation start",
        de: "Auswertung Startdatum"
    },
    {
        key: "REPORT_EXPORT_LOG_EVALUATION_MONTH",
        en: "Evaluation month",
        de: "Auswertungsmonat"
    },
    {
        key: "REPORT_EXPORT_LOG_REPORT_TIMESTAMP",
        en: "Report Timestamp",
        de: "Berichtszeitstempel"
    },
    {
        key: "REPORT_EXPORT_LOG_REPORT_NAME",
        en: "Report Name",
        de: "Berichtsname"
    },
    {
        key: "REPORT_EXPORT_LOG_REPORT_PARAMETERS",
        en: "Report Parameters",
        de: "Berichtsparameter"
    },
    {
        key: "REPORT_EXPORT_LOG_EXPORT_TYPE",
        en: "Export Type",
        de: "Exportart"
    },
    {
        key: "REPORT_EXPORT_LOG_COMPANY_NAME",
        en: "Company Name",
        de: "Buchungskreisname"
    },
    {
        key: "REPORT_CONTRACT_LIST_EVALUATION_END",
        en: "Evaluation end",
        de: "Auswertung Enddatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_EVALUATION_MONTH",
        en: "Evaluation month",
        de: "Auswertungsmonat"
    },
    {
        key: "REPORT_CONTRACT_LIST_EVALUATION_YEAR",
        en: "Evaluation year",
        de: "Auswertungsjahr"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_TYPE",
        en: "Contract type",
        de: "Vertragstyp"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_STATE",
        en: "Contract state",
        de: "Vertragsstatus"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONCLUCION_DATE",
        en: "Conclusion date",
        de: "Abschlussdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_COMMENCEMENT_DATE",
        en: "Commencement date",
        de: "Beginndatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_EXTERNAL",
        en: "External",
        de: "Extern"
    },
    {
        key: "REPORT_CONTRACT_LIST_IS_INTERNAL",
        en: "Is internal",
        de: "Ist intern"
    },
    {
        key: "REPORT_CONTRACT_LIST_PARTNER_ID",
        en: "Partner id",
        de: "Geschäftspartner ID"
    },
    {
        key: "REPORT_CONTRACT_LIST_PARTNER_NAME",
        en: "Partner name",
        de: "Geschäftspartner name"
    },
    {
        key: "REPORT_CONTRACT_LIST_USER_ID",
        en: "User id",
        de: "Benutzer ID"
    },
    {
        key: "REPORT_CONTRACT_LIST_USER_DOMAIN",
        en: "User domain",
        de: "Benutzer Domain"
    },
    {
        key: "REPORT_CONTRACT_LIST_IS_LIMITED",
        en: "Is limitted",
        de: "Ist begrenzt"
    },
    {
        key: "REPORT_CONTRACT_LIST_IFRS_LEASE_TYPE",
        en: "IFRS",
        de: "IFRS"
    },
    {
        key: "REPORT_CONTRACT_LIST_USGAAP_LEASE_TYPE",
        en: "US-GAAP",
        de: "US-GAAP"
    },
    {
        key: "REPORT_CONTRACT_LIST_REVISION_ID",
        en: "Revision id",
        de: "Revision Id"
    },
    {
        key: "REPORT_CONTRACT_LIST_REVISION",
        en: "Revision No.",
        de: "Revision Nr"
    },
    {
        key: "REPORT_CONTRACT_LIST_REVISION_DESCRIPTION",
        en: "Rev description",
        de: "Revisionsbeschreibung"
    },
    {
        key: "REPORT_CONTRACT_LIST_MODIFICATION_TYPE",
        en: "Modification type",
        de: "Änderungstyp"
    },
    {
        key: "REPORT_CONTRACT_LIST_ACTIVATE_DATE",
        en: "Activate date",
        de: "Aktivierungsdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_REVISION_STATE",
        en: "Revision state",
        de: "Revision Status"
    },
    {
        key: "REPORT_CONTRACT_LIST_IS_SHORT_TERMLEASE",
        en: "Is short term lease ",
        de: "Ist Kurzzeit-Lease"
    },
    {
        key: "REPORT_CONTRACT_LIST_IS_LOW_VALUE",
        en: "Is low value",
        de: "Ist geringfügig"
    },
    {
        key: "REPORT_CONTRACT_LIST_LEGAL_ENTITY",
        en: "Legal entity",
        de: "Rechtsträger"
    },
    {
        key: "REPORT_CONTRACT_LIST_PROFIT_CENTER",
        en: "Profit Сenter",
        de: "Profitcenter"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_TYPE",
        en: "Contract type",
        de: "Vertragstyp"
    },
    {
        key: "REPORT_CONTRACT_LIST_COST_CENTER",
        en: "Cost Сenter",
        de: "Kostenstelle"
    },
    {
        key: "REPORT_CONTRACT_LIST_MANAGEMENT_UNIT",
        en: "Management Unit",
        de: "Management Unit"
    },
    {
        key: "REPORT_CONTRACT_LIST_RETIREMENT_DATE",
        en: "Retirement date",
        de: "Abgangsdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_RESIDUAL_VALUE",
        en: "Residual value",
        de: "Restwert"
    },
    {
        key: "REPORT_CONTRACT_LIST_RESIDUAL_DATE",
        en: "Residual date",
        de: "Restwertdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_INTEREST_RATE",
        en: "Interest rate",
        de: "Zinzrate"
    },
    {
        key: "REPORT_CONTRACT_LIST_INCREMENTAL_BORROWING_RATE",
        en: "Borrowing rate",
        de: "Zinssatz"
    },
    {
        key: "REPORT_CONTRACT_LIST_USE_INTEREST_RATE",
        en: "Use interest rate",
        de: "Zinsrate in Nutzung"
    },
    {
        key: "REPORT_CONTRACT_LIST_TRANSFER_OF_OWNERSHIP",
        en: "Transfer ownership",
        de: "Eigentum übertragen"
    },
    {
        key: "REPORT_CONTRACT_LIST_PURCHASE_OPTION_DATE",
        en: "Purchase Option date",
        de: "Kaufoption Datum"
    },
    {
        key: "REPORT_CONTRACT_LIST_PURCHASE_OPTION_VALUE",
        en: "Purchase Option value",
        de: "Kaufoption Wert"
    },
    {
        key: "REPORT_CONTRACT_LIST_ROUASSET_ID",
        en: "RoU asset ID",
        de: "Vermögenswert ID"
    },
    {
        key: "REPORT_CONTRACT_LIST_INITIAL_COSTS",
        en: "Initial costs",
        de: "Initiale Kosten"
    },
    {
        key: "REPORT_CONTRACT_LIST_INITIAL_COSTS_DATE",
        en: "Initial costs date",
        de: "Initiale Kosten Zahldatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_GRANTS",
        en: "Grants",
        de: "Zuschüsse"
    },
    {
        key: "REPORT_CONTRACT_LIST_GRANTS_DATE",
        en: "Grants date",
        de: "Zuschüsse Zahldatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_OTHER_INITIAL_COSTS",
        en: "Other initial costs",
        de: "Andere initiale Kosten"
    },
    {
        key: "REPORT_CONTRACT_LIST_OTHER_INITIAL_COSTS_DATE",
        en: "Other initial costs date",
        de: "Andere initiale Kosten Zahldatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_RECEIVED_AMOUNT",
        en: "Received Amount",
        de: "Rückerstattungsbetrag"
    },
    {
        key: "REPORT_CONTRACT_LIST_RECEIVED_AMOUNT_DATE",
        en: "Recived Amount date",
        de: "Rückerstattungsdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_RESTORATION_COSTS",
        en: "Restoration costs",
        de: "Wiederherstellungskosten"
    },
    {
        key: "REPORT_CONTRACT_LIST_RESTORATION_COSTS_DATE",
        en: "Restoration costs date",
        de: "Wiederherstellungskosten Zahldatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_COMMENTS",
        en: "Comments",
        de: "Kommentare"
    },
    {
        key: "REPORT_CONTRACT_LIST_EVALUATION_START_DAY",
        en: "Evaluation start day",
        de: "Starttag der Auswertung"
    },
    {
        key: "REPORT_CONTRACT_LIST_EVALUATION_END_DAY",
        en: "Evaluation end day",
        de: "Endtag der Auswertung"
    },
    {
        key: "REPORT_CONTRACT_LIST_RETIREMENT_DAY",
        en: "Retirement Day",
        de: "Ausscheidungs-Tag"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_END_DATE",
        en: "Contract end date",
        de: "Vertragsenddatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_START_DATE",
        en: "Contract start date",
        de: "Vertragsstartdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_CONTRACT_END_DAY",
        en: "Contract end day",
        de: "Vetragsend-Tag"
    },
    {
        key: "REPORT_CONTRACT_LIST_PURCHSE_OPTION_VALUE",
        en: "Purchase option value",
        de: "Kaufoptionswert"
    },
    {
        key: "REPORT_CONTRACT_LIST_EXTENSION_OPTION_VALUE",
        en: "Extension option value",
        de: "Erweiterungsoption"
    },
    {
        key: "REPORT_CONTRACT_LIST_TERMINATION_OPTION_VALUE",
        en: "Termination value",
        de: "Terminierungswert"
    },
    {
        key: "REPORT_CONTRACT_LIST_TERMINATION_OPTION_DATE",
        en: "Termination date",
        de: "Terminierungsdatum"
    },
    {
        key: "REPORT_CONTRACT_LIST_LIABILITY_REVISION",
        en: "Liability",
        de: "Verbindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_LIST_LIABILITY_INITIAL_REVISION",
        en: "Initial liability",
        de: "Initiale Vergindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_LIST_LIABILITY_START_PERIOD",
        en: "Liability start",
        de: "Startverbindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_LIST_LIABILITY_END_PERIOD",
        en: "Liability end",
        de: "Endverbindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_LIST_SUM_ALLPAYMENTS",
        en: "Sum payments",
        de: "Summe der Zahlungen"
    },
    {
        key: "REPORT_CONTRACT_LIST_SUM_ROU_INITIAL_REVISION",
        en: "Sum RoU initial revision",
        de: "Summe RoU erste Überarbeitung"
    },
    {
        key: "REPORT_CONTRACT_LIST_SUM_PAYMENTS_IN_PERIOD",
        en: "Extinction in Period",
        de: "Tilgung Auswertungszeitraum"
    },
    {
        key: "REPORT_CONTRACT_LIST_INTEREST_SHARE_IN_PERIOD",
        en: "Interest share",
        de: "Zinsanteil"
    },
    {
        key: "REPORT_CONTRACT_LIST_BOOKING_VALUE_IN_PERIOD",
        en: "Booking value",
        de: "Buchungswert"
    },
    {
        key: "REPORT_CONTRACT_LIST_LIABILITY_RETIREMENT_DATE",
        en: "Liability retirement date",
        de: "Verbindlichkeit am Abgang"
    },
    {
        key: "REPORT_CONTRACT_LIST_DIFF_IN_PERIOD",
        en: "Liability diff.",
        de: "Verbindlichkeitsdifferenz"
    },
    {
        key: "REPORT_CONTRACT_LIST_REMAINING_PAYMENTS_START",
        en: "Remaining payments start",
        de: "Verbleibende Zahlungen ab Start"
    },
    {
        key: "REPORT_CONTRACT_LIST_MULTICOLUMN_INPERIODCALCULATION",
        en: "In Period calculation",
        de: "Kalkulation auf evaluierungszeitram bezogen."
    },
    {
        key: "REPORT_CONTRACT_LIST_MULTICOLUMN_CONTRACTBASEDATA",
        en: "Contract base data",
        de: "Vertragsstammdaten"
    },
    {
        key: "REPORT_CONTRACT_LIST_MULTICOLUMN_CONTRACTCOSTS",
        en: "Contract costs data",
        de: "Vertragskosten"
    },
    {
        key: "REPORT_CONTRACT_LIST_REMAINING_PAYMENTS_END",
        en: "Remaining payments end",
        de: "Verbleibende Zahlung ab Ende"
    },
    {
        key: "REPORTS_COMPANY_SUMMARY_STATE",
        en: "Contract state",
        de: "Vertragsstatus"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EVALUATION_START",
        en: "Evaluation start",
        de: "Auswertung Startdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EVALUATION_END",
        en: "Evaluation end",
        de: "Auswertung Enddatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EVALUATION_MONTH",
        en: "Evaluation month",
        de: "Auswertungsmonat"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EVALUATION_YEAR",
        en: "Evaluation year",
        de: "Auswertungsjahr"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_TYPE",
        en: "Contract type",
        de: "Vertragstyp"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_STATE",
        en: "Contract state",
        de: "Vertragsstatus"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONCLUCION_DATE",
        en: "Conclusion date",
        de: "Abschlussdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMMENCEMENT_DATE",
        en: "Commencement date",
        de: "Beginndatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EXTERNAL",
        en: "External",
        de: "Extern"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_IS_INTERNAL",
        en: "Is internal",
        de: "Ist intern"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_PARTNER_ID",
        en: "Partner id",
        de: "Geschäftspartner ID"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_PARTNER_NAME",
        en: "Partner name",
        de: "Geschäftspartner name"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_USER_ID",
        en: "User id",
        de: "Benutzer ID"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_USER_DOMAIN",
        en: "User domain",
        de: "Benutzer Domain"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_IS_LIMITED",
        en: "Is limitted",
        de: "Ist begrenzt"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_IFRS_LEASE_TYPE",
        en: "IFRS",
        de: "IFRS"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_USGAAP_LEASE_TYPE",
        en: "US-GAAP",
        de: "US-GAAP"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_REVISION_ID",
        en: "Revision Id",
        de: "Revision Id"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_REVISION",
        en: "Revision No.",
        de: "Revision Nr"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_REVISION_DESCRIPTION",
        en: "Rev description",
        de: "Revisionsbeschreibung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_MODIFICATION_TYPE",
        en: "Modification type",
        de: "Änderungstyp"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_ACTIVATE_DATE",
        en: "Activate date",
        de: "Aktivierungsdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_REVISION_STATE",
        en: "Revision state",
        de: "Revision Status"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_IS_SHORT_TERMLEASE",
        en: "Is short term lease ",
        de: "Ist Kurzzeit-Lease"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_IS_LOW_VALUE",
        en: "Is low value",
        de: "Ist geringfügig"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_LEGAL_ENTITY",
        en: "Legal entity",
        de: "Rechtsträger"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_PROFIT_CENTER",
        en: "Profit center",
        de: "Profitcenter"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_TYPE",
        en: "Contract type",
        de: "Vertragstyp"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COST_CENTER",
        en: "Cost center",
        de: "Kostenstelle"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_MANAGEMENT_UNIT",
        en: "Management Unit",
        de: "Management Unit"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RETIREMENT_DATE",
        en: "Retirement date",
        de: "Abgangsdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RESIDUAL_VALUE",
        en: "Residual value",
        de: "Restwert"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RESIDUAL_DATE",
        en: "Residual date",
        de: "Restwertdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_INTEREST_RATE",
        en: "Interest rate",
        de: "Zinzrate"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_INCREMENTAL_BORROWING_RATE",
        en: "Borrowing rate",
        de: "Zinssatz"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_USE_INTEREST_RATE",
        en: "Use interest rate",
        de: "Zinsrate in Nutzung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_TRANSFER_OF_OWNERSHIP",
        en: "Transfer ownership",
        de: "Eigentum übertragen"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_PURCHASE_OPTION_DATE",
        en: "Purchase Option date",
        de: "Kaufoption Datum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_PURCHASE_OPTION_VALUE",
        en: "Purchase Option value",
        de: "Kaufoption Wert"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_ROUASSET_ID",
        en: "RoU asset ID",
        de: "Vermögenswert ID"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_INITIAL_COSTS",
        en: "Initial costs",
        de: "Initiale Kosten"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_INITIAL_COSTS_DATE",
        en: "Initial costs date",
        de: "Initiale Kosten Zahldatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_GRANTS",
        en: "Grants",
        de: "Zuschüsse"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_GRANTS_DATE",
        en: "Grants date",
        de: "Zuschüsse Zahldatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_OTHER_INITIAL_COSTS",
        en: "Other initial costs",
        de: "Andere initiale Kosten"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_OTHER_INITIAL_COSTS_DATE",
        en: "Other initial costs date",
        de: "Andere initiale Kosten Zahldatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RECEIVED_AMOUNT",
        en: "Received Amount",
        de: "Rückerstattungsbetrag"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RECEIVED_AMOUNT_DATE",
        en: "Recived Amount date",
        de: "Rückerstattungsdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RESTORATION_COSTS",
        en: "Restoration costs",
        de: "Wiederherstellungskosten"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RESTORATION_COSTS_DATE",
        en: "Restoration costs date",
        de: "Wiederherstellungskosten Zahldatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMMENTS",
        en: "Comments",
        de: "Kommentare"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EVALUATION_START_DAY",
        en: "Evaluation start day",
        de: "Starttag der Auswertung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EVALUATION_END_DAY",
        en: "Evaluation end day",
        de: "Endtag der Auswertung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_RETIREMENT_DAY",
        en: "Retirement Day",
        de: "Ausscheidungs-Tag"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_END_DATE",
        en: "Contract end date",
        de: "Vertragsenddatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_START_DATE",
        en: "Contract start date",
        de: "Vertragsstartdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_CONTRACT_END_DAY",
        en: "Contract end day",
        de: "Vetragsend-Tag"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_PURCHSE_OPTION_VALUE",
        en: "Purchase option value",
        de: "Kaufoptionswert"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_EXTENSION_OPTION_VALUE",
        en: "Extension option value",
        de: "Erweiterungsoption"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_TERMINATION_OPTION_VALUE",
        en: "Termination value",
        de: "Terminierungswert"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_TERMINATION_OPTION_DATE",
        en: "Termination date",
        de: "Terminierungsdatum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_LIABILITY_REVISION",
        en: "Liability",
        de: "Verbindlichkeit"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_LIABILITY_INITIAL_REVISION",
        en: "Initial liability",
        de: "Initiale Vergindlichkeit"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_LIABILITY_START_PERIOD",
        en: "Liability start",
        de: "Startverbindlichkeit"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_LIABILITY_END_PERIOD",
        en: "Liability end",
        de: "Endverbindlichkeit"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_SUM_ALLPAYMENTS",
        en: "Sum payments",
        de: "Summe der Zahlungen"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_SUM_ROU_INITIAL_REVISION",
        en: "Sum RoU initial revision",
        de: "Summe RoU erste Überarbeitung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_SUM_PAYMENTS_IN_PERIOD",
        en: "Extinction in Period",
        de: "Tilgung Auswertungszeitraum"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_INTEREST_SHARE_IN_PERIOD",
        en: "Interest share",
        de: "Zinsanteil"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_BOOKING_VALUE_IN_PERIOD",
        en: "Booking value",
        de: "Buchungswert"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_LIABILITY_RETIREMENT_DATE",
        en: "Liability retirement date",
        de: "Verbindlichkeit am Abgang"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_DIFF_IN_PERIOD",
        en: "Liability diff.",
        de: "Verbindlichkeitsdifferenz"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_REMAINING_PAYMENTS_START",
        en: "Remaining payments start",
        de: "Verbleibende Zahlungen ab Start"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_MULTICOLUMN_INPERIODCALCULATION",
        en: "In Period calculation",
        de: "Kalkulation auf evaluierungszeitram bezogen."
    },
    {
        key: "REPORT_COMPANY_SUMMARY_MULTICOLUMN_CONTRACTBASEDATA",
        en: "Contract base data",
        de: "Vertragsstammdaten"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_MULTICOLUMN_CONTRACTCOSTS",
        en: "Contract costs data",
        de: "Vertragskosten"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_REMAINING_PAYMENTS_END",
        en: "Remaining payments end",
        de: "Verbleibende Zahlung ab Ende"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMPANY_NAME",
        en: "Company name",
        de: "Buchungskreisname"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMPANY_CODE",
        en: "Company code",
        de: "Buchungskreiscode"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMPANY_ID",
        en: "Company Id",
        de: "Id"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_IS_ACTIVE",
        en: "Is Active",
        de: "Ist Aktiv"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMPANY_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "REPORT_COMPANY_SUMMARY_COMPANY_EXTINCTION",
        en: "Extinction",
        de: "Extinction"
    },
    {
        key: "REPORT_EXPORT",
        en: "Export",
        de: "Exportieren"
    },
    {
        key: "REPORT_EXPORT_EXCEL",
        en: "Download Excel",
        de: "Excel herunterladen"
    },
    {
        key: "REPORT_EXPORT_CSV",
        en: "Download CSV",
        de: "CSV herunterladen"
    },
    {
        key: "REPORT_EXPORT_EXCEL_LOADING",
        en: "Excel will be generated",
        de: "Excel wird generiert"
    },
    {
        key: "REPORT_EXPORT_CSV_LOADING",
        en: "CSV will be generated",
        de: "CSV wird generiert"
    },
    {
        key: "REPORT_EXPORT_READY",
        en: "Report is ready",
        de: "Report ist bereit"
    },
    {
        key: "REPORT_EXPORT_ERROR",
        en: "Error:",
        de: "Fehler"
    },
    {
        key: "REPORT_EXPORT_VIEW",
        en: "Export displayed result",
        de: "Ansicht exportieren"
    },
    {
        key: "REPORT_EXPORT_CONFIGURE_FORMATTING",
        en: "Configure format",
        de: "Formatierung konfigurieren"
    },
    {
        key: "REPORTS_COMMENCMENT_DATE",
        en: "Date of commencement",
        de: "Beginn des Leasingverhältnisses"
    },
    {
        key: "REPORTS_END_DATE",
        en: "End of Leaseterm",
        de: "Ende des Leasingverhältnisses"
    },
    {
        key: "REPORT_INCLUDEPENDING",
        en: "Include pending Contract",
        de: "Verträge in Bearbeitung mitanzeigen"
    },
    {
        key: "REPORT_CONTRACT_PAYMENTS_PAYMENT_DATE",
        en: "Payment date",
        de: "Zahlungsdatum"
    },
    {
        key: "REPORT_CONTRACT_PAYMENTS_DAYS_FROM_START",
        en: "Days from start",
        de: "Tage seit Beginn"
    },
    {
        key: "REPORT_CONTRACT_PAYMENTS_NOMINAL_VALUE",
        en: "Nominal value",
        de: "Nominalwert"
    },
    {
        key: "REPORT_CONTRACT_PAYMENTS_PRESENT_VALUE",
        en: "Present value",
        de: "Gegenwartswert"
    },
    {
        key: "REPORT_CONTRACT_PAYMENTS_DESCRIPTION",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "REPORT_EXPORTING",
        en: "Exporting Report",
        de: "Report wird exportiert"
    },
    {
        key: "REPORT_CONTRACT_SUM_ALL_PAYMENTS",
        en: "Sum all Payments",
        de: "Summe alle Zahlungen"
    },
    {
        key: "REPORT_CONTRACT_TOTAL_LIABILITY",
        en: "Total Liability",
        de: "Summe Verbindlichkeit"
    },
    {
        key: "REPORT_CONTRACT_TOTAL_LIABILITY_FIRST_YEAR",
        en: "Liability for one Year",
        de: "Summe Verbindlichkeit für ein Jahr"
    },
    {
        key: "REPORT_CONTRACT_TOTAL_LIABILITY_LESS_THEN_FIVE_YEARS",
        en: "Liability for five Year",
        de: "Summe Verbindlichkeit für unter fünf Jahre"
    },
    {
        key: "REPORT_CONTRACT_TOTAL_LIABILITY_MORE_THEN_FIVE_YEAR",
        en: "Liability diff one to five years",
        de: "Summe Verbindlichkeit für mehr als fünf Jahr" //TODO translate
    },
    {
        key: "REPORTS_CONTRACT_FILTER_LOW_VALUES_LEASES",
        en: "low-values Leases",
        de: "Geringwertiges Leasing"
    },
    {
        key: "REPORTS_EXPORT_LOG_FILTER_ALL_ENTRIES",
        en: "All entries export log",
        de: "Alle Einträge exportieren das Protokoll"
    },
    {
        key: "REPORTS_CONTRACT_FILTER_SHORT_TERM_LEASES",
        en: "short-term Leases",
        de: "Kurzzeit Leasing"
    },
    {
        key: "REPORTS_NOTES_TITLE",
        de: "Anhangangaben Reports",
        en: "Notes Reports"
    },
    {
        key: "REPORTS_EXPORT_LOGS_TITLE",
        de: "Protokolle exportieren Reports",
        en: "Export Logs Reports"
    },
    {
        key: "REPORTS_ABATEMENT_TITLE",
        de: "Minderungen Reports",
        en: "Abatement Reports"
    },
    {
        key: "REPORTS_ABAO_TOOLKIT_TITLE",
        de: "ABAO Toolkit Reports",
        en: "ABAO Toolkit Reports"
    },

    // Asset List Report
    {
        key: "REPORTS_ASSET_LIST_TITLE",
        de: "Vermögenswert Listenbericht",
        en: "Asset list report"
    },
    {
        key: "REPORTS_ASSET_LIST_PIRIOD_START",
        de: "Anfang",
        en: "Start"
    },
    {
        key: "REPORTS_ASSET_LIST_PIRIOD_END",
        de: "Ende",
        en: "End"
    },
    {
        key: "REPORTS_ASSET_LIST_CONTRACT_ID",
        en: "Contract ID",
        de: "Vertrags ID"
    },
    {
        key: "REPORTS_ASSET_LIST_CONTRACT_NAME",
        en: "Contract name",
        de: "Vertragsname"
    },
    {
        key: "REPORTS_ASSET_LIST_CURRENCY",
        de: "Währung",
        en: "Currency"
    },
    {
        key: "REPORTS_ASSET_LIST_SUM_OPERATE_SPECIAL_DEPRECIATION_IN_PERIOD",
        de: "Summe Spezial-Abschreibung",
        en: "Special Depreciation sum"
    },
    {
        key: "REPORTS_ASSET_LIST_OPERATE_SPECIAL_START",
        de: "Spezialkosten Anfang",
        en: "Special costs at start"
    },
    {
        key: "REPORTS_ASSET_LIST_OPERATE_SPECIAL_END",
        de: "Spezialkosten Ende",
        en: "Spcial costs at end"
    },
    {
        key: "REPORTS_ASSET_LIST_OPERATE_SPECIAL_DIFF_IN_PERIOD",
        de: "Spezialkosten Unterschied",
        en: "Spcial costs diff"
    },
    {
        key: "REPORTS_ASSET_LIST_OPERATE_SPECIAL_AT_RETIREMENT_DATE",
        de: "Spezialkosten Abgangsdatum",
        en: "Spcial costs retirement date"
    },
    {
        key: "REPORTS_ASSET_LIST_ASSET_ID",
        de: "Vermögenswert ID",
        en: "Asset ID"
    },
    {
        key: "REPORTS_ASSET_LIST_ASSET_NAME",
        de: "Objektname",
        en: "Asset name"
    },
    {
        key: "REPORTS_ASSET_LIST_SUM_ASSET_DEPRECIATION_IN_PERIOD",
        de: "Summe Abschreibung",
        en: "Sum depreciation"
    },
    {
        key: "REPORTS_ASSET_LIST_ASSET_COMPONENT_ID",
        de: "Vermögenswert Komponenten-ID",
        en: "Asset component ID"
    },
    {
        key: "REPORTS_ASSET_LIST_CONTRACT_COMPONENT_ID",
        de: "Vertrags-Komponenten-ID",
        en: "Contract component ID"
    },
    {
        key: "REPORTS_ASSET_LIST_ASSET_COMPONENT_NAME",
        de: "Vermögenswert Komponenten-Name",
        en: "Asset component name"
    },
    {
        key: "REPORTS_ASSET_LIST_IS_LIMITTED",
        de: "Vermögenswert Limitierung",
        en: "Asset limitted"
    },
    {
        key: "REPORTS_ASSET_LIST_VALUE_DELTA",
        de: "Wert Delta", // todo translate
        en: "Value delta"
    },
    {
        key: "REPORTS_ASSET_LIST_ECONOMICAL_USEFULLIFE_ENDDATE",
        de: "Wirt. Nutzdauer Enddatum",
        en: "Econ. useful life end date"
    },
    {
        key: "REPORTS_ASSET_LIST_FAIRVALUE",
        de: "Fairer Wert", // todo translate
        en: "Fair value"
    },
    {
        key: "REPORTS_ASSET_LIST_ASSETSHARE",
        de: "Asset-Anteil", // todo translate
        en: "Asset share"

    },
    {
        key: "REPORTS_ASSET_LIST_ASSETCLASS",
        de: "Vermögenswert Klassifizierung",
        en: "Asset class"
    },
    {
        key: "REPORTS_ASSET_LIST_REVISION_DIFFERENCE",
        de: "Änderungsdifferenz", // todo translate
        en: "Revision diff"
    },
    {
        key: "REPORTS_ASSET_LIST_SUM_ASSET_COMPONENT_DEPRECIATION_IN_PERIOD",
        de: "Summe Abschreibung pro Assetkomponente", // todo translate
        en: "Sum asset component depreciation"
    },
    {
        key: "REPORTS_ASSET_LIST_SUM_ASSET_DEPRECIATION_IN_PERIOD",
        de: "Summe Abschreibung pro Anlage", // todo translate
        en: "Sum asset depreciation"
    },
    {
        key: "REPORTS_ASSET_LIST_DEPRECIATION_AT_START",
        de: "Abschreibungswert Start",
        en: "Depreciation Start"
    },
    {
        key: "REPORTS_ASSET_LIST_DEPRECIATION_AT_END",
        de: "Abschreibungswert Ende",
        en: "Depreciation end"
    },
    {
        key: "REPORTS_ASSET_LIST_DEPRECIATION_DIFF_IN_PERIOD",
        de: "Abschreibungsdifferenz",
        en: "Depreciation diff"
    },
    {
        key: "REPORTS_ASSET_LIST_DEPRECIATION_RETIREMENT_DATE",
        de: "Abschreibungswert Abgangsdatum",
        en: "Depreciation retirement date"
    },
    {
        key: "REPORTS_ASSET_LIST_USEFULLIFE_ENDDATE",
        de: "Nutzungsdauer Enddatum",
        en: "Useful life end date"
    },
    {
        key: "REPORTS_ASSET_LIST_USEFULLIFE_ENDDAY",
        de: "Nutzungsdauer Endtag",
        en: "Useful life end day"
    },
    {
        key: "REPORT_EVALUATION_DAY",
        en: "Evaluation day",
        de: "Tag der Auswertung"
    },
    {
        key: "REPORT_CUR_NO",
        en: "Current Number",
        de: "Laufende Nummer"
    },
    {
        key: "REPORT_ASSET_TRANSACTION_TYPE",
        en: "Asset Transaction Type",
        de: "Anlagenhauptnummer"
    },
    {
        key: "REPORT_ASSET_SUBNUMMER",
        en: "Asset Subnumber",
        de: "Anlagenunternummer"
    },
    {
        key: "REPORT_DOCUMENT_HEADER_TEXT",
        en: "Belegkopftext",
        de: "Document Header Text"
    },
    {
        key: "REPORT_DOCUMENT_HEADER_DATE",
        en: "Belegdatum im Beleg",
        de: "Document Date In Document"
    },
    {
        key: "REPORT_POSTING_DATE_IN_DOCUMENT",
        en: "Posting Date In Document",
        de: "Buchungsdatum im Beleg"
    },
    {
        key: "REPORT_ASSET_VALUE_DATE",
        en: "Asset Value Date",
        de: "Bezugsdatum"
    },
    {
        key: "REPORT_TRANSLATION_DATE",
        en: "Translation Date",
        de: "Umrechnungsdatum"
    },
    {
        key: "REPORT_VALUE_DATE",
        en: "Value Date",
        de: "Valutadatum"
    },
    {
        key: "REPORT_REFERENCE_DOCUMENT_NUMBER",
        en: "Reference Document Number",
        de: "Referenz-Belegnummer"
    },
    {
        key: "REPORT_KENZ_VOLLABGANG",
        en: "###",
        de: "Kennzeichen Vollabgang"
    },
    {
        key: "REPORT_KENZ_BEWEGUNG_NEU",
        en: "####",
        de: "Kennzeichen Bewegung bezieht sich auf Neuzugang"
    },
    {
        key: "REPORT_PROZ_ANLAGEABGANG",
        en: "####",
        de: "Prozentsatz Anlageabgang"
    },
    {
        key: "REPORT_AMOUNT",
        en: "Amount",
        de: "Buchungsbetrag"
    },
    {
        key: "REPORT_QUANTITY",
        en: "Quantity",
        de: "Menge"
    },
    {
        key: "REPORT_BASE_UNIT_OF_MEASURE",
        en: "Base Unit Of Measure",
        de: "Basismengeneinheit"
    },
    {
        key: "REPORT_ERLOES_AUS_ANLAGENVERKAUF",
        en: "####",
        de: "Erlös aus Anlagenverkauf"
    },
    {
        key: "REPORT_BERTUNGSBEREICH_RESTBUCH_WERT",
        en: "####",
        de: "Basisbewertungsbereich für Restbuchwert ermitteln"
    },
    {
        key: "REPORT_KENZ_BERTUNGSBEREICH_RESTBUCH_WERT",
        en: "####",
        de: "Kennzeichen für Erlös aus Restbuchwert ermitteln"
    },
    {
        key: "REPORT_KOSTEN_ANLAGEABGANG",
        en: "####",
        de: "Kosten aus Anlageabgang"
    },
    {
        key: "REPORT_FISCAL_YEAR",
        en: "Fiscal Year",
        de: "Geschäftsjahr"
    },
    {
        key: "REPORT_FISCAL_PERIOD",
        en: "Fiscal Period",
        de: "Geschäftsmonat"
    },
    {
        key: "REPORT_COMPANY_ID_OF_TRADING_PARTNER",
        en: "####",
        de: "Partner Gesellschaftsnummer"
    },
    {
        key: "REPORT_COST_CENTER",
        en: "Cost Center",
        de: "Kostenstelle"
    },
    {
        key: "REPORT_ORDER_NUMBER",
        en: "Order Number",
        de: "Auftragsnummer"
    },
    {
        key: "REPORT_WORK_BREAK_DOWN_STRUCTURE_ELEMENT",
        en: "Work Break Down Structure Element",
        de: "Projektstrukturelement (PSP-Element)"
    },
    {
        key: "REPORT_ITEM_TEXT",
        en: "Item Text",
        de: "Positionstext"
    },
    {
        key: "REPORT_ASSIGNMENT_NUMBER",
        en: "Assignment Number",
        de: "Zuordnungsnummer"
    },
    {
        key: "DOCNO_TOOLKIT",
        en: "####",
        de: "Belegnummer Toolkit"
    },
    {
        key: "REPORT_CURRENCY_KEY",
        en: "####",
        de: "Währungsschlüssel"
    },
    {
        key: "REPORT_AMOUNT_IN_DOCUMENT_CURRENCY",
        en: "Amount In Document Currency",
        de: "Betrag in Belegwährung"
    },
    {
        key: "REPORT_LEDGER_GROUP",
        en: "Ledger Group",
        de: "Ledger Gruppe"
    },
    {
        key: "REPORT_BOOKING_KEY",
        en: "Booking Key",
        de: "Buchungsschlüssel"
    },
    {
        key: "REPORT_SALES_TAX_CODE",
        en: "Sales Tax Code",
        de: "Umsatzsteuerkennzeichen"
    },
    {
        key: "REPORT_ASSIGNMENT_NUMBER",
        en: "Assignment Number",
        de: "Zuordnungsnummer"
    },
    {
        key: "REPORT_PARTNER_PROFIT_CENTER",
        en: "Partner Profit Center",
        de: "Partner Gesellschaftsnummer"
    },
    {
        key: "REPORT_TRANSACTION_TYPE",
        en: "Transaction Type",
        de: "Kostenstelle"
    },
    {
        key: "REPORT_OPERATION_ACTIVITY_NUMBER",
        en: "Operation Activity Number",
        de: "Vorgangsnummer"
    },
    {
        key: "REPORT_MATERIAL_NUMBER",
        en: "Material Number",
        de: "Materialnummer"
    },
    {
        key: "REPORT_KEY_FOR_LINE_ITEM",
        en: "Reference Key For Line Item",
        de: "Referenzschlüssel zur Belegposition"
    },
    {
        key: "REPORT_BUSINESS_PARTNER_REFERENCE_KEY",
        en: "Business Partner Reference Key",
        de: "Refernzschlüssel des Geschäftspartners"
    },
    {
        key: "REPORT_FLAT_CALCULATE_TAX",
        en: "Flat Calculate Tax",
        de: "Kz Steuer berechnen"
    },
    {
        key: "REPORT_CONFIRM_ASSET_CAPITALIZATION",
        en: "Set all listed AssetComponents to AfterCapitalization?",
        de: "Sollen die angezeigten AssetKomponenten alle kapitalisiert werden?"
    },
    {
        key: "REPORT_CONFIRM_ASSET_CAPITALIZATION_TITLE",
        en: "Capitalization",
        de: "Kapitalisierung"
    },
    {
        key: "CAPITALIZATION_FAILED",
        en: "Capitalization failed! No entries available",
        de: "Keine Einträge für die Kapitalisierung verfügbar!"
    },
    {
        key: "CAPITALIZATION_SUCCESS",
        en: "Capitalization successful!",
        de: "Kapitalisierung aller Einträge war erfolgreich!"
    },
    {
        key: "CAPITALIZATION",
        en: "Capitalization",
        de: "Kapitalisierung"
    },
    {
        key: "REPORT_NO_CONTRACT_FOUND_MATCHING_CRITERIA",
        en: "No records were found that match the specified search criteria",
        de: "Es wurden keine Datensätze gefunden, die den angegebenen Suchkriterien entsprechen"
    },
    //PaymentRuleReport
    {
        key: "REPORTING_PAYMENTRULES",
        en: "Payment Rules Report",
        de: "Zahlungsregelereport"
    },
    {
        key: "REPORTS_PAYMENT_RULE_COMPANY",
        en: "Company Code",
        de: "Buchungskreis",
    },
    {
        key: "REPORTS_PAYMENT_RULE_CONTRACTID",
        en: 'Contract Id',
        de: 'Vertrags Id',
        //de: "VertragsId"
    },
    {
        key: "REPORTS_PAYMENT_RULE_CONTRACTNAME",
        en: "Contract name",
        de: "Vertragsname",
    },
    {
        key: "REPORTS_PAYMENT_RULE_OBJECTTYPEID",
        en: "Objecttype Id",
        de: "Objekttyp Id",
        //de: "Objekttyp ID"
    },
    {
        key: "REPORTS_PAYMENT_RULE_COSTCENTER",
        en: "Objecttype Name",
        de: "Anlagenklasse Name",
        //de: "Anlagenklasse Name"
    },
    {
        key: "REPORTS_PAYMENT_RULE_PAYMENTTYPE",
        en: "Payment type",
        de: "Zahlungsart"
    },
    {
        key: "REPORTS_PAYMENT_RULE_PERIODSTART",
        en: "Period start",
        de: "Start der Periode"
    },
    {
        key: "REPORTS_PAYMENT_RULE_PERIODEND",
        en: "Period end",
        de: "Ende der Periode"
    },
    {
        key: "REPORTS_PAYMENT_RULE_RULESTART",
        en: "Payment rule start",
        de: "Start der Zahlungsregel"
    },
    {
        key: "REPORTS_PAYMENT_RULE_RULEEND",
        en: "Payment rule end",
        de: "Ende der Zahlungsregel"
    },
    {
        key: "REPORTS_PAYMENT_RULE_FIXVALUE",
        en: "Payment rules report?",
        de: "Payment rules report?",
        //de: "Zahlungsregelereport"
    },
    {
        key: "REPORTS_PAYMENT_RULE_PAYMENTVALUE",
        en: "Payment value",
        de: "Zahlungsvolumen"
    },
    {
        key: "REPORTS_PAYMENT_RULE_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "REPORTS_PAYMENT_RULE_INTERVAL",
        en: "Payment interval",
        de: "Zahlungsinterval"
    },
    {
        key: "REPORTS_PAYMENT_RULE_FREQUENZ",
        en: "Payment frequency",
        de: "Zahlungsfrequenz"
    },
    {

        key: "REPORTS_PAYMENT_RULE_LCTCONTRACTID",
        en: "Leg ID",
        de: "Leg ID",
        //de: "Leg ID"
    },
    {
        key: "REPORTS_PAYMENT_RULE_LCTOBJECTID",
        en: "Object ID",
        de: "Object ID",
        //de: "Object ID"
    },
    {
        key: "REPORTS_PAYMENT_RULE_LCTCONTRACTHEADERID",
        en: "Header ID",
        de: "Header ID",
        //de: "Header ID"
    },
    {
        key: "REPORTS_PAYMENT_RULE_INTERESTRATE",
        en: "Interest rate",
        de: "Zinsrate"
    },
    {
        key: "REPORTS_PAYMENT_RULE_ASSETCLASSID",
        en: "Objecttype Id",
        de: "Anlagenklasse Id"
    },
    {
        key: "REPORTS_PAYMENT_RULE_ASSETCLASSNAME",
        en: "Objecttype Name",
        de: "Anlagenklasse Name"
    },
    {
        key: "REPORTS_PAYMENT_RULE_ROU_ASSET_CLASS",
        en: "RoU Asset Class ID",
        de: "RoU Anlagenklasse ID"
    },
    {
        key: "REPORTS_PAYMENT_RULE_COSTCENTER",
        en: "Cost center",
        de: "Kostenstelle",
    },
    // Booking Entries Report
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT",
        en: "Booking Entries Report",
        de: "Buchungssätze Report",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_MONTH",
        en: "Monthly Booking Entries Report",
        de: "Monatliche Buchungssätze Report",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_QUARTER",
        en: "Quarter Booking Entries Report",
        de: "Quartal Buchungssätze Report",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_YEAR",
        en: "Yearly Booking Entries Report",
        de: "Jährliche Buchungssätze Report",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_ASSET_SUMMARY",
        en: "Asset Summary Booking Entries Report",
        de: "Objekttyp Buchungssätze Report",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_COMPANY",
        en: "Company",
        de: "Buchungskreis",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_EVALUATION_START",
        en: "Startdate",
        de: "Startdatum",
    },
    {
        key: "REPORTING_BOOKING_ENTRIES_REPORT_EVALUATION_END",
        en: "Enddate",
        de: "Enddatum",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_COMPANY_ID",
        en: "Company Id",
        de: "Buchungskreis Id",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_CONTRACT_ID",
        en: "Contract Id",
        de: "Vertrags Id",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_CONTRACT_NAME",
        en: "Contract name",
        de: "Vertragsname",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_CURRENCY_NAME",
        en: "Currency",
        de: "Währung",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_CONTRACT_END_DATE",
        en: "Contract end date",
        de: "Vertragsende",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_COMMENCEMENT_DATE",
        en: "Commencement date",
        de: "Beginndatum",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INTEREST_RATE",
        en: "Interest rate",
        de: "Zinsrate",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_ASSET_CLASS_NAME",
        en: "Asset class",
        de: "Anlagenklasse",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_ASSET_CLASS_ID",
        en: "Asset class Id",
        de: "Anlagenklasse Id",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_COST_CENTER",
        en: "Cost center",
        de: "Kostenstelle",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_EXPENSE",
        en: "Expense",
        de: "Tilgung",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_EXPENSE_LEDGER_NAME",
        en: "Expense ledger",
        de: "Tilgungskonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_EXPENSE_LEDGER_EXTERNAL_ID",
        en: "Expense ledger number",
        de: "Tilgungskontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INTEREST_SHARE",
        en: "Interest share",
        de: "Zinsanteil",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INTEREST_SHARE_LEDGER_NAME",
        en: "Interest share ledger",
        de: "Zinsanteil Konto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INTEREST_SHARE_LEDGER_EXTERNAL_ID",
        en: "Interest share ledger number",
        de: "Zinsanteil Kontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_LIABILITY_REDUCTION",
        en: "Liability reduction",
        de: "Verbindlichkeitsminderung",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_LIABILITY_REDUCTION_LEDGER_NAME",
        en: "Liability reduction ledger",
        de: "Verbindlichkeitsminderungskonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_LIABILITY_REDUCTION_LEDGER_EXTERNAL_ID",
        en: "Liability reduction ledger number",
        de: "Verbindlichkeitsminderungskontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DEPRECIATION",
        en: "Depreciation",
        de: "Abschreibung",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DEPRECIATION_LEDGER_NAME",
        en: "Depreciation ledger",
        de: "Abschreibungskonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DEPRECIATION_LEDGER_EXTERNAL_ID",
        en: "Depreciation ledger number",
        de: "Abschreibungskontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INITIAL_ASSET_VALUE",
        en: "Initial asset value",
        de: "Startvermögenswert",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INITIAL_ASSET_LEDGER_NAME",
        en: "Initial asset value ledger",
        de: "Startvermögenswertkonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INITIAL_ASSET_LEDGER_EXTERNAL_ID",
        en: "Initial asset value ledger number",
        de: "Startvermögenswertkontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INITIAL_LIABILITY_VALUE",
        en: "Initial liability value",
        de: "Startverbindlichkeit",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INITIAL_LIABILITY_LEDGER_NAME",
        en: "Initial liability value ledger",
        de: "Startverbindlichkeitskonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_INITIAL_LIABILITY_LEDGER_EXTERNAL_ID",
        en: "Initial liability value ledger number",
        de: "Startverbindlichkeitskontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_FIRST_YEAR",
        en: "First year",
        de: "Erstes Jahr",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_SECOND_YEAR",
        en: "Second year",
        de: "Zweites Jahr",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_THIRD_YEAR",
        en: "Third year",
        de: "Drittes Jahr",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_FOURTH_YEAR",
        en: "Fourth year",
        de: "Viertes Jahr",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_FIFTH_YEAR",
        en: "Fifth year",
        de: "Fünftes Jahr",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DECREASE_LIABILITY",
        en: "Decrease liability",
        de: "Abnahmeverbindlichkeit",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DECREASE_LIABILITY_LEDGER_NAME",
        en: "Decrease liability ledger",
        de: "Abnahmeverbindlichkeitskonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DECREASE_LIABILITY_LEDGER_EXTERNAL_ID",
        en: "Decrease liability ledger number",
        de: "Abnahmeverbindlichkeitskontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_ASSET_VALUE",
        en: "Asset value (end of Month)",
        de: "Vermögenswert (Am Ende des Monats)",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_ASSET_VALUE_LEDGER_NAME",
        en: "Asset value ledger",
        de: "Vermögenswertkonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_ASSET_VALUE_LEDGER_EXTERNAL_ID",
        en: "Asset value ledger number",
        de: "Vermögenswertkontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_LIABILITY",
        en: "Liability (end of Month)",
        de: "Verbindlichkeit (Am Ende des Monats)",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_LIABILITY_LEDGER_NAME",
        en: "Liability ledger",
        de: "Verbindlichkeitskonto",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_LIABILITY_LEDGER_EXTERNAL_ID",
        en: "Liability ledger number",
        de: "Verbindlichkeitskontonummer",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_JAN",
        en: "Jan",
        de: "Jan",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_FEB",
        en: "Feb",
        de: "Feb",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_MAR",
        en: "Mar",
        de: "Mär",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_APR",
        en: "Apr",
        de: "Apr",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_MAY",
        en: "May",
        de: "Mai",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_JUN",
        en: "Jun",
        de: "Jun",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_JUL",
        en: "Jul",
        de: "Jul",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_AUG",
        en: "Aug",
        de: "Aug",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_SEP",
        en: "Sep",
        de: "Sep",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_OCT",
        en: "Oct",
        de: "Okt",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_NOV",
        en: "Nov",
        de: "Nov",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_DEC",
        en: "Dec",
        de: "Dez",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_FIRST_QUARTER",
        en: "1st quarter",
        de: "1. Quartal",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_SECOND_QUARTER",
        en: "2nd quarter",
        de: "2. Quartal",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_THIRD_QUARTER",
        en: "3rd quarter",
        de: "3. Quartal",
    },
    {
        key: "BOOKING_ENTRIES_REPORT_FOURTH_QUARTER",
        en: "4th quarter",
        de: "4. Quartal",
    },
    {
        key: "REPORTING_CONTRACT_CONTROLLING_BOOKING_OVERALL_REPORT",
        en: "Contracts Controlling Booking Overall",
        de: "Verträge Controlling Buchung Insgesamt",
    },    
    {
        key: "REPORTING_CONTRACT_CONTROLLING_BOOKING_OVERALL_REPORT_PAYMENT_RULES",
        en: "Payment rules",
        de: "Zahlungsregeln",
    },    
    
]);