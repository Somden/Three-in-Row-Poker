﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
	{
	    key: "FORM_HEADER_EVALUATION_SINGLE",
	    en: "Single Evaluation",
	    de: "Einzel-Evaluation"
	},
	{
	    key: "FORM_HEADER_EVALUATION_PERIOD",
	    en: "Period Evaluation",
	    de: "Evaluation einer Periode"
	},

	{
	    key: "BUTTON_EVALUATE_SINGLE_DATE_INSTEAD",
	    en: "evaluate for a single date instead",
	    de: "stattdessen für ein Einzeldatum evaluieren"
	},

	{
	    key: "FORM_EVALUATION_VIEWSECTION_EVALUATION_DATE",
	    en: "Date",
	    de: "Datum"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_EVALUATION_DATE_START",
	    en: "Start",
	    de: "Start"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_EVALUATION_DATE_END",
	    en: "End",
	    de: "Ende"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_ACCOUNTING_STANDARD",
	    en: "Accounting Standard",
	    de: "Rechnungsvorschrift"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_ASSET_COMPONENT",
	    en: "Asset Component",
	    de: "Vermögenswert Komponente"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_RESULT_LIABILITY_DEMAND",
	    en: "Liability/Demand",
	    de: "Verbindlichkeit/Forderung"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_RESULT_ASSET_VALUE",
	    en: "Asset Value",
	    de: "Vermögenswert"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_RESULT_REMAINING_PAYMENTS",
	    en: "Remaining Payments",
	    de: "Ausstehende Zahlungen"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_RESULT_INTEREST_SHARE_SUM",
	    en: "Interest Share Sum",
	    de: "Zinsanteil Summe"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_RESULT_DEPRECATION",
	    en: "Deprecation",
	    de: "Abschreibung"
	},
	{
	    key: "FORM_EVALUATION_VIEWSECTION_RESULT_PAYMENTS_SUM_NOMINAL",
	    en: "Payments Sum nominal",
	    de: "Nominale Zahlungssumme"
	},
	{
	    key: "EVALUATION_MISSING_FIELDS_HEADER",
	    en: "Empty fields",
	    de: "Leere Felder"
	},
	{
	    key: "EVALUATION_MISSING_FIELDS_TEXT",
	    en: "You have to fill out all fields for calculation",
	    de: "Sie müssen alle Felder für die Berechnung ausfüllen"
	}
]);