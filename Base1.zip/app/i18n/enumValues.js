﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ENUM_CONTRACT_TYPE_LESSOR",
        en: "Lessor",
        de: "Leasinggeber"
    },
    {
        key: "ENUM_CONTRACT_TYPE_LESSEE",
        en: "Lessee",
        de: "Leasingnehmer"
    },

    {
        key: "ENUM_MODIFICATION_TYPE_", // Just there to hide an empty state
        en: "",
        de: ""
    },
    {
        key: "ENUM_MODIFICATION_TYPE_INITIAL",
        en: "Initial",
        de: "Initial"
    },
    {
        key: "ENUM_MODIFICATION_TYPE_MODIFICATION",
        en: "Modification",
        de: "Modifizierung"
    },
    {
        key: "ENUM_MODIFICATION_TYPE_REASSEMENT",
        en: "Reassessment",
        de: "Neubewertung"
    },

    {
        key: "ENUM_CONTRACT_REVISION_STATE_", // Just there to hide an empty state
        en: "",
        de: ""
    },
    {
        key: "ENUM_CONTRACT_REVISION_STATE_VALIDATED",
        en: "Validated",
        de: "Validiert"
    },
    {
        key: "ENUM_CONTRACT_REVISION_STATE_PENDING",
        en: "Pending",
        de: "In Bearbeitung"
    },
    {
        key: "ENUM_CONTRACT_REVISION_STATE_EXPIRED",
        en: "Expired",
        de: "Abgelaufen"
    },
    {
        key: "ENUM_CONTRACT_REVISION_STATE_COMPLETED",
        en: "Completed",
        de: "Abgeschlossen"
    },
    {
        key: "ENUM_CONTRACT_REVISION_STATE_TERMINATED",
        en: "Terminated",
        de: "Terminiert"
    },
    {
        key: "ENUM_LEASE_TYPE_DEACTIVATED",
        en: "Not activated",
        de: "Nicht aktiviert"
    },
    {
        key: "ENUM_LEASE_TYPE_OPERATE",
        en: "Operate",
        de: "Operate"
    },
    {
        key: "ENUM_LEASE_TYPE_FINANCE",
        en: "Finance",
        de: "Finance"
    },
    {
        key: "ENUM_INTERVAL_ONCE",
        en: "Once",
        de: "Einmalig"
    },
    {
        key: "ENUM_INTERVAL_MONTHLY",
        en: "Monthly",
        de: "Monatlich"
    },
    {
        key: "ENUM_INTERVAL_YEARLY",
        en: "Yearly",
        de: "Jährlich"
    }
]);