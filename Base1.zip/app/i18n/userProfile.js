﻿if (translations == null) {
    var translations = [];
} translations = translations.concat([
    {
        key: "FORM_USER_SETTING_EXPORT_HEADER",
        en: "Export Configuration",
        de: "Einstellungen für den Export"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_SPECIFICNAME",
        en: "Specificname",
        de: "Feldname"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_FELDTYPE",
        en: "Field type",
        de: "Feldtyp"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_DEFAULT_VALUE",
        en: "Default value",
        de: "Standardwert"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_EXPORT_FORMAT",
        en: "Export format",
        de: "Export Format"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_TABLE_ACTION",
        en: "Action",
        de: "Aktionen"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_CULTURE",
        en: "Language",
        de: "Sprache"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_SELECT_FELDTYPE",
        en: "select a Field type",
        de: "Feldtyp wählen"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_OUTPUTTYPE",
        en: "Reporting type",
        de: "Exporttyp"
    },
    {
        key: "HELPTEXT_EXPORT_CSV_DELIMITER",
        en: "Formats that use delimiter-separated values",
        de: "CSV Trennzeichen"

    },
    {
        key: "HELPTEXT_EXPORT_CULTURE",
        en: "on witch language is this setting valid (more languages separate with comma ','",
        de: "für welche sprache gilt die Einstellung (mehrere sprachen mit komman ',' trennen"
    },
    {
        key: "HELPTEXT_EXPORT_OUTPUTTYPE",
        en: "on wich Outputtype is this setting valid (more items separate with comma ','",
        de: "für welche export Format gilt die Einstellung (mehrere Einträge mit komman ',' trennen"
    },
    {
        key: "FORM_USER_SETTING_REPORTING_STRING_MAX_LENGTH",
        en: "Text max. length",
        de: "Text maximale Länge"
    }
]);
