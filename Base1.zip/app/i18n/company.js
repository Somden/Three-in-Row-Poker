﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_COMPANY_DETAILS",
        en: "Company Details",
        de: "Unternehmen Details"
    },

    {
        key: "LOADING_COMPANY",
        en: "Loading Company",
        de: "Unternehmen wird geladen"
    },
    {
        key: "LOADING_COMPANIES",
        en: "Companies will be loaded",
        de: "Unternehmen werden geladen"
    },
    {
        key: "LOADING_SAVING_COMPANY",
        en: "Saving company",
        de: "Unternehmen wird gespeichert"
    },
    {
        key: "LOADING_REMOVING_COMPANY",
        en: "Removing company",
        de: "Unternehmen wird entfernt"
    },

    {
        key: "BUTTON_NEW_COMPANY",
	    en: "Add new Company",
	    de: "Unternehmen hinzufügen"
    },
    
    {
        key: "MESSAGE_COMPANY_SAVED",
        en: "Company saved",
        de: "Unternehmen gespeichert"
    },
    {
        key: "MESSAGE_COMPANY_REMOVED",
        en: "Company removed",
        de: "Unternehmen entfernt"
    },
    {
        key: "MESSAGE_COMPANY_IS_DELETED",
        en: "This company is marked as deleted. You can not modify it and you can not choose it in contracts. But it will stay visible in contracts that have this company selected.",
        de: "Dieses Unternehmen ist als gelöscht markiert. Es kann weder editiert werden, noch kann es in Verträgen gewählt werden. Es bleibt aber sichtbar in Verträgen, die dieses Unternehmen bereits gewählt haben."
    },

    {
        key: "TABLE_COMPANIES_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_COMPANIES_COMPANY_CODE",
        en: "Code",
        de: "Code"
    },
    {
        key: "TABLE_COMPANIES_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "TABLE_COMPANIES_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "TABLE_COMPANIES_COMPANYCODE",
        en: "Company Code",
        de: "Buchungskreiscode"
    },
    {
        key: "TABLE_COMPANIES_ISACTIVE",
        en: "Is Active",
        de: "Ist Aktiv"
    },

    {
        key: "FORM_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "FORM_COMPANY_CODE",
        en: "Company Code",
        de: "Buchungskreis"
    }
]);