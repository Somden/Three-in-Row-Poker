﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TOOLTIP_SAVE_WITH_CTRL_ENTER",
        en: "Or: Ctrl + Enter",
        de: "Oder: Strg + Enter"
    },
    {
        key: "TOOLTIP_ARCHIVE",
        en: "Show or hide removed/archived items",
        de: "Zeige oder verdecke archivierte/gelöschte Elemente"
    },
    {
        key: "TOOLTIP_DISCARD_STATE",
        en: "Revert the contract revision to validated state",
        de: "Revert the contract revision to validated state"
    }
    ,
    {
        key: "TOOLTIP_DISCARD_STATE_UNDO",
        en: "Undo revert state",
        de: "Undo revert state"
    }
]);