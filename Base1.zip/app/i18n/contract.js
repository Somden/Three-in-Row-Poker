﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "TITLE_CONTRACTS",
        en: "Contracts",
        de: "Verträge"
    },
    {
        key: "TITLE_CONTRACT_TEMPLATES",
        en: "Templates",
        de: "Vorlagen"
    },
    {
        key: "TITLE_CONTRACT_DETAILS",
        en: "Contract",
        de: "Vertrag"
    },
    {
        key: "TITLE_CONTRACT_TEMPLATE_DETAILS",
        en: "Contract Template",
        de: "Vertragsvorlage"
    },
    {
        key: "TITLE_NEW_CONTRACT",
        en: "New Contract",
        de: "Neuer Vertrag"
    },
    {
        key: "TITLE_NEW_TEMPLATE",
        en: "New Contract Template",
        de: "Neue Vertragsvorlage erstellen"
    },

    {
        key: "TAB_HEADER_COMMON",
        en: "Common data",
        de: "Allgemeine Daten"
    },
    {
        key: "TAB_HEADER_REVISION",
        en: "More Options",
        de: "Mehr Optionen"
    },
    {
        key: "TAB_HEADER_PAYMENTS",
        en: "Payments",
        de: "Zahlungen"
    },
    {
        key: "TAB_HEADER_LEASING_PERIODS",
        en: "Leasing Periods",
        de: "Leasingperioden"
    },
    {
        key: "TAB_HEADER_CONTRACT_LEASING_PERIOD",
        en: "Contract Leasing Period",
        de: "Leasingperiode"
    },
    {
        key: "TAB_HEADER_ASSETS",
        en: "Assets",
        de: "Vermögenswerte"
    },
    {
        key: "TAB_HEADER_LIABILITY_OVERVIEW",
        en: "Calculation",
        de: "Berechnung"
    },
    {
        key: "TABLE_ALL_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_ALL_REVISION",
        en: "Revision",
        de: "Revision"
    },
    {
        key: "TABLE_ALL_STATE",
        en: "State",
        de: "Status"
    },

    {
        key: "TABLE_ALL_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_ALL_REVISION",
        en: "Revision",
        de: "Revision"
    },
    {
        key: "TABLE_ALL_STATE",
        en: "State",
        de: "Status"
    },

    {
        key: "BADGE_VALIDATION_ERRORS",
        en: "Missing or wrong inputs",
        de: "Fehlende oder falsche Eingaben"
    },

    {
        key: "TABLE_ALL_NAME",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "TABLE_ALL_CONTRACT_STATE",
        en: "Revision State",
        de: "Revisionsstatus"
    },
    {
        key: "ENUM_CONTRACT_STATE_ACTIVE",
        en: "Active",
        de: "Aktiv"
    },
    {
        key: "ENUM_CONTRACT_STATE_INACTIVE",
        en: "Inactive",
        de: "Inaktiv"
    },
    {
        key: "ENUM_CONTRACT_STATE_IS_ACTIVE_",
        en: "is active",
        de: "ist aktiv"
    },
    {
        key: "ENUM_CONTRACT_STATE_IS_INACTIVE",
        en: "is inactive",
        de: "ist inaktiv"
    },
    {
        key: "ENUM_CONTRACT_STATE_TEMPLATE",
        en: "Template",
        de: "Vorlage"
    },
    {
        key: "TABLE_ALL_COMPANY_CODE",
        en: "Company code",
        de: "Buchungskreis"
    },
    {
        key: "TABLE_ALL_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "TABLE_ALL_USER",
        en: "Created by",
        de: "Erstellt von"
    },
    {
        key: "TABLE_ALL_ASSET_CATEGORY",
        en: "Asset Category",
        de: "Kategorie"
    },
    {
        key: "TABLE_ALL_ADMIN_ACTIONS",
        en: "Actions",
        de: "Actions"
    },
    {
        key: "TABLE_ALL_MANAGEMENT_UNIT",
        en: "Mangement Unit",
        de: "Mangement Unit"
    },

    {
        key: "BUTTON_NEW_CONTRACT",
        en: "Add new contract",
        de: "Vertrag hinzufügen"
    },
    {
        key: "BUTTON_NEW_TEMPLATE",
        en: "Add new template",
        de: "Vertragsvorlage hinzufügen"
    },
    {
        key: "BUTTON_SAVE",
        en: "Save",
        de: "Speichern"
    },
    {
        key: "BUTTON_SAVE_AND_GO_BACK",
        en: "Save and go back",
        de: "Speichern und zurück"
    },
    {
        key: "BUTTON_CREATE_REASSESSMENT",
        en: "Create Reassessment",
        de: "Neubewertung Erstellen"
    },
	{
	    key: "BUTTON_CREATE_REASSESSMENT_DESCRIPTION",
	    en: "Creates new revision and lets you edit some fields allowed for a reassessment",
	    de: "Erstellt eine neue editierbare Revision und macht alle Felder für eine Neubewertung editiebar"
	},
    {
        key: "BUTTON_CREATE_MODIFICATION",
        en: "Create Modification",
        de: "Modifikation erstellen"
    },
	{
	    key: "BUTTON_CREATE_MODIFICATION_DESCRIPTION",
	    en: "Creates new revision and lets you edit all fields",
	    de: "Erstellt eine neue editierbare Revision. Alle Felder sind editierbar"
	},
    {
        key: "BUTTON_MARK_AS_PENDING",
        en: "Edit current revision",
        de: "Aktuelle Revision editieren"
    },
    {
        key: "BUTTON_MARK_AS_PENDING_DESCRIPTION",
        en: "Lets you edit the current revision by setting back the state from validated to pending",
        de: "Der aktuellen Revision wird der validierte Status entzogen und kann dann komplett editiert werden"
    },
    {
        key: "BUTTON_EDIT_CONTRACT",
        en: "Edit Contract",
        de: "Vertrag editieren"
    },
    {
        key: "BUTTON_TOGGLE_HELP_TOOLTIPS",
        en: "Activate help tooltips",
        de: "Hilfstooltips aktivieren"
    },
    {
        key: "BUTTON_DEFINE_DURATION",
        en: "Define a duration instead",
        de: "Stattdessen eine Dauer angeben"
    },
    {
        key: "BUTTON_DEFINE_TERMINATION_DURATION",
        en: "Define a duration of the shortening instead",
        de: "Stattdessen eine Verkürzungsdauer angeben"
    },
    {
        key: "BUTTON_ENABLE_TERMINATION",
        en: "enable",
        de: "aktivieren"
    },
    {
        key: "BUTTON_NEW_CONTRACT",
        en: "Add new contract",
        de: "Vertrag hinzufügen"
    },
    {
        key: "BUTTON_NEW_TEMPLATE",
        en: "Add new template",
        de: "Vertragsvorlage hinzufügen"
    },
	{
	    key: "BUTTON_SAVE",
	    en: "Save",
	    de: "Speichern"
	},
	{
	    key: "BUTTON_SAVE_AND_GO_BACK",
	    en: "Save and go back",
	    de: "Speichern und zurück"
	},
	{
	    key: "BUTTON_SAVE_AS_VALIDATED",
	    en: "Save as validated contract",
	    de: "Speichern als validierten Vertrag"
	},
	{
	    key: "BUTTON_DISCARD_REASSESSMENT",
	    en: "Discard Changes",
	    de: "Änderungen Verwerfen"
	},
	{
	    key: "BUTTON_REMOVE",
	    en: "Remove",
	    de: "Entfernen"
	},
	{
	    key: "BUTTON_DEFINE_DURATION",
	    en: "Define a duration instead",
	    de: "Stattdessen eine Dauer angeben"
	},
	{
	    key: "BUTTON_DEFINE_TERMINATION_DURATION",
	    en: "Define a duration of the shortening instead",
	    de: "Stattdessen eine Verkürzungsdauer angeben"
	},
	{
	    key: "BUTTON_ENABLE_TERMINATION",
	    en: "enable",
	    de: "aktivieren"
	},
    {
        key: "BUTTON_DEFINE_SCALING_AS_PERCENTAGE",
        en: "Define a percentage instead",
        de: "Stattdessen eine prozentuale Erhöhung angeben"
    },
    {
        key: "BUTTON_DEFINE_SCALING_AS_VALUE",
        en: "Define an absolute value instead",
        de: "Stattdessen einen festen Wert angeben"
    },
    {
        key: "BUTTON_ADD_PAYMENT_RULE",
        en: "Add new payment rule",
        de: "Neue Zahlungsregel hinzufügen"
    },
    {
        key: "BUTTON_ADD_PAYMENT",
        en: "Add new payment",
        de: "Neue Zahlung hinzufügen"
    },
    {
        key: "BUTTON_ADD_ASSET",
        en: "Add new asset",
        de: "Neuen Vermögenswert hinzufügen"
    },
    {
        key: "BUTTON_ADD_ASSET_COMPONENT",
        en: "Add new component",
        de: "Neue Komponente hinzufügen"
    },
    {
        key: "BUTTON_ADD_PURCHASE_OPTION",
        en: "Add new purchase option",
        de: "Neue Kaufoption hinzufügen"
    },
    {
        key: "BUTTON_TAKE_VALUE",
        en: "Use {{ result }} as value",
        de: "{{ result }} als Wert übernehmen"
    },
	{
	    key: "BUTTON_SWITCH_REVISION",
	    en: "Show an older revision...",
	    de: "Eine ältere Revision anzeigen..."
	},
	{
	    key: "BUTTON_SHOW_PAYMENT_VALUES_INSTEAD",
	    en: "show nominal values instead",
	    de: "stattdessen Zahlungen anzeigen"
	},
	{
	    key: "BUTTON_SHOW_PRESENT_VALUES_INSTEAD",
	    en: "show present values instead",
	    de: "stattdessen Barwerte anzeigen"
	},
	{
	    key: "BUTTON_EVALUATE_PERIOD_INSTEAD",
	    en: "evaluate for a date-period instead",
	    de: "stattdessen für eine Zeitperiode evaluieren"
	},
	{
	    key: "BUTTON_RESULTS_MIGHT_BE_OUTDATED",
	    en: "Results might be outdated / Press to reload",
	    de: "Ergebnisse evtl. veraltet / Drücken um neu zu laden"
	},
	{
	    key: "BUTTON_CONTRACT_NEEDS_TO_BE_VALIDATED",
	    en: "Retry when contract is validated",
	    de: "Versuchen Sie es wieder, wenn der Vertrag validiert ist"
	},

    {
        key: "TOOLTIP_DISCARD_REASSESSMENT",
        en: "The contract will be set back to the previous validated revision",
        de: "Der Vertrag wird zur letzten validierten Revision zurückgesetzt"
    },

    {
        key: "LOADING_CONTRACT",
        en: "Loading Contract",
        de: "Vertrag wird geladen"
    },
    {
        key: "LOADING_CONTRACT_TEMPLATE",
        en: "Loading Contract Template",
        de: "Vertragvorlage wird geladen"
    },
    {
        key: "LOADING_CONTRACTS",
        en: "Loading Contracts",
        de: "Verträge werden geladen"
    },
    {
        key: "LOADING_CONTRACT_NEW",
        en: "Loading New Contract",
        de: "Neuer Vertrag wird geladen"
    },
    {

        key: "LOADING_TEMPLATES",
        en: "Loading Contract Templates",
        de: "Vertragsvorlagen werden geladen"
    },
    {
        key: "LOADING_SAVING_CONTRACT",
        en: "Saving Contract",
        de: "Vertrag wird gespeichert"
    },
    {
        key: "LOADING_VALIDATING_CONTRACT",
        en: "Validating Contract",
        de: "Vertrag wird validiert"
    },
    {
        key: "LOADING_CREATE_NEW_REVISION",
        en: "Creating New Revision",
        de: "Es wird eine neue Revision erstellt"
    },
    {
        key: "LOADING_CREATE_NEW_MODIFICATION",
        en: "Creating New Modification",
        de: "Es wird eine neue Modifikation erstellt"
    },
    {
        key: "LOADING_MAKE_REVISION_EDITABLE",
        en: "Setting state of current revision back to pending",
        de: "Die aktuelle Revision wird editierbar gemacht"
    },
    {
        key: "LOADING_DISCARDING_CHANGES",
        en: "Discarding Pending Changes",
        de: "Änderungen werden verworfen"
    },

    {
        key: "MESSAGE_CONTRACT_SAVED",
        en: "Contract saved",
        de: "Vertrag gespeichert"
    },
    {
        key: "MESSAGE_VALIDATED_CONTRACT",
        en: "Contract is now validated",
        de: "Der Vertrag ist nun validiert"
    },
    {
        key: "MESSAGE_CREATED_NEW_REVISION",
        en: "A new revision got created",
        de: "Es wurde eine neue Revision erstellt"
    },
    {
        key: "MESSAGE_REVISION_NOW_EDTABLE",
        en: "The current revision is now editable",
        de: "Die aktuelle Revision is nun editierbar"
    },
    {
        key: "MESSAGE_DISCARDED_CHANGES",
        en: "Pending changes got discarded",
        de: "Änderungen wurden verworfen"
    },
    {
        key: "MESSAGE_NO_PAYMENT_RULE",
        en: "Payment rules are empty.",
        de: "Zahlungsregeln sind leer."
    },
    {
        key: "MESSAGE_NO_PAYMENT",
        en: "Payments are empty.",
        de: "Keine Zahlungen vorhanden."
    },
    {
        key: "MESSAGE_NO_ASSETS",
        en: "Assets are empty.",
        de: "Keine Vermögenswerte vorhanden."
    },
    {
        key: "MESSAGE_NO_ASSET_COMPONENTS",
        en: "Add components to this asset.",
        de: "Fügen Sie diesem Vermögenswert Komponenten hinzu."
    },
    {
        key: "MESSAGE_NO_PURCHASE_OPTION",
        en: "Purchase options are empty.",
        de: "Keine Kaufoptionen vorhanden."
    },
    {
        key: "MESSAGE_ASSET_SHARES_DONT_SUM_TO_100",
        en: "The sum of all asset shares needs to be 100%",
        de: "Die Vermögenswert-Anteile aller Vermögenswert Komponenten müssen zusammen 100% ergeben."
    },
    {
        key: "MESSAGE_CONTRACT_LEASING_PERIOD_MIN_ONE_PAYMENT_RULE",
        en: "You need at least one payment rule for a contract.",
        de: "Die Vertrags-Leasingperiode benötigt mindestens eine Zahlungsregel."
    },
    {
        key: "MESSAGE_SHOWING_NEW_REVISION",
        en: "Changed the displayed revision",
        de: "Anzuzeigenede Revision wurde geändert"
    },
    {
        key: "MESSAGE_NO_CONTRACT_OVERVIEW_CAUSE_MISSING_PERMISSION",
        en: "To see contracts, you need read permissions for a company",
        de: "Um Verträge zu sehen, benötigen Sie Leserechte für ein Unternehmen"
    },
    {
        key: "MESSAGE_NO_CONTRACT_ADD_CAUSE_MISSING_MODIFY_PERMISSION",
        en: "To add new contracts, you need writing-permissions for a company",
        de: "Um neue Verträge hinzuzufügen, brauchen Sie Schreibrechte für ein Unternehmen"
    },
    {
        key: "MESSAGE_CHOOSE_COMPANY_BEFORE_ADDING_ASSET_COMPONENT",
        en: "First choose a company for this contract",
        de: "Wählen Sie zunächst einen Buchungskreis für den Vertrag"
    },

    {
        key: "INFO_CONTRACT_STATE_VALIDATED",
        en: "This contract is in a validated and readonly state.",
        de: "Dieser Vertrag ist im Moment validiert und schreibgeschützt."
    },
    {
        key: "INFO_CONTRACT_NO_MODIFY_RIGHTS",
        en: "This contract is readonly for you cause you don't have the right to modify contracts of the company {{ company }}.",
        de: "Auf diesen vertrag haben Sie nur Leserecht und kein Schreibrecht, da Sie nicht berechtigt sind verträge des Unternehmes {{ company }} zu editieren."
    },
    {
        key: "INFO_CONTRACT_DELETED",
        en: "This contract is deleted and not available anymore.",
        de: "Dieser Vertrag wurde gelöscht und ist nicht mehr verfügbar."
    },
    {
        key: "INFO_CONTRACT_COMPLETED",
        en: "This contract is locked and not editable anymore.",
        de: "Dieser Vertrag wurde gesperrt und ist nicht mehr editierbar."
    },
    {
        key: "INFO_CONTRACT_TERMINATED",
        en: "This contract is terminated and not editable anymore.",
        de: "Dieser Vertrag wurde terminiert und ist nicht mehr editierbar."
    },
    {
        key: "INFO_TERMINATION_DISABLED",
        en: "The termination option is disabled",
        de: "Die Verkürzungsoption is deaktiviert"
    },

    {
        key: "PROMPT_VALIDATE",
        en: "By validating this contract, the contract will be readonly until someone opens up a reassessment/modification.",
        de: "Wenn Sie diesen Vertrag als validiert markieren, dann wird er nicht mehr editierbar sein, bis eine Neubewertung/Modifikation eröffnet wird."
    },
    {
        key: "PROMPT_SET_LESSOR",
        en: "Do you really want to change the contract type to lessor? All values for your right of use asset will be cleared.",
        de: "Wollen Sie wirklich die Vertragsart zu Leasinggeber ändern? Alle Werte der Vermögenswerte werden dann zurückgesetzt."
    },
    {
        key: "PROMPT_SET_UNLIMITED",
        en: "Do you really want to mark the contract as not limited? This will cause all extension leasing periods to be removed.",
        de: "Wollen Sie wikrlich den Vertrag als unlimitiert deklarieren? Dadurch werden alle Verlängerungsoptionen entfernt."
    },
    {
        key: "PROMPT_MODIFY_CONTRACT_HEADER",
        en: "How do you want to edit the contract?",
        de: "Wie wollen Sie den Vertrag editieren?"
    },
    {
        key: "PROMPT_REASSESSMENT_VALIDATE",
        en: "Do you really want to create a reassessment?",
        de: "Wollen Sie wirklich eine Neubewertung erstellen?"
    },
    {
        key: "PROMPT_REASSESSMENT_VALIDATE_DESCRIPTION",
        en: "This will create a new reassessment in pending state. You will be able to discard it as long as it's not validated.",
        de: "Es wird eine Neubewertung im Status Bearbeitung erstellt. Die Neuwewertung kann verworfen werden, solange sie nicht validiert wird."
    },
    {
        key: "PROMPT_REASSESSMENT_VALIDATE_ACTIVATE_DATE",
        en: "When should the reassessment be activated? Must be after {{ currentActivateDate | date: format }}.",
        de: "Wann soll die Neubewertung in Kraft treten? Muss nach dem {{ currentActivateDate | date: format }} sein."
    },
    {
        key: "PROMPT_REASSESSMENT_DISCARD",
        en: "Do you really want to discard the changed in this revision? This revision will be removed the prvious validated revision will be shown.",
        de: "Wollen Sie wirklich alle Änderungen in dieser Revision verwerfen? Danach wird die zuletzt validierte Revision angezeigt."
    },
    {
        key: "PROMPT_NOTEDITABLESTATE_DISCARD",
        en: "Do you really want to discard the completed/terminated state in this contract \"{{description}}\"?",
        de: "Do you really want to discard the completed/terminated state in this contract \"{{description}}\"?"
    },

    {
        key: "PROMPT_MODIFICATION_VALIDATE",
        en: "Do you really want to create a modification?",
        de: "Wollen Sie wirklich eine Modifikation erstellen?"
    },
    {
        key: "PROMPT_MODIFICATION_VALIDATE_DESCRIPTION",
        en: "This will create a new modification in pending state. You will be able to discard it as long as it's not validated.",
        de: "Es wird eine Modifikation im Status Bearbeitung erstellt. Die Neuwewertung kann verworfen werden, solange sie nicht validiert wird."
    },
    {
        key: "PROMPT_MODIFICATION_VALIDATE_ACTIVATE_DATE",
        en: "When should the modification be activated? Must be after {{ currentActivateDate | date: format }}.",
        de: "Wann soll die Modifikation in Kraft treten? Muss nach dem {{ currentActivateDate | date: format }} sein."
    },
    {
        key: "PROMPT_MODIFICATION_DISCARD",
        en: "Do you really want to discard the changed in this revision? This revision will be removed the prvious validated revision will be shown.",
        de: "Wollen Sie wirklich alle Änderungen in dieser Revision verwerfen? Danach wird die zuletzt validierte Revision angezeigt."
    },

    {
        key: "MODAL_PAYMENT_RULE_TITLE_ADD",
        en: "Add Payment Rule",
        de: "Zahlungsregel hinzufügen"
    },
    {
        key: "MODAL_PAYMENT_RULE_TITLE_EDIT",
        en: "Edit Payment Rule",
        de: "Zahlungsregel editieren"
    },
    {
        key: "MODAL_ONE_TIME_PAYMENT_TITLE_ADD",
        en: "Add Payment",
        de: "Zahlung hinzufügen"
    },
    {
        key: "MODAL_ONE_TIME_PAYMENT_TITLE_EDIT",
        en: "Edit Payment",
        de: "Zahlung editieren"
    },
    {
        key: "MODAL_ASSET_TITLE",
        en: "Asset",
        de: "Vermögenswert"
    },
    {
        key: "MODAL_ASSET_TITLE_ADD",
        en: "Add Asset",
        de: "Vermögenswert hinzufügen"
    },
    {
        key: "MODAL_ASSET_TITLE_EDIT",
        en: "Edit Asset",
        de: "Vermögenswert editieren"
    },
    {
        key: "MODAL_ASSET_COMPONENT_TITLE_ADD",
        en: "Add Asset Component",
        de: "Vermögenswert-Komponente hinzufügen"
    },
    {
        key: "MODAL_ASSET_COMPONENT_TITLE_EDIT",
        en: "Edit Asset Component",
        de: "Vermögenswert-Komponente editieren"
    },
    {
        key: "MODAL_ASSET_COMPONENT_VIEW",
        en: "Asset Component",
        de: "Vermögenswert-Komponente"
    },

	{
	    key: "FORM_HEADER_INFOS",
	    en: "Infos",
	    de: "Infos"
	},
	{
	    key: "FORM_HEADER_COMMON_CONTRACT_DATA",
	    en: "Common Contract Information",
	    de: "Allgemeine Vertragsdaten"
	},
	{
	    key: "FORM_HEADER_SAP_FIELDS",
	    en: "Other Data",
	    de: "Sonstige Daten"
	},
	{
	    key: "FORM_HEADER_REVISION_DETAILS",
	    en: "Details about revision no. {{ revisionNr }}",
	    de: "Details zu Revision Nr. {{ revisionNr }}"
	},
	{
	    key: "FORM_HEADER_INITIAL_REVISION_DETAILS",
	    en: "Details for the initial revision",
	    de: "Details für die initiale Revision"
	},
	{
	    key: "FORM_HEADER_ROU_ASSETS",
	    en: "Right Of Use Assets",
	    de: "Right Of Use Vermögenswerte"
	},
	{
	    key: "FORM_HEADER_ADDITIONAL_PAYMENTS",
	    en: "Additional payments",
	    de: "Zusätzliche Zahlungszeitpunkte"
	},
	{
	    key: "FORM_HEADER_ASSETS_AND_ASSET_COMPONENTS",
	    en: "Assets",
	    de: "Vermögenswerte"
	},
    {
        key: "FORM_HEADER_CONTRACT_LEASING_PERIOD",
        en: "Contract Leasing Period",
        de: "Leasingperiode des Vertrags"
    },
    {
        key: "FORM_HEADER_TERMINATION_OPTION",
        en: "Termination Option",
        de: "Verkürzungsoption"
    },
    {
        key: "FORM_HEADER_EXECUTION_VALUE",
        en: "Execution Value",
        de: "Ausübungspreis"
    },
    {
        key: "FORM_HEADER_PAYMENT_RULES",
        en: "Payment Rules",
        de: "Zahlungsregeln"
    },
	{
	    key: "FORM_HEADER_ACCOUNTING_STANDARDS",
	    en: "Activated Accounting Standards",
	    de: "Aktivierte Rechnungsvorschriften"
	},
	{
	    key: "FORM_HEADER_LIABILITY_OVERVIEW",
	    en: "Liability/Demand of activated Leasingperiods",
	    de: "Verbindlichkeit/Forderung der aktivierten Leasingperioden"
	},

	{
	    key: "FORM_HEADER_PAYMENT_OVERVIEW",
	    en: "Payment overview",
	    de: "Übersicht der Zahlungen"
	},

    {
        key: "FORM_ACCOUNTING_STANDARD_IFRS",
        en: "IFRS 16",
        de: "IFRS 16"
    },
    {
        key: "FORM_ACCOUNTING_STANDARD_USGAAP",
        en: "US-GAAP",
        de: "US-GAAP"
    },
    {
        key: "FORM_CONTRACT_USER",
        en: "Created by",
        de: "Erstellt von"
    },
    {
        key: "FORM_CONTRACT_REVISION_REVISION",
        en: "Revisionnr.",
        de: "Revisionsnummer",
    },
    {
        key: "FORM_CONTRACT_REVISION_CONTRACT_REVISION_STATE",
        en: "Revision-State",
        de: "Revisions-Status",
    },
    {
        key: "FORM_CONTRACT_REVISION_MODIFICATIONTYPE",
        en: "Modificationtype",
        de: "Typ",
    },
    {
        key: "FORM_CONTRACT_REVISION_LEGAL_ENTITY",
        en: "Legal entity",
        de: "Legal entity",
    },
    {
        key: "FORM_CONTRACT_REVISION_PROFIT_CENTER",
        en: "Profit Center",
        de: "Profitcenter"
    },
    {
        key: "FORM_CONTRACT_REVISION_COST_CENTER",
        en: "Cost Center",
        de: "Kostenstelle"
    },
    {
        key: "FORM_CONTRACT_TYPE",
        en: "Contract type",
        de: "Vertragsart"
    },
    {
        key: "FORM_CONTRACT_COMPANY",
        en: "Company",
        de: "Buchungskreis"
    },
    {
        key: "FORM_CONTRACT_CURRENCY",
        en: "Currency",
        de: "Währung"
    },
    {
        key: "FORM_CONTRACT_PARTNER",
        en: "Contact person",
        de: "Ansprechpartner"
    },
    {
        key: "FORM_CONTRACT_ADD_PARTNER",
        en: "Add new contact person",
        de: "Neuen Ansprechpartner hinzufügen"
    },
    {
        key: "FORM_CONTRACT_BUTTON_ADD_PARTNER",
        en: "New Partner",
        de: "Neuer Partner"
    },
    {
        key: "FORM_CONTRACT_BUTTON_SELECT_PARTNER",
        en: "Select Partner",
        de: "Partner wählen"
    },
    {
        key: "FORM_IS_INTERNAL_CONTRACT",
        en: "This is an internal contract",
        de: "Das ist ein interner Vertrag"
    },
    {
        key: "FORM_IS_LIMITED",
        en: "This is a limited contract",
        de: "Das ist ein limitierter Vertrag"
    },
    {
        key: "FORM_CONTRACT_CONCLUSION_DATE",
        en: "Date of conclusion",
        de: "Datum Vertragsunterzeichnung"
    },
    {
        key: "HELPTEXT_EFFECTIVE_START_DATE",
        en: "Enter the effective contract start as date (the contract start can be different from the commencement date)",
        de: "Tragen Sie den tatsächlichen Vertragsbeginn als Datum ein (der Vertragsbeginn kann unabhängig vom Beginn des Leasings sein)"
    },
    {
        key: "FORM_CONTRACT_EFFECTIVE_START_DATE",
        en: "Date of effective start",
        de: "Datum tatsächlicher Vertragsbeginn"
    },
    {
        key: "FORM_CONTRACT_COMMENCEMENT_DATE",
        en: "Date of commencement",
        de: "Beginn des Leasingverhältnisses"
    },
	{
	    key: "FORM_REVISION_END_OF_LEASETERM",
	    en: "End of Leaseterm",
	    de: "Ende des Leasingverhältnisses"
	},
	{
	    key: "FORM_EXTERNAL_CONTRACT",
	    en: "External Contract No. / Name",
	    de: "Externe Vertrags-Nr. / Bezeichnung"
	},
	{
	    key: "FORM_MANAGEMENT_UNIT",
	    en: "Management Unit",
	    de: "Management Unit"
	},
	{
	    key: "FORM_IS_TEMPLATE",
	    en: "Save as template",
	    de: "Als Vorlage speichern"
	},
	{
	    key: "FORM_REVISION_REVISION_DESCRIPTION",
	    en: "Description for this revision",
	    de: "Beschreibung für diese Revision"
	},
	{
	    key: "FORM_REVISION_INTEREST_RATE",
	    en: "rate",
	    de: "Zinssatz"
	},
	{
	    key: "FORM_REVISION_ACTIVATE_DATE",
	    en: "Activate date",
	    de: "Aktivierungsdatum"
	},
	{
	    key: "FORM_REVISION_RETIREMENT_DATE",
	    en: "Retirement date",
	    de: "Abgangsdatum"
	},
	{
	    key: "FORM_PAYMENT_PAYMENT_START_DATE",
	    en: "Begin of payments",
	    de: "Beginn der Zahlungen"
	},
	{
	    key: "FORM_ROU_CONTRACT_INITIATION_COSTS",
	    en: "Payment for contract initiation",
	    de: "Zahlung für die Vertragsanbahnung"
	},
	{
	    key: "FORM_ROU_CONTRACT_INITIATION_COSTS_PAYMENT_DATE",
	    en: "Payment Date",
	    de: "Zahlungdatum"
	},
	{
	    key: "FORM_ROU_OTHER_INITIAL_COSTS",
	    en: "Other initial costs",
	    de: "Andere initiale Kosten"
	},
	{
	    key: "FORM_ROU_OTHER_INITIAL_COSTS_PAYMENT_DATE",
	    en: "Payment Date",
	    de: "Zahlungdatum"
	},
	{
	    key: "FORM_ROU_LEASE_INCENTIVES_RECEIVED_AMOUNT",
	    en: "Lease incentives received",
	    de: "Erhaltene Leasinganreize"
	},
	{
	    key: "FORM_ROU_LEASE_INCENTIVES_RECEIVED_AMOUNT_DATE",
	    en: "Payment Date",
	    de: "Zahlungdatum"
	},
	{
	    key: "FORM_ROU_RESTORATION_VALUE",
	    en: "Restoration costs",
	    de: "Restaurationskosten"
	},
	{
	    key: "FORM_ROU_RESTORATION_VALUE_DATE",
	    en: "Payment Date",
	    de: "Zahlungdatum"
	},
	{
	    key: "FORM_ROU_GRANTS",
	    en: "Government grants",
	    de: "Öffentliche Zuschüsse"
	},
	{
	    key: "FORM_ROU_GRANTS_PAYMENT_DATE",
	    en: "Payment Date",
	    de: "Zahlungdatum"
	},
    {
        key: "FORM_ASSET_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "FORM_ASSET_DESCRIPTION",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "FORM_ASSET_NUMBER",
        en: "SAP Number",
        de: "SAP Number"
    },
    {
        key: "FORM_ASSET_SUB_NUMBER",
        en: "SAP Subnumber",
        de: "SAP Subnumber"
    },
    {
        key: "FORM_ASSET_DEFAULT_ASSET_CLASS",
        en: "Default Asset Class",
        de: "Standard Vermögenswertklasse"
    },

    {
        key: "FORM_ASSET_COMPONENT_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "FORM_ASSET_COMPONENT_IS_LIMITED",
        en: "Component is limited",
        de: "Komponente ist limitiert"
    },
    {
        key: "FORM_ASSET_COMPONENT_VALUE_DELTA",
        en: "Value delta",
        de: "Wertdifferenz"
    },
    {
        key: "FORM_ASSET_COMPONENT_ECONOMICAL_USEFUL_LIFE_ENDDATE",
        en: "Economical useful life enddate",
        de: "Ende der wirtschaftlichen Nutzungsdauer"
    },
    {
        key: "FORM_ASSET_COMPONENT_CAPITALIZATION_STARTDATE",
        en: "Capitalization start date",
        de: "Capitalization start date"
    },
    {
        key: "FORM_ASSET_COMPONENT_FAIR_VALUE",
        en: "Fair Value",
        de: "Zeitwert"
    },
    {
        key: "FORM_ASSET_COMPONENT_ASSET_SHARE",
        en: "Asset Share",
        de: "Anteil am Vermögenswert"
    },
    {
        key: "FORM_ASSET_COMPONENT_AMOUNT_CHANGE",
        en: "Amount Change",
        de: "Wertänderung"
    },
    {
        key: "FORM_ASSET_COMPONENT_ASSET_CLASS",
        en: "Asset Class",
        de: "Vermögenswertklasse"
    },
    {
        key: "FORM_ASSET_COMPONENT_SAP_BOOKING_STATE",
        en: "SAP Booking State",
        de: "SAP Buchungsstatus",
    },

    {
        key: "FORM_LEASING_PERIOD_IS_EXPECTED_EXECUTED",
        en: "Will be executed",
        de: "Wird angewandt"
    },
    {
        key: "FORM_LEASING_PERIOD_START_DATE",
        en: "Start date",
        de: "Startdatum"
    },
    {
        key: "FORM_LEASING_PERIOD_END_DATE",
        en: "End date",
        de: "Enddatum"
    },
    {
        key: "FORM_LEASING_PERIOD_DURATION",
        en: "Duration of leasing period",
        de: "Dauer der Leasingperiode"
    },
    {
        key: "FORM_LEASING_PERIOD_EXECUTION_VALUE",
        en: "Execution value",
        de: "Ausübungspreis"
    },
    {
        key: "FORM_LEASING_PERIOD_EXECUTION_DATE",
        en: "Payment Date",
        de: "Zahlungdatum"
    },
    {
        key: "FORM_TERMINATION_OPTION_ENABLED",
        en: "Enabled",
        de: "Aktiviert"
    },
    {
        key: "FORM_TERMINATION_OPTION_DISABLED",
        en: "Disabled",
        de: "Deaktiviert"
    },
    {
        key: "FORM_TERMINATION_OPTION_DURATION",
        en: "Reduces contract by..",
        de: "Verkürzt den Vertrag um.."
    },
    {
        key: "FORM_TERMINATION_EXECUTION_VALUE",
        en: "Execution value",
        de: "Ausübungspreis"
    },
    {
        key: "FORM_TERMINATION_EXECUTION_DATE",
        en: "Payment Date",
        de: "Zahlungdatum"
    },
    {
        key: "FORM_TERMINATION_IS_EXPECTED_EXECUTED",
        en: "The termination option is executed",
        de: "Die Verkürzungsoption wird angewandt"
    },
    {
        key: "FORM_TERMINATION_OPTION_END_DATE",
        en: "Enddate",
        de: "Enddatum"
    },
    {
        key: "FORM_PAYMENT_RULE_DESCRIPTION",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "FORM_PAYMENT_RULE_DESCRIPTION_SET_OWN",
        en: "Set an own description",
        de: "Eine eigene Beschreibung setzen"
    },
    {
        key: "FORM_PAYMENT_RULE_DESCRIPTION_SET_AUTO",
        en: "Generate description automatically",
        de: "Beschreibung automatisch generieren lassen"
    },
    {
        key: "FORM_PAYMENT_RULE_SCALING",
        en: "Scaling",
        de: "Skalierung"
    },
    {
        key: "FORM_PAYMENT_RULE_PERCENTAGE_SCALING_VALUE",
        en: "Scaling value",
        de: "Erhöhung um"
    },
    {
        key: "FORM_PAYMENT_RULE_ABSOLUTE_SCALING_VALUE",
        en: "Scaling value",
        de: "Erhöhung um"
    },
    {
        key: "FORM_PAYMENT_RULE_SCALING_FREQUENCY",
        en: "Scale up payment value every",
        de: "Zahlungsbetrag erhöhen alle"
    },
    {
        key: "FORM_PAYMENT_RULE_IN_SUBSTANCE_PAYMENT_VALUE",
        en: "In Substance fixed payment value",
        de: "Quasi fixer Betrag"
    },
    {
        key: "FORM_PAYMENT_RULE_PAYMENT_VALUE",
        en: "Value",
        de: "Betrag"
    },
    {
        key: "FORM_PAYMENT_RULE_PAYMENT_FREQUENCY",
        en: "Every",
        de: "Alle"
    },
    {
        key: "FORM_PAYMENT_RULE_PAYMENT_INTERVAL",
        en: "Interval",
        de: "Interval"
    },
    {
        key: "FORM_PAYMENT_RULE_PAYMENT_END_DATE",
        en: "End",
        de: "Ende"
    },
    {
        key: "FORM_PAYMENT_RULE_PAYMENT_START_DATE",
        en: "Start",
        de: "Start"
    },
    {
        key: "FORM_PAYMENT_RULE_PAYMENT_PAY_DATE",
        en: "Paydate",
        de: "Zahldatum"
    },
    {
        key: "FORM_PAYMENT_RULE_INDEXED_BASED",
        en: "This payment rule should be index based",
        de: "Diese Zahlungsregel soll Index-basiert sein"
    },
    {
        key: "FORM_PAYMENT_RULE_SCALING_ENABLED",
        en: "Let the payment value scale over time",
        de: "Der Zahlungsbetrag soll mit der Zeit skalieren"
    },
    {
        key: "FORM_HAS_TERMINATION_OPTION",
        en: "Contract has an option to terminate earlier",
        de: "Vertrag hat die Option frühzeitig zu terminieren"
    },
    {
        key: "TABLE_START_DATE",
        en: "Start date",
        de: "Startdatum"
    },
    {
        key: "TABLE_END_DATE",
        en: "End date",
        de: "Enddatum"
    },
   {
       key: "TABLE_TYPE",
       en: "Type",
       de: "Typ"
   },
    {
        key: "TABLE_DURATION_DAYS",
        en: "Days",
        de: "Tage"
    },
    {
        key: "TABLE_PRESENT_VALUE",
        en: "Present values",
        de: "Barwerte"
    },
    {
        key: "TABLE_NOMINAL_VALUE",
        en: "Nominal values",
        de: "Zahlungswerte"
    },
    {
        key: "TABLE_LIABILITY_VALUE_TOTAL",
        en: "Total",
        de: "Gesamt"
    },
    {
        key: "TABLE_LIABILITY_VALUE_PAYMENT_RULE",
        en: "Payment rule",
        de: "Zahlungen"
    },
    {
        key: "TABLE_LIABILITY_VALUE_PAYMENT_RULE_RATE",
        en: "Payment rule rate",
        de: "Zahlungsraten"
    },
    {
        key: "TABLE_LIABILITY_VALUE_PAYMENT_RULE_IN_SUBSTANCE",
        en: "In-substance payments",
        de: "Quasi-fixe Zahlungen"
    },
    {
        key: "TABLE_LIABILITY_VALUE_MANUAL_PAYMENT",
        en: "Manual payment",
        de: "Einmalzahlungen"
    },
    {
        key: "TABLE_LIABILITY_VALUE_EXTENSION_OPTION",
        en: "Extension option",
        de: "Erweiterungsoptionen"
    },
    {
        key: "TABLE_LIABILITY_VALUE_TERMINATION_OPTION",
        en: "Termination option",
        de: "Verkürzungsoption"
    },
    {
        key: "TABLE_NOMINAL_PAYMENT",
        en: "Nominal payment",
        de: "Zahlung"
    },
    {
        key: "TABLE_ROWTYPE_TOTAL",
        en: "Total",
        de: "Gesamt"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_PAYMENT_START_DATE",
        en: "Start",
        de: "Start"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_PAYMENT_END_DATE",
        en: "End",
        de: "Ende"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_PAYMENT_INTERVAL",
        en: "Interval",
        de: "Interval"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_PAYMENT_VALUE",
        en: "Value",
        de: "Betrag"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_SCALING",
        en: "Scaling",
        de: "Skalierung"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_SCALING_FREQUENCY",
        en: "Scale up every..",
        de: "Erhöhen alle.."
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_ABSOLUTE_SCALING_VALUE",
        en: "Value",
        de: "Betrag"
    },
    {
        key: "TABLE_HEADER_PAYMENT_RULE_PERCENTAGE_SCALING_VALUE",
        en: "Percent",
        de: "Prozent"
    },
    {
        key: "TABLE_HEADER_ONE_TIME_PAYMENT_DESCRIPTION",
        en: "Description",
        de: "Beschreibung"
    },
    {
        key: "TABLE_HEADER_ONE_TIME_PAYMENT_DATE",
        en: "Date",
        de: "Datum"
    },
    {
        key: "TABLE_HEADER_ONE_TIME_PAYMENT_VALUE",
        en: "Value",
        de: "Betrag"
    },
    {
        key: "TABLE_HEADER_PAYMENT_DATE",
        en: "Payment date",
        de: "Zahlungsdatum"
    },
    {
        key: "FORM_ONE_TIME_PAYMENT",
        en: "Payment Date",
        de: "Zahltag"
    },
    {
        key: "FORM_HEADER_PAYMENTS",
        en: "Payments",
        de: "Zahlungen"
    },
    {
        key: "FORM_HEADER_EXTENSION_LEASING_PERIOD",
        en: "Extension Leasing Period",
        de: "Erweiterungsperiode"
    },

    {
        key: "FORM_HEADER_REVISION_RESIDUAL_VALUE",
        en: "Residual value",
        de: "Restwert"
    },
    {
        key: "FORM_HEADER_REVISION_PURCHASE_OPTION",
        en: "Purchase Option",
        de: "Kaufoptionen"
    },
    {
        key: "FORM_REVISION_USE_INTEREST_RATE",
        en: "Use Interest rate",
        de: "Implizierter Zinssatz"
    },
    {
        key: "FORM_REVISION_BORROWING_RATE",
        en: "rate",
        de: "Zinssatz"
    },
    {
        key: "FORM_REVISION_IS_LOW_VALUE_CONTRACT",
        en: "Low Value",
        de: "Geringwertausnahme"
    },
    {
        key: "FORM_REVISION_IS_SHORT_TERM_LEASE",
        en: "Short Term Lease",
        de: "Kurzfristausnahme"
    },
    {
        key: "FORM_REVISION_TRANSFER_OF_OWNERSHIP",
        en: "Transfer of ownership",
        de: "Autom. Eigentumsübergang"
    },
    {
        key: "FORM_REVISION_RESIDUAL_VALUE",
        en: "Guaranteed residual value",
        de: "Restwert"
    },
    {
        key: "FORM_REVISION_RESIDUAL_DATE",
        en: "Payment Date",
        de: "Zahlungsdatum"
    },
    {
        key: "FORM_REVISION_USE_BORROWING_RATE",
        en: "Use Borrowing rate",
        de: "Grenzfremdkapitalzinssatz"
    },
    {
        key: "HELPTEXT_REVISION_BORROWING_RATE",
        en: "The rate of interest that a lessee would have to pay to borrow over a similar term, and with a similar security, the funds necessary to obtain an asset of a similar value to the right-of-use asset in a similar economic environment. The applicable incremental borrowing rates will be announced by IFA.",
        de: "Der Grenzfremdkapitalzinssatz des Leasingnehmers ist der Zinssatz, den der Leasingnehmer bei einer fiktiven Fremdfinanzierung mit gleicher Betragshöhe und gleicher Laufzeit anzunehmen hätte. Ist im Vertrag kein impliziter Zinssatz angeführt, so ist der Grenzfremdkapitalzinssatz zu verwenden. Die zu verwendenden Grenzfremdkapitalzinssätze werden durch IFA bekannt gegeben."
    },
    {
        key: "TABLE_REVISION_PURCHASE_OPTION_ISEXECUTED",
        en: "Execution",
        de: "Ausübung"
    },
    {
        key: "MODAL_REVISION_PURCHASE_OPTION_TITLE_EDIT",
        en: "Edit Purchase Option",
        de: "Kaufoption bearbeiten"
    },
    {
        key: "MODAL_REVISION_PURCHASE_OPTION_TITLE_ADD",
        en: "Add new Purchase Option",
        de: "Kaufoption hinzufügen"
    },
    {
        key: "MODAL_REVISION_PURCHASE_OPTION_ISEXECUTED",
        en: "Is executed",
        de: "Ausübung"
    },
    {
        key: "MODAL_REVISION_PURCHASE_OPTION_PAYMENTDATE",
        en: "Payment date",
        de: "Datum"
    },
    {
        key: "MODAL_REVISION_PURCHASE_OPTION_PAYMENTVALUE",
        en: "Value",
        de: "Betrag"
    },
    {
        key: "TABLE_REVISION_PAYMENTDATE",
        en: "Payment date",
        de: "Datum"
    },
    {
        key: "TABLE_REVISION_PAYMENTVALUE",
        en: "Value",
        de: "Betrag"
    },

    {
        key: "LEASING_PERIOD_ALL_LEASING_PERIODS",
        en: "All Leasingperiods",
        de: "Alle Leasingperioden"
    },
    {
        key: "LEASING_PERIOD_CONTRACT_LEASING_PERIOD",
        en: "Contract Leasing Period",
        de: "Vertragslaufzeit"
    },
    {
        key: "LEASING_PERIOD_CONTRACT_EXTENSION_PERIOD",
        en: "Contract Extension Period",
        de: "Verlängerungsoption"
    },
    {
        key: "LEASING_PERIOD_MORE_BUTTON",
        en: "more",
        de: "weitere"
    },
    {
        key: "LEASING_PERIOD_CAN_BE_EXECUTED_FOR",
        en: "can be executed for",
        de: "kann ausgeführt werden für"
    },
    {
        key: "LEASING_PERIOD_WILL_BE_EXECUTED_FOR",
        en: "will be executed for",
        de: "wird ausgeführt für"
    },
    {
        key: "LEASING_PERIOD_PAID_UNTIL",
        en: "paid until",
        de: "zu zahlen bis zum"
    },
    {
        key: "LEASING_PERIOD_EXTENDS_CONTRACT_UNTIL",
        en: "Extends the contract until",
        de: "Verlängert Vertrag bis zum"
    },
    {
        key: "LEASING_PERIOD_CAN_EXTEND_CONTRACT_UNTIL",
        en: "Can extend the contract until",
        de: "Kann Vertrag verlängern bis zum"
    },
    {
        key: "LEASING_PERIOD_WITH_OPTION_TO_TERMINATE",
        en: "with option to terminate",
        de: "mit der Option zu verkürzen"
    },
    {
        key: "LEASING_PERIOD_CAUSE_OF_TERMINATION_OPTION",
        en: "cause of termination option",
        de: "wegen Verkürzungsoption"
    },
    {
        key: "LEASING_PERIOD_ADD",
        en: "Add a new leasing period",
        de: "Neue Verlängerungsoption"
    },
    {
        key: "MODAL_CLASSIFY_TYPE_OF_LEASE_TITLE",
        en: "Classification",
        de: "Klassifikation"
    },
    {
        key: "CALCULATE_CLASSIFY_TYPE",
        en: "Calculating classify type",
        de: "Klassifikation wird berechnet"
    },
    {
        key: "CLASSIFY_TYPE_SPECIALISATION",
        en: "specialisation",
        de: "spezialisierung"
    },
    {
        key: "HELPTEXT_CLASSIFY_TYPE_SPECIALISATION",
        en: "Set a marker in the checkbox if the leased asset is procured in such a specific manner that only the corporation can use it appropriately. In this case, a finance lease exists.",
        de: "Markieren Sie das Kontrollfeld, wenn es sich um einen Leasinggegenstand handelt, der derart speziell beschaffen ist, dass nur das Unternehmen diesen sinnvoll einsetzen kann. In diesem Fall liegt ein finance lease vor."
    },
    {
        key: "HELPTEXT_CLASSIFY_PERCENTAGE_OF_PRESENT_VALUE",
        en: "Enter the percentage threshold for the recovery of investment test.",
        de: "Geben Sie den prozentualen Schwellenwert für den Barwerttest an."
    },
    {
        key: "MODAL_CLASSIFY_PERCENTAGE_OF_PRESENT_VALUE",
        en: "Recovery of Investment Test  (bright line)",
        de: "Barwertschwelle"
    },
    {
        key: "MODAL_CLASSIFY_ECONOMICLIFE",
        en: "Economic life test",
        de: "Nutzungsdauertest"
    },
    {
        key: "HELPTEXT_CLASSIFY_ECONOMICLIFE",
        en: "Automatic calculation of the ratio of contract term and economic useful life. The checkbox is marked automatically if the ratio exceeds the defined threshold. In this case, a finance lease exists.",
        de: "Automatische Berechnung des Quotienten aus Vertragslaufzeit und wirtschaftlicher Nutzungsdauer. Sofern der Quotient den festgelegten Schwellenwert überschritten hat, wird das Kontrollfeld automatisch markiert. In diesem Fall liegt ein finance lease vor."

    },
    {
        key: "MODAL_CLASSIFY_ECONOMICLIFE_VALUE",
        en: "Economic life test (brightline)",
        de: "Nutzungsdauerschwelle"
    },
    {
        key: "HELPTEXT_CLASSIFY_ECONOMICLIFE_VALUE",
        en: "Enter the percentage threshold for the useful life test.",
        de: "Geben Sie den prozentualen Schwellenwert für den Nutzungsdauertest an."
    },
    {
        key: "MODAL_CLASSIFY_ECONOMICLIFE",
        en: "Economic life test",
        de: "Nutzungsdauertest"
    },
    {
        key: "HELPTEXT_CLASSIFY_ECONOMICLIFE",
        en: "Automatic calculation of the ratio of contract term and economic useful life. The checkbox is marked automatically if the ratio exceeds the defined threshold. In this case, a finance lease exists.",
        de: "Automatische Berechnung des Quotienten aus Vertragslaufzeit und wirtschaftlicher Nutzungsdauer. Sofern der Quotient den festgelegten Schwellenwert überschritten hat, wird das Kontrollfeld automatisch markiert. In diesem Fall liegt ein finance lease vor."
    },
    {
        key: "MODAL_CLASSIFY_RECOVERY_OF_INVESTMENT",
        en: "Recovery of Investment Test",
        de: "Barwerttest"
    },
    {
        key: "HELPTEXT_CLASSIFY_RECOVERY_OF_INVESTMENT",
        en: "Automatic calculation of the present value as well as the comparison with the fair value of the asset. The checkbox is marked automatically if the ratio of present value and fair value exceeds the defined threshold. In this case, a finance lease exists.",
        de: "Automatische Berechnung des Barwerts sowie des Vergleichs mit dem fair value des Vermögenswerts. Sofern der Quotient aus Barwert und fair value den festgelegten Schwellenwert überschritten hat, wird das Kontrollfeld automatisch markiert. In diesem Fall liegt ein finance lease vor."
    },
    {
        key: "MODAL_CLASSIFY_AUTOMATICTRANSFER",
        en: "Automatic transfer of ownership",
        de: "Eigentumsübergang"
    },
    {
        key: "HELPTEXT_CLASSIFY_AUTOMATICTRANSFER",
        en: "Datafield is marked automatically, if there is an agreement about automatic transfer of ownership of the leased asset to the lessee.",
        de: "Dieses Feld befüllt sich automatisch, wenn im Zuge der Modifikation ein automatischer Eigentumsübergang des Leasingobjekts vom Leasinggeber auf den Leasingnehmer vereinbart wurde. In diesem Fall liegt ein finance lease vor."
    },
    {
        key: "HELPTEXT_CLASSIFY_BARGIN_PURCHASE",
        en: "This data field is marked automatically, if the estimation of the execution of a purchase option changes into “Certain to be exercised” or if a purchase option was added which is estimated as certain to be exercised. In this case, a finance lease exists.",
        de: "Dieses Datenfeld befüllt sich automatisch, wenn sich im Zuge einer Modifikation die Einschätzung zur Ausübung einer Kaufoption hin zu „sicher ausgeübt“ ändert bzw. durch die Modifikation eine Kaufoption hinzugefügt wurde, welche gleichzeitig als sicher ausübbar einzuschätzen ist. In diesem Fall liegt ein finance lease vor."
    },
    {
        key: "MODAL_CLASSIFY_BARGIN_PURCHASE",
        en: "Bargain purchase option",
        de: "Günstige Kaufoption"
    },
    {
        key: "MODAL_CLASSIFY_AUTOMATIC_CLASSIFICATION",
        en: "Automatic classification",
        de: "Vorgeschlagene Klassifikation"
    },
    {
        key: "HELPTEXT_CLASSIFY_AUTOMATIC_CLASSIFICATION",
        en: "The field shows the result of the automatic classification.",
        de: "Das Feld zeigt das Ergebnis der automatischen Klassifizierung."
    },
    {
        key: "HELPTEXT_CLASSIFY_AUTOMATIC_CLASSIFICATION_BUTTON",
        en: "Press the Check Button to get an assessment for the classification based on the entered data.",
        de: "Beim Klicken des Buttons Check wird eine Neuklassifikation zwischen Leasinggeber und/oder Leasingnehmer durchgeführt."
    },
    {
        key: "TAB_HEADER_COMMENT",
        en: "Comments",
        de: "Kommentare"
    },
    {
        key: "TAB_HEADER_PREVIEW",
        en: "Printable",
        de: "Druckbar"
    },
    {
        key: "FORM_HEADER_COMMENT",
        en: "Comments",
        de: "Kommentare"
    },
    {
        key: "FORM_GENERAL_COMMENT",
        en: "General comments",
        de: "Allgemeine Kommentare"
    },
    {
        key: "HELPTEXT_GENERAL_COMMENT",
        en: "Enter general comments",
        de: "Tragen Sie hier allgemeine Kommentare ein."
    },
    {
        key: "HELPTEXT_COMMENT_CONTRACT_ADJUSTMENT",
        en: "Enter the comments related to other contractual adjustments.",
        de: "Tragen Sie Kommentare zu sonstigen Vertragsanpassungen ein."
    },
    {
        key: "FORM_COMMENT_CONTRACT_ADJUSTMENT",
        en: "Comment contract adjustments",
        de: "Kommentar Vertragsänderungen"
    },
    {
        key: "FORM_COMMENT_TERMINATION",
        en: "Comment Termination",
        de: "Kommentar Kündigung"
    },
    {
        key: "HELPTEXT_COMMENT_TERMINATION",
        en: "Enter the comments related to the contractual term and especially for the termination of a lease contract.",
        de: "Tragen Sie Kommentare zur Vertragslaufzeit insbesondere zur Kündigung eines Leasingvertrages ein."
    },
    {
        key: "FORM_COMMENT_INDEX_BINDING",
        en: "Comment Index binding",
        de: "Kommentar Indexbindung"
    },
    {
        key: "HELPTEXT_COMMENT_INDEX_BINDING",
        en: "Enter the comments related to indexation of the payments (e.g. the actual underlying index, for example: VPI 2000/2005)",
        de: "Tragen Sie Kommentare zur Indexbindung der Zahlungen ein (z.B. den aktuell zugrundeliegenden Index, bspw. VPI 2000/2005)."
    },
    {
        key: "BUTTON_COPY_AS_CONTRACT",
        en: "as Contract",
        de: "Als Vertrag"
    },
    {
        key: "DECLINED_COPY_CONTRACT_COMMENT",
        en: "You can copy only inital contract.",
        de: "Sie können nur den ursprünglichen Vertrag kopieren"
     },
     {
         key: "BUTTON_COPY_AS_TEMPLATE",
         en: "as Template",
         de: "Als Vorlage"
     },
    {
        key: "BUTTON_COPY",
        en: "Copy",
        de: "Kopieren"
    },
    {
        key: "REMOVING_CONTRACT",
        en: "Removing Contract",
        de: "Vertrag wird gelöscht"
    },
    {
        key: "REMOVING_CONTRACT_TEMPLATE",
        en: "Removing Contract Template",
        de: "Vertragvorlage Wird gelöscht"
    },
    {
        key: "PROMPT_DELETE_TEMPLATE",
        en: "Do you really want to delete the Template?",
        de: "Wollen Sie wirklich die Vorlage löschen?"
    },
    {
        key: "PROMPT_DELETE_CONTRACT",
        en: "Do you really want to delete the contract?",
        de: "Wollen Sie wirklich den Vertrag löschen?"
    },
    {
        key: "LOADING_CONTRACT_REVISION",
        en: "Loading Contract Revision",
        de: "Vertragsrevision Wird Geladen"
    },
    {
        key: "BUTTON_NEXT_CONTRACTREVISION",
        en: "Next Contract Revision",
        de: "nächste Vertrags revision"
    },
    {
        key: "BUTTON_PREVIEW_CONTRACTREVISION",
        en: "Preview Contract Revision",
        de: "vorherige Vertragsrevision"
    },
    {
        key: "LOADIN_CHANGE_STATE",
        en: "Changing Contrate State",
        de: "Status wird geändert"
    },
    {
        key: "BUTTON_MARK_AS_COMPLETED",
        en: "Lock contract",
        de: "Vertrag sperren"
    },
    {
        key: "BUTTON_MARK_AS_TERMINATED",
        en: "Terminate Contract",
        de: "Vertrag terminieren"
    },
    {
        key: "LOADING_CHANGE_STATE",
        en: "Contract will be updated",
        de: "Vertrag wird aktualisiert"
    },
    {
        key: "PROMPT_CONFIRM_TERMINATE_CONTRACT",
        en: "Do you really want to provisionally terminate the Contract?",
        de: "Möchten Sie den Vertrag wirklich vorzeitig beenden?"
    },
    {
        key: "PROMPT_CONFIRM_COMPLETE_CONTRACT",
        en: "Do you really want to lock the Contract?",
        de: "Möchten Sie den Vertrag wirklich sperren?"
    },
    {
        key: "PROMPT_COMPLETE_CONTRACT_DESCRIPTION",
        en: "If you lock the contract, you won't be able to edit it anymore.",
        de: "Wenn Sie den Vertrag jetzt sperren, werden Sie keine Änderungen mehr vornehmen können."
    },
    {
        key: "PROMPT_TERMINATE_CONTRACT_DESCRIPTION",
        en: "If you terminate the contract, you won't be able to recover it anymore.",
        de: "Wenn Sie den Vertrag jetzt terminieren, dann werden Sie ihn nicht mehr wiederherstellen können."
    },
    {
        key: "PROMPT_TERMINATION_DATE",
        en: "When should the contract be terminated? Must be after {{ activateDate | date: format }}.",
        de: "Wann soll der Vertrag terminiert werden? Muss nach dem {{ activateDate | date: format }} sein."
    },
    {
        key: "PROMPT_COMPLETION_DATE",
        en: "When should the contract be comleted? Must be after {{ activateDate | date: format }}.",
        de: "Wann soll der Vertrag abgeschlossen werden? Muss nach dem {{ activateDate | date: format }} sein."
    },

    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_OBJECTS_WILL_BE_REMOVED",
        en: "Those objects will be removed, if they are too old:",
        de: "Folgende Objekte werden entfernt, falls sie zu alt sind:"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_PURCHASE_OPTIONS",
        en: "Purchase options",
        de: "Kaufoptionen"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_PURCHASE_OPTIONS_DESCRIPTION",
        en: "If payment date older or equal to new activate date.",
        de: "Wenn die Zahlungsregel älter oder gleich dem Aktivierungsdatum ist."
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_PAYMENT_RULES",
        en: "Payment rules",
        de: "Zahlungsregeln"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_PAYMENT_RULES_DESCRIPTION",
        en: "If end date older or equal to new activate date.",
        de: "Wenn das Enddatum älter oder gleich dem Aktivierungsdatum ist."
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_EXECUTION_OF_EXTENSION_LEASING_PERIOD",
        en: "Execution payment and date of extension leasing periods",
        de: "Ausführungsdatum und -zahlung der Verlängerungsoptionen"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_EXECUTION_OF_EXTENSION_LEASING_PERIOD_DESCRIPTION",
        en: "If execution date older or equal to new activate date.",
        de: "Wenn das Ausführungsdatum älter oder gleich dem Aktivierungsdatum ist."
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_EXECUTION_OF_TERMINATION_OPTION",
        en: "Execution payment and date of termination options",
        de: "Ausführungsdatum und -zahlung der Verkürzungsoptionen"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_EXECUTION_OF_TERMINATION_OPTION_DESCRIPTION",
        en: "If execution date older or equal to new activate date.",
        de: "Wenn das Ausführungsdatum älter oder gleich dem Aktivierungsdatum ist."
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_EXECUTION_OF_REVISION",
        en: "Execution payment and date of residual value",
        de: "Ausführungsdatum und -zahlung des Restwerts"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_EXECUTION_OF_REVISION_DESCRIPTION",
        en: "If execution date older or equal to new activate date.",
        de: "Wenn das Ausführungsdatum älter oder gleich dem Aktivierungsdatum ist."
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_DATES_WILL_BE_MODIFIED",
        en: "Those dates will be set to one day after the activate date, if they are older or equal to the new activate date:",
        de: "Bei folgenden Elementen wird das Datum auf einen Tag nach dem Aktivierungsdatum gesetzt, falls das Datum älter oder gleich dem Aktivierungsdatum ist."
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_STARTDATE_OF_PAYMENT_RULES",
        en: "Startdate of payment rules",
        de: "Startdatum der Zahlungsregeln"
    },
    {
        key: "CONTRACT_ASK_FOR_REASSESSMENT_ITEM_STARTDATE_OF_PAYMENT_RULES_DESCRIPTION",
        en: "If activate date is between the payment start and end date.",
        de: "Wenn das Aktivierungsdatum zwischen Start- und Enddatum der Zahlungsregel liegt."
    },
    {
        key: "FORM_IS_SUB_LEASE",
        en: "Is Sub Lease",
        de:"Ist Untervermietung"
    }
]);