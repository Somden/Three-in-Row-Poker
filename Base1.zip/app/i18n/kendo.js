﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "KENDO_GRID_DISPLAY",
        en: "{0} - {1} of {2} items",
        de: "{0} - {1} von {2} Elementen"
    },
    {
        key: "KENDO_GRID_EMPTY",
        en: "No items to display",
        de: "Keine Elemente vorhanden"
    },
    {
        key: "KENDO_GRID_PAGE",
        en: "Page",
        de: "Seite"
    },
    {
        key: "KENDO_GRID_ALLPAGES",
        en: "All",
        de: "Alle"
    },
    {
        key: "KENDO_GRID_OF",
        en: "of {0}",
        de: "von {0}"
    },
    {
        key: "KENDO_GRID_ITEMSPERPAGE",
        en: "items per page",
        de: "Elemente pro Seite"
    },
    {
        key: "KENDO_GRID_FIRST",
        en: "Go to the first page",
        de: "Gehe zur ersten Seite"
    },
    {
        key: "KENDO_GRID_PREVIOUS",
        en: "Go to the previous page",
        de: "Gehe zur vorigen Seite"
    },
    {
        key: "KENDO_GRID_NEXT",
        en: "Go to the next page",
        de: "Gehe zur nächsten Seite"
    },
    {
        key: "KENDO_GRID_LAST",
        en: "Go to the last page",
        de: "Gehe zur letzten Seite"
    },
    {
        key: "KENDO_GRID_REFRESH",
        en: "Refresh",
        de: "Neu laden"
    },
    {
        key: "KENDO_GRID_GROUPABLE_EMPTY",
        en: "Drag a column header and drop it here to group by that column",
        de: "Ziehe einen Spaltenkopf hierher um nach der Spalte zu gruppieren"
    },
    {
        key: "KENDO_GRID_FILTERABLE_INFO",
        en: "Show items with value that:",
        de: "Zeige nur Elemente mit Wert:"
    },
    {
        key: "KENDO_GRID_FILTERABLE_IS_FALSE",
        en: "False",
        de: "Nein"
    },
    {
        key: "KENDO_GRID_FILTERABLE_IS_TRUE",
        en: "True",
        de: "Ja"
    },
    {
        key: "KENDO_DROPDOWN_EMPTY_ELEMENT",
        en: "Select..",
        de: "Wählen.."
    }
]);