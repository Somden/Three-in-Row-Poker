﻿if (translations == null) {
    var translations = [];
}

translations = translations.concat([
    {
        key: "ITEM_SUB_BASEDATA_LEDGERS_ARCHIVED",
        en: "Archived Ledgers",
        de: "Archivierte Konten"
    },
    {
        key: "ITEM_SUB_BASEDATA_LEDGERS",
        en: "Ledgers",
        de: "Konten"
    },
    {
        key: "TITLE_LEDGER_DETAILS",
        en: "Ledger details",
        de: "Kontodetails"
    },
    {
        key: "LOADING_LEDGER",
        en: "Ledger is loading",
        de: "Konto wird geladen"
    },
    {
        key: "LOADING_SAVING_LEDGER",
        en: "Ledger is saving",
        de: "Konto wird gespeichert"
    },
    {
        key: "MESSAGE_LEDGER_SAVED",
        en: "Ledger has been saved",
        de: "Konto wurde gespeichert"
    },
    {
        key: "LOADING_REMOVING_LEDGER",
        en: "Ledger will be removed",
        de: "Konto wird entfernt"
    },
    {
        key: "MESSAGE_LEDGER_REMOVED",
        en: "Ledger has been removed",
        de: "Konto wurde entfernt"
    },
    {
        key: "MESSAGE_COULD_NOT_SAVE_LEDGER",
        en: "Ledger could not be saved",
        de: "Konto konnte nicht gespeichert werden"
    },
    {
        key: "MESSAGE_LEDGER_IS_DELETED",
        en: "Ledger is deleted",
        de: "Konto ist gelöscht"
    },
    {
        key: "FORM_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "FORM_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "FORM_EXTERNAL_ID",
        en: "External id",
        de: "Externe Id"
    },
    {
        key: "FORM_TRANSACTION_CODE",
        en: "Transaction code",
        de: "Bewegungsart"
    },
    {
        key: "TABLE_LEDGER_ID",
        en: "Id",
        de: "Id"
    },
    {
        key: "TABLE_LEDGER_NAME",
        en: "Name",
        de: "Name"
    },
    {
        key: "TABLE_LEDGER_EXTERNAL_ID",
        en: "External id",
        de: "Externe Id"
    },
    {
        key: "TABLE_LEDGER_TRANSACTION_CODE",
        en: "Transaction code",
        de: "Bewegungsart"
    }
]);