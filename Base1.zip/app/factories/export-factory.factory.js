﻿"use strict";

angular
    .module("LeadApp")
    .factory("exportFactory", [
        "messageFactory", "resourceFactory",
        function (messageFactory, resourceFactory) {
            return {
                exportReport: function (reportSourceName, reportParameters, reportConfig, exportType) {
                    var message = exportType == "xlsx" ? "REPORT_EXPORT_EXCEL_LOADING" : "REPORT_EXPORT_CSV_LOADING";

                    messageFactory
                        .exportNotificationMessage
                        .startExport(reportSourceName, reportParameters, reportConfig, message, resourceFactory, exportType);
                }
            };
        }
    ]);