﻿'use strict';

angular
    .module('LeadApp')
    .factory("pageFactory", [
        "$translate", "$rootScope", "$route", "resourceFactory", "messageFactory",
        function ($translate, $rootScope, $route, resourceFactory, messageFactory) {
            var header = {
                titleTranslationKey: "",
                backbutton: null
            };

            // Comma and thousands separators: https://docs.oracle.com/cd/E19455-01/806-0169/overview-9/index.html
            // Dateformats ALLOWED in countires: https://en.wikipedia.org/wiki/Date_format_by_country
            // Dateformats that are COMMON in countires: https://de.wikipedia.org/wiki/Datumsformat
            var languageSettings = [
                {
                    name: "English (British)",
                    languageKey: "en_GB",
                    translationKey: "en",
                    dateFormat: "dd/MM/yyyy",
                    dateMonthYearFormat: "MM/yyyy",
                    commaSeparator: ".",
                    thousandsSeparator: ","
                },
                {
                    name: "English (American)",
                    languageKey: "en_US",
                    translationKey: "en",
                    dateFormat: "M/d/yyyy",
                    dateMonthYearFormat: "M/yyyy",
                    commaSeparator: ".",
                    thousandsSeparator: ","
                },
                {
                    name: "German",
                    languageKey: "de_DE",
                    translationKey: "de",
                    dateFormat: "dd.MM.yyyy",
                    dateMonthYearFormat: "MM.yyyy",
                    commaSeparator: ",",
                    thousandsSeparator: " "
                }
            ];

            var getLanguageByLanguageKey = function (languageKey) {
                for (var f in languageSettings) {
                    if (languageSettings[f].languageKey.toLowerCase() == languageKey.toLowerCase()) {
                        return languageSettings[f];
                    }
                }
            };

            return {
                header: header,

                setTitle: function (newTitleTranslationKey, backPathOrOnClickFunction) {
                    header.titleTranslationKey = newTitleTranslationKey;

                    if (typeof (backPathOrOnClickFunction) == "string") {
                        header.backbutton = {
                            path: backPathOrOnClickFunction
                        }
                    }
                    else if (typeof (backPathOrOnClickFunction) == "function") {
                        header.backbutton = {
                            onClick: backPathOrOnClickFunction
                        }
                    }
                    else {
                        header.backbutton = null;
                    }
                },

                languageSettings: languageSettings,
                getDefaultLanguage: function () {
                    return getLanguageByLanguageKey("en_GB");
                },
                getLanguageByLanguageKey: getLanguageByLanguageKey,

                changeLanguage: function (language, saveSetting) {
                    $translate.use(language.translationKey.toLowerCase());

                    $rootScope.languageSettings = language;
                    $rootScope.dateFormat = language.dateFormat;
                    $rootScope.initializeKendoHelpers();
                    kendo.culture(language.languageKey.replace('_', '-'));
                    $route.reload();

                    if (saveSetting) {
                        resourceFactory
                            .userLanguage($rootScope.currentUser.Id)
                            .setLanguage({
                                language: language.languageKey
                            })
                            .$promise
                            .then(function () {
                                messageFactory.showSuccessMessage("MESSAGE_CHANGED_LANGUAGE");
                            });
                    }
                }
            };
        }
    ]);