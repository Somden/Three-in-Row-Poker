﻿"use strict";

angular
    .module("LeadApp")
    .factory("resourceFactory", [
        "$q", "$resource", "messageFactory", "resourceFactoryHelpers",
        function ($q, $resource, messageFactory, resourceFactoryHelpers) {
            // Response Interceptors
            var responseInterceptors = {
                // Catches errors from backend and shows error message
                responseError: function (rejection) {
                    console.log("Request failed", rejection);

                    if (rejection.status == 401) {
                        messageFactory.showErrorMessage("MESSAGE_REQUEST_401");
                    }
                    if (rejection.status == 403) {
                        messageFactory.showErrorMessage(rejection.data.Message);
                    }
                    else {
                        if (rejection.data && rejection.data.length > 1) {
                            console.error(rejection.data);
                        }

                        if (typeof (rejection) !== "undefined" && rejection !== null && typeof (rejection.data) !== "undefined" &&
                            rejection.data !== null && rejection.data.toUpperCase != null &&
                            rejection.data.toUpperCase() === "NO CONTRACT FOUND") {
                            messageFactory.showWarningMessage("REPORT_NO_CONTRACT_FOUND_MATCHING_CRITERIA");
                        }
                        else {
                            messageFactory.showErrorMessage("MESSAGE_REQUEST_ERROR");
                        }
                    }

                    return $q.reject(rejection);
                }
            };

            // Interceptor, that controls the response of the report/export resource
            var exportErrorInterceptor = {
                responseError: function (rejection) {
                    console.log("Request failed", rejection);

                    if (rejection.status == 401) {
                        messageFactory.showErrorMessage("MESSAGE_REQUEST_401");
                    }
                    if (rejection.status == 403 || rejection.status == 204) {
                        messageFactory.showErrorMessage(rejection.data.Message);
                    }
                    else {
                        messageFactory.showErrorMessage("MESSAGE_REQUEST_ERROR");
                    }

                    return $q.reject(rejection);
                }
            };

            // This header needs to be sent with every POST/PUT/DELETE action!
            var antiForgeryTokenHeader = { "RequestVerificationToken": globalConfig.antiForgeryToken };

            var resources = {
                permittedValue: function (enumType, value) {
                    var actions =
                        {
                            getByEnumType:
                                {
                                    method: "GET",
                                    interceptor: responseInterceptors
                                }
                        };

                    if (value == null) {
                        return $resource("/odata/PermittedValues?$filter=EnumType eq ':enumType'", { enumType: enumType }, actions);
                    }
                    else {
                        var parameters = {
                            value: value,
                            enumType: enumType
                        };
                        return $resource("/odata/PermittedValues?$filter=Value eq ':value' and EnumType eq ':enumType'", parameters, actions);
                    }
                },

                emptyEntity: function (entityName, baseTemplateId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            interceptor: responseInterceptors
                        },
                        getAll: {
                            method: "GET",
                            isArray: true,
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            interceptor: responseInterceptors
                        },
                        getDefaultAssetWithComponent: {
                            method: "GET",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };
                    if (baseTemplateId == null) {
                        var parameters = {
                            entityName: entityName,
                            baseTemplateId: -1
                        };
                        return $resource("/api/emptyEntity?entityName=:entityName&baseTemplateId:=baseTemplateId", parameters, actions);
                    }
                    else {
                        var parameters =
                            {
                                entityName: entityName,
                                baseTemplateId: baseTemplateId
                            };
                        return $resource("/api/emptyEntity?entityName=:entityName&baseTemplateId:=baseTemplateId", parameters, actions);
                    }
                },

                gridDefinition: function (modelName) {
                    var actions = {
                        loadDefinition: {
                            method: "GET",
                            isArray: true,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/gridDefinition/:modelName", { modelName: modelName }, actions);
                },

                contract: function (contractId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            transformRequest: resourceFactoryHelpers.transformContractRequest,
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            transformRequest: resourceFactoryHelpers.transformContractRequest,
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/contract/:contractId", { contractId: contractId }, actions);
                },

                contractRevision: function (contractRevisionId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            transformResponse: resourceFactoryHelpers.transformContractRevisionResponse,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/contractRevision/:contractRevisionId", { contractRevisionId: contractRevisionId }, actions);
                },

                contractRevisionState: function (contractId) {
                    var actions = {
                        changeState: {
                            method: "PUT",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        discardPendingChanges: {
                            method: "DELETE",
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/contractRevisionState/:contractId", { contractId: contractId }, actions);
                },

                company: function (companyId, originCompanyId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        copy: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    if (originCompanyId) {
                        var parameters = {
                            originCompanyId: originCompanyId,
                            destinationCompanyId: companyId
                        };
                        return $resource("/api/company", parameters, actions);
                    }

                    return $resource("/api/company/:companyId", { companyId: companyId }, actions);
                },

                currency: function (currencyId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/currency/:currencyId", { currencyId: currencyId }, actions);
                },

                user: function (userId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        getAll: {
                            method: "GET",
                            isArray: true,
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/user/:userId", { userId: userId }, actions);
                },

                fieldFormatterHelper: function (userId) {
                    var actions = {
                        get: {
                            method: "GET",
                            interceptor: responseInterceptors,
                        },
                    };

                    return $resource("/odata/FieldFormatterHelper", null, actions);
                },

                userAccount: function () {
                    var actions = {
                        changePassword: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors,
                        },
                    };

                    return $resource("/action/UserAccount/ChangePassword", null, actions);
                },

                userLanguage: function (userId) {
                    var actions = {
                        setLanguage: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/user/language/:userId", { userId: userId }, actions);
                },

                partner: function (partnerId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        getAll: {
                            method: "GET",
                            isArray: true,
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/partner/:partnerId", { partnerId: partnerId }, actions);
                },

                assetClass: function (assetClassId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        getAll: {
                            method: "GET",
                            isArray: true,
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/assetClass/:assetClassId", { assetClassId: assetClassId }, actions);
                },

                contractLockDateSettings: function (settingsId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/contractLockDateSetting/:settingsId", { settingsId: settingsId }, actions);
                },

                liabilityOverview: function () {
                    var actions = {
                        loadWithModel: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                    };

                    return $resource("/api/ContractLiability", null, actions);
                },

                evaluationOverview: function () {
                    var actions = {
                        loadWithModel: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                    };

                    return $resource("/api/ContractEvaluation", null, actions);
                },

                paymentOverview: function (contractRevisionId) {
                    var actions = {
                        loadWithModel: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                    };

                    return $resource("/api/PaymentOverview", null, actions);
                },

                calculationHelper: function (contractId) {
                    var actions = {
                        GetTypeOfLease: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors,
                            transformResponse: resourceFactoryHelpers.transformContractResponse,
                        },
                    };

                    return $resource("/api/TypeOfLease/:contractId", { contractId: contractId }, actions);
                },

                report: function (exportRequest) {
                    var actions = {
                        post: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: exportErrorInterceptor
                        }
                    };

                    return $resource("/api/Export/:exportRequest", { exportRequest: exportRequest }, actions);
                },

                reportProgress: function (exportId) {
                    var actions = {
                        getOverview: {
                            method: "GET",
                            isArray: true,
                            interceptor: responseInterceptors
                        },
                        getCurrentProgress: {
                            method: "GET",
                            interceptor: responseInterceptors
                        }
                    };

                    var antiCache = Math.round(Math.random() * Math.pow(2, 16));

                    return $resource("/api/ExportProgress/:exportId?cache:antiCache", { exportId: exportId, antiCache: antiCache }, actions);
                },

                companySummaryReport: function (reportConfig) {
                    var actions = {
                        getResults: {
                            method: "GET",
                            interceptor: responseInterceptors
                        }
                    };

                    var contractRevisionState = reportConfig.contractState.state;

                    //http://localhost:63200/odata/CompanySummaryReportView/Lead.Get(contractState='Terminated',evaluationPeriodStart=12.12.2018,evaluationPeriodEnd=13.12.2018)

                    var parameters = {
                        companyCode: "0694",
                        contractRevisionState: contractRevisionState
                    };
                    var dataSourceUrl = "/odata/CompanySummaryReportView/Lead.Get(companyId=':companyCode',contractState=':contractRevisionState')";
                    return $resource(dataSourceUrl, parameters, actions);
                },

                notesReport: function (reportConfig) {
                    var actions = {
                        getResults: {
                            method: "GET",
                            interceptor: responseInterceptors
                        }
                    };
                    var cId = reportConfig.selectedCompany.Id;
                    var isShortTermLeaseFilter = reportConfig.isShortTermLeaseFilter;
                    var isLowValueFilter = reportConfig.isLowValueFilter;

                    if (angular.isDefined(reportConfig.evaluationStart) && reportConfig.evaluationStart != null && angular.isDefined(reportConfig.evaluationEnd) && reportConfig.evaluationEnd != null) {
                        var evaluationStart = reportConfig.evaluationStart.getFullYear() + "-" + (reportConfig.evaluationStart.getMonth() + 1) + "-" + reportConfig.evaluationStart.getDate();
                        var evaluationEnd = reportConfig.evaluationEnd.getFullYear() + "-" + (reportConfig.evaluationEnd.getMonth() + 1) + "-" + reportConfig.evaluationEnd.getDate();

                        var dataSourceUrl = "/odata/SimpleReport/Lead.GetWithEvaluationPeriod(companyId=:cId,isShortTermLeaseFilter=:isShortTermLeaseFilter,isLowValueFilter=:isLowValueFilter,evaluationPeriodStart=':evaluationStart', evaluationPeriodEnd=':evaluationEnd' )";

                        var parameters = {
                            cId: cId,
                            isLowValueFilter: isLowValueFilter,
                            isShortTermLeaseFilter: isShortTermLeaseFilter,
                            evaluationPeriodStart: evaluationStart,
                            evaluationPeriodEnd: evaluationEnd
                        };
                        return $resource(dataSourceUrl, parameters, actions);
                    }

                    //http://localhost:63200/odata/SimpleReportView/Lead.GetWithEvaluationPeriod(companyId=1,contractState='Terminated',evaluationPeriodStart=12.12.2018,evaluationPeriodEnd=13.12.2018)

                    var dataSourceUrl = "/odata/SimpleReport/Lead.Get(companyId=:cId,isShortTermLeaseFilter=:isShortTermLeaseFilter,isLowValueFilter=:isLowValueFilter)";

                    var parameters = {
                        cId: cId,
                        isShortTermLeaseFilter: isShortTermLeaseFilter,
                        isLowValueFilter: isLowValueFilter
                    };
                    return $resource(dataSourceUrl, parameters, actions);
                },

                exportLogReport: function (reportConfig) {
                    var actions = {
                        getResults: {
                            method: "GET",
                            interceptor: responseInterceptors
                        }
                    };

                    var isAllEntries = reportConfig.isAllEntries;
                    var evaluationDate = !isAllEntries
                        ? reportConfig.evaluationDate.getFullYear() +
                        "-" +
                        (reportConfig.evaluationDate.getMonth() + 1) +
                        "-" +
                        1
                        : null;
                    var dataSourceUrl = "/odata/ExportLogReport/Lead.GetAll";

                    var parameters;

                    if (!reportConfig.isAllEntries) {
                        var filter = "month(CreatedDate) eq " + 
                            (reportConfig.evaluationDate.getMonth() +
                            1) +
                            " and year(CreatedDate) eq " +
                            reportConfig.evaluationDate.getFullYear();
                        parameters = {
                            $expand: "Company",
                            $filter: filter
                        };
                    } else {
                        parameters = {
                            $expand: "Company"
                        };
                    }
                    
                    
                    return $resource(dataSourceUrl, parameters, actions);
                },
                contractSeriesReport: function (reportConfig) {
                    var actions = {
                        getResults: {
                            method: "GET",
                            interceptor: responseInterceptors
                        }
                    };

                    var contractId = reportConfig.selectedContract.Id;
                    var revision = reportConfig.revision.Revision;
                    var accountingStandard = reportConfig.accountingStandard.Value;
                    var componentId = "null";


                    if (reportConfig.component != null && angular.isDefined(reportConfig.component) && angular.isDefined(reportConfig.component.ContractComponentId)) {
                        componentId = reportConfig.component.ContractComponentId;
                    }

                    var dataSourceUrl = "/odata/ContractSeriesReportView/Lead.GetComponentByRevision(id=:contractId,revision=:revision,accountingStandard=':accountingStandard',componentId=:componentId)";

                    var parameters = {
                        contractId: contractId,
                        revision: revision,
                        accountingStandard: accountingStandard,
                        componentId: componentId
                    };
                    return $resource(dataSourceUrl, parameters, actions);
                },

                ledger: function (ledgerId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/Ledger/:ledgerId", { ledgerId: ledgerId }, actions);
                },

                ledgerAssociation: function (ledgerAssociationId) {
                    var actions = {
                        getById: {
                            method: "GET",
                            interceptor: responseInterceptors
                        },
                        create: {
                            method: "POST",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        update: {
                            method: "PUT",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        },
                        remove: {
                            method: "DELETE",
                            headers: antiForgeryTokenHeader,
                            interceptor: responseInterceptors
                        }
                    };

                    return $resource("/api/LedgerAssociation/:ledgerAssociationId", { ledgerAssociationId: ledgerAssociationId }, actions);
                }
            };

            // This is a modifier to modify or expand the resources that will be returned
            // transformResourceFactory needs to be globally defined
            if (typeof (transformResourceFactory) == "function") {
                resources = transformResourceFactory(resources, $resource, responseInterceptors, antiForgeryTokenHeader);
            }

            return resources;
        }
    ]);