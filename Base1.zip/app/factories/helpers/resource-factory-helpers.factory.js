﻿"use strict";

angular
    .module("LeadApp")
    .factory("resourceFactoryHelpers", [
        "$rootScope", "messageFactory",
        function ($rootScope, messageFactory) {
            // Private
            function castContractDates(contract) {
                if (contract != null) {
                    if (contract.ConclusionDate != null) {
                        contract.ConclusionDate = new Date(contract.ConclusionDate).convertTimeToLocalTime();
                    }

                    if (contract.CommencementDate != null) {
                        contract.CommencementDate = new Date(contract.CommencementDate).convertTimeToLocalTime();
                    }

                    if (contract.CurrentContractRevision != null) {
                        if (contract.CurrentContractRevision.EndOfLeaseTerm != null) {
                            contract.CurrentContractRevision.EndOfLeaseTerm = new Date(contract.CurrentContractRevision.EndOfLeaseTerm).convertTimeToLocalTime();
                        }

                        if (contract.CurrentContractRevision.Payment != null
                            && contract.CurrentContractRevision.Payment.PaymentStartDate != null) {
                            contract.CurrentContractRevision.Payment.PaymentStartDate = new Date(contract.CurrentContractRevision.Payment.PaymentStartDate).convertTimeToLocalTime();
                        }

                        if (contract.CurrentContractRevision.ContractLeasingPeriod != null) {
                            contract.CurrentContractRevision.ContractLeasingPeriod.EndDate = new Date(contract.CurrentContractRevision.ContractLeasingPeriod.EndDate).convertTimeToLocalTime();

                            if (contract.CurrentContractRevision.ContractLeasingPeriod.TerminationOption != null) {
                                contract.CurrentContractRevision.ContractLeasingPeriod.TerminationOption.EndDate = new Date(contract.CurrentContractRevision.ContractLeasingPeriod.TerminationOption.EndDate).convertTimeToLocalTime();
                            }
                        }

                        if (contract.CurrentContractRevision.ExtensionLeasingPeriods != null) {
                            for (var f in contract.CurrentContractRevision.ExtensionLeasingPeriods) {
                                var leasingPeriod = contract.CurrentContractRevision.ExtensionLeasingPeriods[f];

                                leasingPeriod.EndDate = new Date(leasingPeriod.EndDate).convertTimeToLocalTime();

                                if (leasingPeriod.TerminationOption != null) {
                                    leasingPeriod.TerminationOption.EndDate = new Date(leasingPeriod.TerminationOption.EndDate).convertTimeToLocalTime();
                                }
                            }
                        }
                    }
                }

                return contract;
            }

            function convertNumbersOfRevisionFromCurrentCulture(contractRevision) {
                modifyAllNumbersOfAContractRevision(contractRevision, function (number, isPercentageNumber) {
                    return helpers.getNumericValue(number);
                });
            }

            function convertNumbersOfRevisionToCurrentCulture(contractRevision, decimalPlaces) {
                modifyAllNumbersOfAContractRevision(contractRevision, function (number, isPercentageNumber, decimalPlaces) {
                    return helpers.numberToCultureString(number, $rootScope, false, decimalPlaces);
                });
            }

            // Goes through all numbers of a contract and modifies them with given modifier funtion
            // modifier: function(number: number, isPercentageNumber: bool)
            function modifyAllNumbersOfAContractRevision(contractRevision, modifier) {
                if (contractRevision != null) {
                    contractRevision.InterestRate = modifier(contractRevision.InterestRate, true, 4);
                    contractRevision.IncrementalBorrowingRate = modifier(contractRevision.IncrementalBorrowingRate, true, 4);
                    contractRevision.ResidualValue = modifier(contractRevision.ResidualValue);

                    if (contractRevision.ContractLeasingPeriod != null) {
                        if (contractRevision.ContractLeasingPeriod.PaymentRules != null) {
                            for (var f in contractRevision.ContractLeasingPeriod.PaymentRules) {
                                var paymentRule = contractRevision.ContractLeasingPeriod.PaymentRules[f];
                                paymentRule.PaymentValue = modifier(paymentRule.PaymentValue);
                                paymentRule.InSubstancePaymentValue = modifier(paymentRule.InSubstancePaymentValue);
                                paymentRule.PercentageScalingValue = modifier(paymentRule.PercentageScalingValue, true);
                                paymentRule.AbsoluteScalingValue = modifier(paymentRule.AbsoluteScalingValue);
                            }
                        }

                        if (contractRevision.ContractLeasingPeriod.TerminationOption != null) {
                            contractRevision.ContractLeasingPeriod.TerminationOption.ExecutionValue = modifier(contractRevision.ContractLeasingPeriod.TerminationOption.ExecutionValue);
                        }
                    }

                    if (contractRevision.ExtensionLeasingPeriods != null) {
                        for (var f in contractRevision.ExtensionLeasingPeriods) {
                            var leasingPeriod = contractRevision.ExtensionLeasingPeriods[f];
                            leasingPeriod.ExecutionValue = modifier(leasingPeriod.ExecutionValue);

                            if (leasingPeriod.PaymentRules != null) {
                                for (var g in leasingPeriod.PaymentRules) {
                                    var paymentRule = leasingPeriod.PaymentRules[g];
                                    paymentRule.PaymentValue = modifier(paymentRule.PaymentValue);
                                    paymentRule.InSubstancePaymentValue = modifier(paymentRule.InSubstancePaymentValue);
                                    paymentRule.PercentageScalingValue = modifier(paymentRule.PercentageScalingValue, true);
                                    paymentRule.AbsoluteScalingValue = modifier(paymentRule.AbsoluteScalingValue);
                                }
                            }

                            if (leasingPeriod.TerminationOption != null) {
                                leasingPeriod.TerminationOption.ExecutionValue = modifier(leasingPeriod.TerminationOption.ExecutionValue);
                            }
                        }
                    }

                    if (contractRevision.PurchaseOptions != null) {
                        for (var f in contractRevision.PurchaseOptions) {
                            var purchaseOption = contractRevision.PurchaseOptions[f];
                            purchaseOption.PurchaseOptionValue = modifier(purchaseOption.PurchaseOptionValue);
                        }
                    }

                    if (contractRevision.RightOfUseAsset != null) {
                        contractRevision.RightOfUseAsset.ContractInitiationCosts = modifier(contractRevision.RightOfUseAsset.ContractInitiationCosts);
                        contractRevision.RightOfUseAsset.OtherInitialCosts = modifier(contractRevision.RightOfUseAsset.OtherInitialCosts);
                        contractRevision.RightOfUseAsset.Grants = modifier(contractRevision.RightOfUseAsset.Grants);
                        contractRevision.RightOfUseAsset.LeaseIncentivesReceivedAmount = modifier(contractRevision.RightOfUseAsset.LeaseIncentivesReceivedAmount);
                        contractRevision.RightOfUseAsset.RestorationValue = modifier(contractRevision.RightOfUseAsset.RestorationValue);

                        if (contractRevision.RightOfUseAsset.Assets != null) {
                            for (var f in contractRevision.RightOfUseAsset.Assets) {
                                var asset = contractRevision.RightOfUseAsset.Assets[f];

                                for (var g in asset.AssetComponents) {
                                    var assetComponent = asset.AssetComponents[g];
                                    assetComponent.AssetShare = modifier(assetComponent.AssetShare, true);
                                    assetComponent.AmountChange = modifier(assetComponent.AmountChange, true);
                                    assetComponent.ValueDelta = modifier(assetComponent.ValueDelta);
                                    assetComponent.FairValue = modifier(assetComponent.FairValue);
                                }
                            }
                        }

                        if (contractRevision.RightOfUseAsset.RightOfUseAssetPaymentRules != null) {
                            for (var g in contractRevision.RightOfUseAsset.RightOfUseAssetPaymentRules) {
                                var paymentRule = contractRevision.RightOfUseAsset.RightOfUseAssetPaymentRules[g];
                                paymentRule.PaymentValue = modifier(paymentRule.PaymentValue);
                            }
                        }
                    }
                }
            }

            function convertPercentagesToRelativeNumbersOfRevision(contractRevision, multiplicator) {
                modifyAllNumbersOfAContractRevision(contractRevision, function (number, isPercentageNumber) {
                    if (isPercentageNumber) {
                        var percentage = helpers.getNumericValue(number);
                        return Math.round(percentage / 100 * 100000000) / 100000000;
                    }

                    return number;
                });
            }

            function convertRelativeNumbersToPercentagesOfRevision(contractRevision, multiplicator) {
                modifyAllNumbersOfAContractRevision(contractRevision, function (number, isPercentageNumber) {
                    if (isPercentageNumber) {
                        var percentage = helpers.getNumericValue(number);
                        return Math.round(percentage * 100 * 100000000) / 100000000;
                    }

                    return number;
                });
            }

            // Public
            var transformContractResponse = function (data) {
                data = JSON.parse(data);

                if (data.Payload == null || typeof (data.Payload) != "object") {
                    return data;
                }

                if (helpers.isList(data.Payload)) {
                    for (var f in data.Payload) {
                        data.Payload[f] = castContractDates(data.Payload[f]);
                        convertRelativeNumbersToPercentagesOfRevision(data.Payload[f].CurrentContractRevision);
                        convertNumbersOfRevisionToCurrentCulture(data.Payload[f].CurrentContractRevision);
                    }
                }
                else {
                    data.Payload = castContractDates(data.Payload);
                    convertRelativeNumbersToPercentagesOfRevision(data.Payload.CurrentContractRevision);
                    convertNumbersOfRevisionToCurrentCulture(data.Payload.CurrentContractRevision);
                }

                return data;
            };

            var transformContractRequest = function (contract, includeDisplayedContractRevision) {
                if (includeDisplayedContractRevision) {
                    convertNumbersOfRevisionFromCurrentCulture(contract.DisplayedContractRevision);

                    // Converts percentages to relative numbers
                    convertPercentagesToRelativeNumbersOfRevision(contract.DisplayedContractRevision);
                }
                // Removes culture specific comma/thousands separator settings from numbers
                convertNumbersOfRevisionFromCurrentCulture(contract.CurrentContractRevision);

                // Converts percentages to relative numbers
                convertPercentagesToRelativeNumbersOfRevision(contract.CurrentContractRevision);

                return JSON.stringify(contract);
            };

            var transformContractRevisionResponse = function (data) {
                data = JSON.parse(data);

                // Converts relative numbers to percentages
                convertRelativeNumbersToPercentagesOfRevision(data.Payload);

                // Applies comma/thousands separator settings to numbers
                convertNumbersOfRevisionToCurrentCulture(data.Payload.CurrentContractRevision);

                return data;
            };

            return {
                // Transforms the request of a contract
                transformContractRequest: transformContractRequest,

                // Transforms the response of a contract
                transformContractResponse: transformContractResponse,

                // Transforms the response of a contract revision
                transformContractRevisionResponse: transformContractRevisionResponse
            };
        }
    ]);