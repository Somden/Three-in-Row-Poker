﻿"use strict";

/* This is a helper to build definitions for kendo grids.

Here is an example for how to call it:
kendoGridBuilder(
    "/odata/Partner",   // OData URL
    "Partner",          // Model that will be sent to api/GridDefinition to retrieve the column definition
    vm.showArchived,    // Whether to show deleted or non deleted entries, can be null as well
    openEntity,         // Click callback. When a row gets clicked, this will be called. Can be null as well
    function (gridDefinition) { vm.gridOptions = gridDefinition; }); //Callback for the kendo grid definition
*/

angular
    .module("LeadApp")
    .factory("kendoGridBuilder", [
        "$rootScope", "$translate", "messageFactory", "resourceFactory",
        function ($rootScope, $translate, messageFactory, resourceFactory) {
            function getGridDefinitions(modelName, onLoaded) {
                resourceFactory
                    .gridDefinition(modelName)
                    .loadDefinition()
                    .$promise
                    .then(function (resp) {
                        onLoaded(resp);
                    })
                    .catch(function (resp) {
                        console.error("Error on loading grid definition:", resp);

                        onLoaded([]);
                    });
            }

            function collectModelDefinitions(modelDefinitions, gridDefinitions) {
                for (var f in gridDefinitions) {
                    modelDefinitions[gridDefinitions[f].ColumnName] = {
                        type: gridDefinitions[f].Type
                    };

                    if (gridDefinitions[f].Columns != null && gridDefinitions[f].Columns.length>0) {
                        collectModelDefinitions(modelDefinitions, gridDefinitions[f].Columns);
                    }
                }
            }

            function buildModelDefinitions(gridDefinitions) {
                var modelDefinitions = {};
                collectModelDefinitions(modelDefinitions, gridDefinitions);

                return modelDefinitions;
            }

            function buildInnerColumns(columns, column) {

                var template = column.Template;
                if (template == null) {
                    switch (column.Type) {
                    case "date":
                        template = '<div class="text-right">#=renderDateTime( ' + column.ColumnName + ' || "", "' + $rootScope.dateFormat + '")#</div>';
                        break;
                    case "boolean":
                        template = '<span translate="BOOLEAN_{{ dataItem.' +
                            column.ColumnName +
                            '.toString().toUpperCase() }}"></span>';
                        break;
                    case "number":
                        template = '<div class="text-right">{{ dataItem.' + column.ColumnName + ' }}</div>';
                        break;
                    case "currencyvalue":
                        template = '<div class="text-right">{{ dataItem.' +
                            column.ColumnName +
                            ' | cultureFormat }} {{ dataItem.' +
                            column.CurrencyCodeProperty +
                            ' }}</div>';
                        break;
                    case "percentage":
                        template = '<div class="text-right">{{ (dataItem.' +
                            column.ColumnName +
                            ') * 100.0 | cultureFormat: 2 }} %</div>';
                        break;
                    case "percentagewith6decimalplaces":
                        template = '<div class="text-right">{{ (dataItem.' +
                            column.ColumnName +
                            ') * 100.0 | cultureFormat: 2 }} %</div>';
                        break;
                    case "currencyvaluewith5decimalplaces":
                        template = '<div class="text-right">{{ dataItem.' +
                            column.ColumnName +
                            ' | cultureFormat: 5 }} {{ dataItem.' +
                            column.CurrencyCodeProperty +
                            ' }}</div>';
                        break;
                    case "stringlist":
                        template = function(dataItem) {
                            if (dataItem[column.ColumnName] == null || dataItem[column.ColumnName].length == 0) {
                                return "";
                            }

                            var assetClassNames = dataItem[column.ColumnName].split(" || ");

                            var categories = [];
                            angular.forEach(assetClassNames,
                                function(assetClassName) {
                                    categories.push("<span class='label label-default'>" + assetClassName + "</span>");
                                });

                            return categories.join("&nbsp;");
                        }
                        break;
                    }
                }

                var innerColumns = null;
                if (column.Columns != null && column.Columns.length > 0) {
                    innerColumns = [];
                    angular.forEach(column.Columns, function (innerColumn) {
                        buildInnerColumns(innerColumns, innerColumn);
                    });
                }

                var newColumn = {
                    field: column.ColumnName,
                    title: "{{ '" + column.ColumnTitle + "' | translate }}",

                    hidden: column.IsHidden,
                    filterable: column.IsFilterable,
                    sortable: column.IsSortable,
                    isSearchEnabled: column.IsSearchEnabled,
                    width: column.Width,
                    template: template,
                    columns: innerColumns
                };

                if (column.HeaderTemplate != null && column.HeaderTemplate.length > 0) {
                    newColumn.title = null;
                    newColumn.headerTemplate = column.HeaderTemplate;
                }

                columns.push(newColumn);
            }

            function buildColumnDefinitions(gridDefinitions) {
                var columns = [];
                angular.forEach(gridDefinitions, function (column) {
                    buildInnerColumns(columns, column);
                });

                return columns;
            }

            function buildDataSource(odataSourceUrl, gridDefinitions, showArchivedItems, onRequestEnd) {
                var modelDefinitions = buildModelDefinitions(gridDefinitions);

                var dataSource = new kendo.data.DataSource({
                    type: "odata-v4",
                    transport: {
                        read: {
                            url: odataSourceUrl,
                            dataType: "json"
                        }
                    },
                    error: function (e) {
                        console.error(e.status + " : " + e.errorThrown);

                        if (typeof (onRequestEnd) == "function") {
                            onRequestEnd();
                        }
                    },
                    requestEnd: function (e) {
                        if (typeof (onRequestEnd) == "function") {
                            onRequestEnd();
                        }
                    },
                    schema: {
                        data: function (data) {
                            return data.value;
                        },
                        total: function (data) {
                            return data['@odata.count'];
                        },
                        model: {
                            fields: modelDefinitions
                        }
                    },
                    pageSize: 50,
                    page: 1,
                    serverPaging: true,
                    serverSorting: true,
                    serverFiltering: true,
                    serverGrouping: true,
                    serverAggregates: true,
                });

                if (showArchivedItems != null) {
                    dataSource.filter({ field: "IsDeleted", operator: "eq", value: showArchivedItems });
                }

                return dataSource;
            }

            function buildLocalDataSource(dataItems, gridDefinitions) {
                var modelDefinitions = buildModelDefinitions(gridDefinitions);

                return {
                    data: dataItems,
                    schema: {
                        model: {
                            fields: modelDefinitions
                        }
                    },
                    pageSize: 50,
                    page: 1
                };
            }

            function buildKendoGridDefinition(odataSourceUrl, gridDefinitions, showArchivedItems, preloadAllResults, onRequestEnd, onRowClick, onDefinitionBuilt) {
                var dataSource = buildDataSource(odataSourceUrl, gridDefinitions, showArchivedItems, onRequestEnd);
                if (preloadAllResults)
                {
                    dataSource
                        .fetch()
                        .then(function (resp) {
                            var data = dataSource.data();
                            dataSource = buildLocalDataSource(data, gridDefinitions);

                            var definition = buildKendoGridDefinitionWithDatasource(dataSource, gridDefinitions, onRowClick);
                            onDefinitionBuilt(definition);
                            onRequestEnd();
                        })
                        .catch(function(resp){
                            console.error(resp);

                            var definition = buildKendoGridDefinitionWithDatasource([], gridDefinitions, onRowClick);
                            onDefinitionBuilt(definition);
                            onRequestEnd();
                        });
                }
                else {
                    var definition = buildKendoGridDefinitionWithDatasource(dataSource, gridDefinitions, onRowClick);
                    onDefinitionBuilt(definition);
                }
            }

            function buildKendoGridDefinitionWithDatasource(dataSource, gridDefinitions, onRowClick) {
                var columnDefinitions = buildColumnDefinitions(gridDefinitions);
                var hasRowClickHandler = typeof (onRowClick) == "function";

                return {
                    dataSource: dataSource,
                    sortable: true,
                    pageable: {
                        refresh: true,
                        buttonCount: 5,
                        pageSizes: [10, 20, 50],
                        messages: {
                            display: $translate.instant("KENDO_GRID_DISPLAY"),
                            empty: $translate.instant("KENDO_GRID_EMPTY"),
                            page: $translate.instant("KENDO_GRID_PAGE"),
                            allPages: $translate.instant("KENDO_GRID_ALLPAGES"),
                            of: $translate.instant("KENDO_GRID_OF"),
                            itemsPerPage: $translate.instant("KENDO_GRID_ITEMSPERPAGE"),
                            first: $translate.instant("KENDO_GRID_FIRST"),
                            previous: $translate.instant("KENDO_GRID_PREVIOUS"),
                            next: $translate.instant("KENDO_GRID_NEXT"),
                            last: $translate.instant("KENDO_GRID_LAST"),
                            refresh: $translate.instant("KENDO_GRID_REFRESH")
                        }
                    },
                    filterable: {
                        mode: "menu",
                        messages: {
                            info: $translate.instant("KENDO_GRID_FILTERABLE_INFO"),
                            isFalse: $translate.instant("KENDO_GRID_FILTERABLE_IS_FALSE"),
                            isTrue: $translate.instant("KENDO_GRID_FILTERABLE_IS_TRUE")
                        }
                    },
                    scrollable: false,
                    selectable: hasRowClickHandler ? "row" : null,
                    change: function (arg) {
                        if (hasRowClickHandler) {
                            var selectedId = $.map(this.select(), function (item) {
                                var row = $(item);
                                var id = row.find('td').eq(0).text();
                                return id;
                            });

                            onRowClick(selectedId);
                        }
                    },
                    columns: columnDefinitions
                }
            }

            return function (odataSourceUrl, modelName, showArchivedItems, onRowClick, onDefinitionBuilt, options) {
                var loadingId = messageFactory.loadingMessage.show("LOADING");
                function onRequestEnd() {
                    messageFactory.loadingMessage.hide(loadingId, $rootScope);
                }

                options = options || {};
                var preloadAllResults = options.preloadAllResults;

                getGridDefinitions(modelName, function (gridDefinitions) {
                    buildKendoGridDefinition(odataSourceUrl, gridDefinitions, showArchivedItems, preloadAllResults, onRequestEnd, onRowClick, function (definition) {
                        if (typeof (onDefinitionBuilt) == "function") {
                            onDefinitionBuilt(definition);
                        }
                    });
                });
            }
        }
    ]);