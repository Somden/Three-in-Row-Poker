﻿"use strict";

/* This is a helper to build data source objects for kendo elements.

Here is an example for how to call it:

*/

angular
    .module("LeadApp")
    .factory("kendoDataSourceBuilder", function () {
        return function (url, config) {
            config = config || {};

            var dataSource = {
                type: "odata-v4",
                transport: {
                    read: {
                        url: url,
                        serverFiltering: true,
                        dataType: "json",
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('RequestVerificationToken', globalConfig.antiForgeryToken)
                        }
                    },
                    parameterMap: function (options, operation) {
                        var paramMap = kendo.data.transports.odata.parameterMap(options);

                        delete paramMap.$inlinecount;
                        delete paramMap.$format;

                        return paramMap;
                    }
                },
                change: function (e) {
                    if (config.onChange != null) {
                        config.onChange(this.data());
                    }
                },
                schema: {
                    data: function (data) {
                        return data.value;
                    },
                    total: function (data) {
                        return data.value.length;
                    },
                    parse: function (data) {
                        if (config.onParse != null) {
                            data = config.onParse(data);
                        }

                        return data;
                    }
                },
                serverFiltering: true,

                pageSize: config.pageSize || 50,
                serverPaging: true
            };
            
            if (config.buildKendoDataSource) {
                config.buildKendoDataSource(dataSource);
            }

            dataSource = new kendo.data.DataSource(dataSource);

            if (typeof (config.sort) == 'object') {
                dataSource.sort(config.sort);
            }

            // Add functions to edit filters afterwards
            dataSource.and = function (additionalFilter) {
                if (this._filter == null) {
                    this._filter = additionalFilter;
                }
                else {
                    this._filter = {
                        logic: "and",
                        filters: [
                            this._filter,
                            additionalFilter
                        ]
                    };
                }

                return this;
            }

            dataSource.or = function (additionalFilter) {
                if (this._filter == null) {
                    this._filter = additionalFilter;
                }
                else {
                    this._filter = {
                        logic: "or",
                        filters: [
                            this._filter,
                            additionalFilter
                        ]
                    };
                }

                return this;
            };

            dataSource.withoutDeleted = function () {
                return this.and({ field: "IsDeleted", operator: "eq", value: false });
            };

            dataSource.orHasId = function (id) {
                return this.orEquals("Id", id);
            };

            dataSource.andHasId = function (id) {
                return this.whereEquals("Id", id);
            };

            dataSource.andHasNotId = function (id) {
                return this.whereNotEquals("Id", id);
            };

            dataSource.orEquals = function (propertyName, propertyValue) {
                if (propertyValue == null) return this;
                if (this._filter == null) return this;

                this.or({ field: propertyName, operator: "eq", value: propertyValue })

                return this;
            };

            dataSource.whereEquals = function (propertyName, propertyValue) {
                if (propertyValue == null) return this;

                var idFilter = { field: propertyName, operator: "eq", value: propertyValue };

                if (this._filter == null) this._filter = idFilter;
                else this.and(idFilter);

                return this;
            };

            dataSource.whereNotEquals = function (propertyName, propertyValue) {
                if (propertyValue == null) return this;

                var idFilter = { field: propertyName, operator: "ne", value: propertyValue };

                if (this._filter == null) this._filter = idFilter;
                else this.and(idFilter);

                return this;
            };

            dataSource.addValue = function (valueToAdd) {
                dataSource.reader.parse = function addDataOnParse(data) {
                    data.value.splice(0, 0, valueToAdd);

                    if (dataSource.reader.parse != null && dataSource.reader.parse != addDataOnParse) {
                        data = dataSource.reader.parse(data);
                    }

                    return data;
                };

                return this;
            };

            return dataSource;
        }
    });