﻿"use strict";
/* This is a helper to build promt definitions

  // Opens a prompt asking whether to execute an action or not
                // okCallback will be called after pressing the OK button.
                // If okCallback returns false, the modal will not be closed
*/

angular
    .module("LeadApp")
    .factory("promptFactory", [
        "$rootScope", "$uibModal",
        function ($rootScope,$uibModal) {
            return function (okCallback,scope, config) {
                if (typeof (config) != "object") {
                    config = {
                    };
                }

                var modalConfig = {
                   
                    size: "sm",
                    backdrop: "static",
                    scope: scope,
                    controller: ["$scope", "$uibModalInstance", function ($scope, $uibModalInstance) {
                        $scope.messageText = config.messageText;
                        $scope.okButtonText = config.okButtonText;

                        if (typeof (config.overriddenScope) == "object") {
                            for (var f in config.overriddenScope) {
                                $scope[f] = config.overriddenScope[f];
                            }
                        }

                        $scope.ok = function () {
                            if (okCallback($scope) !== false) {
                                $uibModalInstance.close();
                            }
                        };

                        $scope.cancel = function () {
                            if (typeof (config.cancelCallback) == "function") {
                                config.cancelCallback($scope);
                            }
                            $uibModalInstance.close();
                        };

                        if (typeof (config.onModalBuilt) == "function") {
                            config.onModalBuilt($scope);
                        }
                    }]
                };

                if (config.templateUrl) {
                    modalConfig.templateUrl = config.templateUrl; //"",
                } else if (config.template) {
                    modalConfig.template = config.template;
                }

                for (var f in config) {
                    modalConfig[f] = config[f];
                }
                if (config.okButtonText == null) config.okButtonText = "BUTTON_OK";
                if (config.messageText == null) config.messageText = "";

                $uibModal.open(modalConfig);
            };
        }
    ]);