﻿"use strict";

/* This is a factory to access of main form fileds.
TODO: write it    
*/

angular
    .module("LeadApp")
    .factory("fieldAccessFacade", [
        "$rootScope",
        function () {
            return function (fieldPath) {

                function componentExists(comp) {
                    return !(comp == null || comp.length === 0);
                }

                var component = $("input[ng-model='" + fieldPath + "']").parent().parent();

                if (!componentExists(component)) {
                    component = $("input[k-ng-model='" + fieldPath + "']").parent().parent().parent().parent();
                }

                if (!componentExists(component)) {
                    component = $("select[k-ng-model='" + fieldPath + "']").parent().parent().parent().parent();
                }
                var scope = null;
                if (!componentExists(component)) {
                    console.error("fieldAccessFacade: can`t find " + fieldPath);
                } else {
                    scope = angular.element(component).scope();
                }

                var container = component.parent();

               

                function replaceByHtml(htmlToReplace) {
                    if (componentExists(component)) {
                        component.remove();
                    }

                    if (componentExists(container)) {
                        angular.element(container).injector().invoke(function ($compile, $timeout) {
                            $timeout(function() {
                                    var $scope = angular.element(container).scope();
                                    container.append($compile($(htmlToReplace))($scope));
                                    // Finally, refresh the watch expressions in the new element
                                    $scope.$apply();
                                },
                                0);//need on next angular ticks
                          
                        });
                    }

                }

                var access = {
                    hide: function(){
                        component.hide();
                    },
                    replaceByHtml: replaceByHtml,
                    scope: scope
                };
                return access;
            }
        }
    ]);