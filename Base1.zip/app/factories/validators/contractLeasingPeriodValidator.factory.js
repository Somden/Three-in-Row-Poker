﻿'use strict';

angular
	.module('LeadApp')
	.factory('contractLeasingPeriodValidator', [
		'validator', 'terminationValidator',
		function (validator, terminationValidator) {
			var rules = new validator();
			rules.ruleFor('EndDate')
				.must(function (x, date) { return !validationHelper.dateIsEmpty(date); })
				.when(function (lp) {
					var contractRevision = lp.ContractRevision || lp.ContractRevisionIfContractLeasingPeriod;

					// Ignore this rule if contract is unlimited
					if (!contractRevision.Contract.IsLimited) return false;

					return contractRevision.Contract.ContractState.Value != "Template";
				})
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('EndDate')
				.must(function (lp, endDate) {
					return new Date(endDate) > new Date(lp.ContractRevisionIfContractLeasingPeriod.Contract.CommencementDate);
				})
				.when(function (lp, endDate) {
					if (validationHelper.dateIsEmpty(endDate)) return false;
					return lp.ContractRevisionIfContractLeasingPeriod.Contract != null && !validationHelper.dateIsEmpty(lp.ContractRevisionIfContractLeasingPeriod.Contract.CommencementDate);
				})
				.withMessage("VALIDATION_LEASING_PERIOD_END_DATE_MUST_BE_BIGGER_THAN_COMMENCEMENT_DATE");
			rules.ruleFor('Duration')
				.notEmpty()
				.when(function (lp) {
					if (!lp.IsRelative) return false;

					var contractRevision = lp.ContractRevision || lp.ContractRevisionIfContractLeasingPeriod;

					// Ignore this rule if contract is unlimited
					if (!contractRevision.Contract.IsLimited) return false;

					return contractRevision.Contract.ContractState.Value != "Template";
				})
				.withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Duration')
				.matches(validationHelper.justDigitsRegex)
				.when(function (lp) { return lp.IsRelative; })
				.withMessage("VALIDATION_JUST_DIGITS");
			rules.ruleFor('TerminationOption').setValidator(terminationValidator);
			rules.ruleFor('PaymentRules').must(function (lp, pr) {
				var cr = lp.ContractRevision || lp.ContractRevisionIfContractLeasingPeriod;

				// If it's Initial, the need to be payment rules
				if (cr.ModificationType.Value == "Initial" && (pr == null || pr.length == 0)) {
					return false;
				}

				return true;
			});

			return rules;
		}
	]);