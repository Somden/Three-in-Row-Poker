﻿'use strict';

angular
	.module('LeadApp')
	.factory('purchaseOptionValidator', [
		'validator', '$translate',
		function (validator, $translate) {
			var rules = new validator();
			rules.ruleFor('PurchaseOptionValue').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PurchaseOptionValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('PurchaseOptionDate').notEmpty().withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			return rules;
		}
	]);