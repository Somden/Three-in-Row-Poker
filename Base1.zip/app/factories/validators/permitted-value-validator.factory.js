﻿'use strict';

angular
	.module('LeadApp')
	.factory('permittedValueValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('Id').greaterThan(-1);
			rules.ruleFor('Value').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);