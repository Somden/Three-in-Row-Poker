﻿'use strict';

angular
	.module('LeadApp')
	.factory('partnerValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('Contact'
				).notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('ExternalId').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('CompanyName').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			return rules;
		}
	]);