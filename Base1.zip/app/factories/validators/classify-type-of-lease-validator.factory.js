﻿'use strict';

angular
	.module('LeadApp')
	.factory('classifyTypeOfLeaseValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('economiclifeValue').greaterThanOrEqual(0).when(function (a, b) {
				return b.toString().length > 0;
			});
			rules.ruleFor('economiclifeValue').lessThanOrEqual(100).when(function (a, b) {
				return b.toString().length > 0;
			});
			rules.ruleFor('recoveryOfInvestmentValue').greaterThanOrEqual(0).when(function (a, b) {
				return b.toString().length > 0;
			});
			rules.ruleFor('recoveryOfInvestmentValue').lessThanOrEqual(100).when(function (a, b) {
				return b.toString().length > 0;
			});
			rules.ruleFor('economiclifeValue').notEmpty().when(function (a, b) {
				return a.recoveryOfInvestmentValue == 0;
			});
			rules.ruleFor('recoveryOfInvestmentValue').notEmpty().when(function (a, b) {
				return a.economiclifeValue == 0;
			});
			return rules;
		}
	]);