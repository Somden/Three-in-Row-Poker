﻿'use strict';

angular
    .module('LeadApp')
    .factory('ledgerAssociationValidator', [
        'validator',
        function (validator) {
            var rules = new validator();
            rules.ruleFor('Ledger').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
            rules.ruleFor('LedgerType').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

            rules.ruleFor('Company')
                .must(function (ledgerAssociation) {

                    if (ledgerAssociation.LedgerType === null || ledgerAssociation.LedgerType === undefined) {
                        return true;
                    }

                    if (ledgerAssociation.LedgerType.RequiresCompany === true) {
                        if (ledgerAssociation.Company === null || ledgerAssociation.Company === undefined || ledgerAssociation.Company.Id === -1) {
                            return false;
                        } else {
                            return true;
                        }
                    } else {
                        return true;
                    }
                })
                .withMessage("VALIDATION_LEDGER_ASSOCIATION_COMPANY_REQUIRED");

            rules.ruleFor('AssetClass')
                .must(function (ledgerAssociation) {

                    if (ledgerAssociation.LedgerType === null || ledgerAssociation.LedgerType === undefined) {
                        return true;
                    }

                    if (ledgerAssociation.LedgerType.RequiresAssetClass === true) {
                        if (ledgerAssociation.AssetClass === null || ledgerAssociation.AssetClass === undefined || ledgerAssociation.AssetClass.Id === -1) {
                            return false;
                        } else {
                            return true;
                        }
                    } else {
                        return true;
                    }
                })
                .withMessage("VALIDATION_LEDGER_ASSOCIATION_ASSET_CLASS_REQUIRED");

            return rules;
        }
    ]);