﻿'use strict';

angular
	.module('LeadApp')
	.factory('exportLogReportValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules
				.ruleFor('evaluationDate')
				.must(function (arg) { return arg.evaluationDate != null; })
				.when(function (arg) {
                    return !arg.isAllEntries;
				});
			return rules;
		}
	]);