﻿'use strict';

angular
	.module('LeadApp')
	.factory('companyValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('Name').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('DefaultCurrency').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('CompanyCode').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);