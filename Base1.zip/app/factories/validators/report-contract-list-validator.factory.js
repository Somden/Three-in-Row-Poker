﻿'use strict';

angular
	.module('LeadApp')
	.factory('reportContractListValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('selectedCompany').notEmpty();
			rules.ruleFor('contractState').must(function (resp) { return resp.contractState != null && resp.contractState.state != ""; });

			return rules;
		}
	]);