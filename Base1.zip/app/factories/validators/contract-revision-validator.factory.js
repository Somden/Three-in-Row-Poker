﻿'use strict';

angular
	.module('LeadApp')
	.factory('contractRevisionValidator', [
		'validator', '$translate',
		function (validator, $translate) {
			var rules = new validator();
			rules.ruleFor('RevisionDescription').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('InterestRate')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS_REGEX"))
				.when(function (contractRevision) { return helpers.getNumericValue(contractRevision.InterestRate) > 0 })
				.withMessage("VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS");
			rules.ruleFor('InterestRate').must(function (cr) {
				return !cr.UseInterestRate || (cr.InterestRate != null && parseFloat(cr.InterestRate) <= 100 && parseFloat(cr.InterestRate) >= 0);
			});

			rules.ruleFor('IncrementalBorrowingRate')
                .matches($translate.instant("VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS_REGEX"))
                .when(function (contractRevision) { return helpers.getNumericValue(contractRevision.IncrementalBorrowingRate) > 0 })
                .withMessage("VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS");

			rules.ruleFor('IncrementalBorrowingRate').must(function (cr) {
				return cr.UseInterestRate || (cr.IncrementalBorrowingRate != null && parseFloat(cr.IncrementalBorrowingRate) <= 100 && parseFloat(cr.IncrementalBorrowingRate) >= 0);
			});
			rules.ruleFor('ResidualValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_FOUR_AFTER_POINTS_REGEX"))
				.when(function (cr) { return cr.ResidualValue != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('ResidualDate')
				.notEmpty()
				.when(function (contractRevision) { return helpers.getNumericValue(contractRevision.ResidualValue) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);