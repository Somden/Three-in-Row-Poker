﻿'use strict';

angular
	.module('LeadApp')
	.factory('accountingStandardsValidator', [
		'validator', 'permittedValueValidator',
		function (validator, permittedValueValidator) {
			var rules = new validator();
			rules.ruleFor('ifrs').setValidator(permittedValueValidator).when(function (accountingStandards) { return accountingStandards.usGaap.Id == -1; }).withMessage("VALIDATION_AT_LEAST_ONE_ACCOUNTING_STANDARD");
			rules.ruleFor('usGaap').setValidator(permittedValueValidator).when(function (accountingStandards) { return accountingStandards.ifrs.Id == -1; }).withMessage("VALIDATION_AT_LEAST_ONE_ACCOUNTING_STANDARD");

			return rules;
		}
	]);