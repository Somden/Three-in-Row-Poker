﻿'use strict';

angular
	.module('LeadApp')
	.factory('terminationValidator', [
		'validator', '$translate',
		function (validator, $translate) {
			var rules = new validator();
			rules.ruleFor('EndDate').notEmpty().withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('EndDate')
				.must(function (x, date) { return !validationHelper.dateIsEmpty(date); })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Duration')
				.matches(validationHelper.justDigitsRegex)
				.withMessage("VALIDATION_JUST_DIGITS");
			rules.ruleFor('ExecutionValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (lp) { return lp.ExecutionValue != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('ExecutionDate')
				.notEmpty()
				.when(function (t) { return helpers.getNumericValue(t.ExecutionValue) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);