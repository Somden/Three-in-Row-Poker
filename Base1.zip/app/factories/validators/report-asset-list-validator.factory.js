﻿'use strict';

angular
	.module('LeadApp')
	.factory('reportAssetListValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('selectedCompany').notEmpty();
			rules.ruleFor('contractState').must(function (resp) { return resp.contractState != null && resp.contractState.state != ""; });
			rules.ruleFor('accountingStandard').notEmpty();
			return rules;
		}
	]);