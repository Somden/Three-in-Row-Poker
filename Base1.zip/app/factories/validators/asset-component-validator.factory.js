﻿'use strict';

angular
	.module('LeadApp')
	.factory('assetComponentValidator', [
		'validator', '$translate',
		function (validator, $translate) {
			var rules = new validator();
			rules.ruleFor('Name').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('AssetClass').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Name').matches(validationHelper.allowStringRegEx);
			rules.ruleFor('AssetShare').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('AssetShare')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('AssetShare')
				.must(function (assetComponent) { return helpers.getNumericValue(assetComponent.AssetShare) <= 100; })
				.withMessage("VALIDATION_LESS_THAN_OR_EQUAL_100_PERCENT");
			rules.ruleFor('AmountChange')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");

			rules.ruleFor('SapAssetNumber').notEmpty().when(function (ac) {
				return ac.SapBookingState && (ac.SapBookingState.Id === 1001 || ac.SapBookingState.Id === 1002);
			}).withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

			rules.ruleFor('CapitalizationStartDate').notEmpty().when(function (ac) {
				return ac.SapBookingState && ac.SapBookingState.Id === 1002;
			}).withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);