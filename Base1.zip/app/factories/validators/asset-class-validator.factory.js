﻿'use strict';

angular
	.module('LeadApp')
	.factory('assetClassValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
            rules.ruleFor('Name').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

            if (!globalConfig.globalAssetClassesEnabled) {
                rules.ruleFor('Company').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
            }
			
			return rules;
		}
	]);