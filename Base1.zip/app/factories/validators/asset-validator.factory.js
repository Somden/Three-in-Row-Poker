﻿'use strict';

angular
	.module('LeadApp')
	.factory('assetValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('Name').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('AssetComponents').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);