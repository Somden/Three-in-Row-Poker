﻿'use strict';

angular
	.module('LeadApp')
	.factory('contractValidator', [
		'validator', 'permittedValueValidator',"kendoDataSourceBuilder",
		function (validator, permittedValueValidator,kendoDataSourceBuilder) {

			var rules = new validator();

			var contractLockDateSettings = null;

		    var contractLockDateSettingDataSource = kendoDataSourceBuilder("/odata/ContractLockDateSetting")
		        .withoutDeleted();

		    function reload() {
		        contractLockDateSettingDataSource.fetch(function () {
		            var data = this.data();
		            contractLockDateSettings = data;

		        });
		    }

		    rules.reloadExternalData = function() {
		        reload();
		    }

		    reload();

		    


		    // User will be set in backend
			rules.ruleFor('Name').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Name').matches(validationHelper.allowStringRegEx).withMessage("VALIDATION_DOES_NOT_MATCH_ALLOW_STRING_REGEX");
			rules.ruleFor('Company').notEmpty().withMessage("VALIDATION_SELECT_MUST_NOT_BE_EMPTY");
			rules.ruleFor('CommencementDate').notEmpty().withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('CommencementDate').must(function (c, date) { return !validationHelper.dateIsEmpty(date); }).withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Currency').notEmpty().withMessage("VALIDATION_SELECT_MUST_NOT_BE_EMPTY");

			rules.ruleFor('ContractType').notEmpty().withMessage("VALIDATION_SELECT_MUST_NOT_BE_EMPTY");
			rules.ruleFor('ContractType').setValidator(permittedValueValidator);

		    rules.ruleFor('CommencementDate')
		        .must(function (contract, date) {
		            if (contract == null || contract.DisplayedContractRevision == null) {
		                return true;
		            }

		            //only for pending initional revisions.
		            //when we are creating reassessment or modification we try check date on special dialogs
		            if (contract.DisplayedContractRevision.ContractRevisionState.Value == 'Pending' &&
		                contract.DisplayedContractRevision.ModificationType.Value == "Initial"
                        ) {
		                var lockDate = validationHelper.getCurrentLockingDate(contract,contractLockDateSettings);
		                var valid = lockDate == null ||
		                    new Date(date) >= new Date(lockDate);
		                return valid;
		            }
		           
		            return true;

		        }).withMessage("CONTRACT_COMMENCEMENT_DATE_AFTER_CONTRACTLOCKINGDATE");

			return rules;
		}
	]);