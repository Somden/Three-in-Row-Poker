﻿'use strict';

angular
	.module('LeadApp')
	.factory('paymentRuleValidator', [
		'validator', 'permittedValueValidator', '$translate',
		function (validator, permittedValueValidator, $translate) {
			var rules = new validator();
			rules.ruleFor('Description').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PaymentStartDate').notEmpty().withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PaymentEndDate').notEmpty().withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PaymentInterval').notEmpty().withMessage("VALIDATION_SELECT_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PaymentInterval').setValidator(permittedValueValidator);
			rules.ruleFor('PaymentFrequency').greaterThan(0).withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PaymentFrequency')
				.matches(validationHelper.justDigitsRegex)
				.withMessage("VALIDATION_JUST_DIGITS");
			rules.ruleFor('PaymentValue')
				.must(function (rule, paymentValue) {
					return helpers.getNumericValue(paymentValue) != 0;
				})
				.withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PaymentValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rule, paymentValue) {
					return helpers.getNumericValue(paymentValue) > 0;
				})
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('InSubstancePaymentValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rule, inSubstancePaymentValue) { return (inSubstancePaymentValue || "") != ""; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");

			rules.ruleFor('PaymentEndDate')
				.must(function (rule, paymentStartDate) { return new Date(paymentStartDate) >= new Date(rule.PaymentStartDate); })
				.withMessage("VALIDATION_FRONTEND_PAYMENT_END_MUST_BE_AFTER_START");

			rules.ruleFor('ScalingFrequency')
				.greaterThan(0).when(function (rule) { return rule.IsScalingEnabled; })
				.withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('ScalingFrequency')
				.matches(validationHelper.justDigitsRegex)
				.withMessage("VALIDATION_JUST_DIGITS");
			rules.ruleFor('ScalingFrequency')
				.must(function (rule, scalingFrequency) { return (scalingFrequency % rule.PaymentFrequency) == 0 })
				.when(function (rule) { return rule.IsScalingEnabled; })
				.withMessage("VALIDATION_MUST_BE_MULTIPLE_OF_INTERVAL");
			rules.ruleFor('AbsoluteScalingValue')
				.greaterThan(0)
				.when(function (rule) { return rule.IsScalingEnabled && (rule.PercentageScalingValue * 1.0) == 0; })
				.withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('AbsoluteScalingValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('PercentageScalingValue')
				.greaterThan(0)
				.when(function (rule) { return rule.IsScalingEnabled && (rule.AbsoluteScalingValue * 1.0) == 0; })
				.withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('PercentageScalingValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");

			return rules;
		}
	]);