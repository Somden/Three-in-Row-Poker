﻿'use strict';

angular
	.module('LeadApp')
	.factory('extensionLeasingPeriodValidator', [
		'validator', 'terminationValidator', '$translate',
		function (validator, terminationValidator, $translate) {
			var rules = new validator();
			rules.ruleFor('EndDate')
				.must(function (x, date) { return !validationHelper.dateIsEmpty(date); })
				.when(function (lp) {
					var contractRevision = lp.ContractRevision || lp.ContractRevisionIfContractLeasingPeriod;
					return contractRevision == null || contractRevision.Contract.ContractState.Value != "Template";
					//TODO Refactor: contractRevision undefined
				})
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");

			rules.ruleFor('ExecutionValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (lp) { return lp.ExecutionValue != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('ExecutionDate')
				.notEmpty()
				.when(function (lp) { return helpers.getNumericValue(lp.ExecutionValue) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Duration').notEmpty().when(function (lp) { return lp.IsRelative; }).withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Duration')
				.matches(validationHelper.justDigitsRegex)
				.when(function (lp) { return lp.IsRelative; })
				.withMessage("VALIDATION_JUST_DIGITS");
			rules.ruleFor('TerminationOption').setValidator(terminationValidator);

			return rules;
		}
	]);