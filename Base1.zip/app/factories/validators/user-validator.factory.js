﻿'use strict';

angular
	.module('LeadApp')
	.factory('userValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('DomainName').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('FirstName').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('LastName').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			return rules;
		}
	]);