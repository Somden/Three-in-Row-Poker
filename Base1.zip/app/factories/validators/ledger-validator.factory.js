﻿'use strict';

angular
    .module('LeadApp')
    .factory('ledgerValidator', [
        'validator',
        function (validator) {
            var rules = new validator();
            rules.ruleFor('Name').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

            return rules;
        }
    ]);