﻿'use strict';

angular
	.module('LeadApp')
	.factory('rightOfUseAssetValidator', [
		'validator', '$translate',
		function (validator, $translate) {
			var rules = new validator();
			rules.ruleFor('ContractInitiationCosts')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rou) { return rou.ContractInitiationCosts != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('Grants')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rou) { return rou.Grants != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('OtherInitialCosts')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rou) { return rou.OtherInitialCosts != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('LeaseIncentivesReceivedAmount')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rou) { return rou.LeaseIncentivesReceivedAmount != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");
			rules.ruleFor('RestorationValue')
				.matches($translate.instant("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS_REGEX"))
				.when(function (rou) { return rou.RestorationValue != 0; })
				.withMessage("VALIDATION_DECIMAL_WITH_TWO_AFTER_POINTS");

			rules.ruleFor('ContractInitiationCostsPaymentDate')
				.notEmpty()
				.when(function (rightOfUseAsset) { return helpers.getNumericValue(rightOfUseAsset.ContractInitiationCosts) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('GrantsPaymentDate')
				.notEmpty()
				.when(function (rightOfUseAsset) { return helpers.getNumericValue(rightOfUseAsset.Grants) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('OtherInitialCostsPaymentDate')
				.notEmpty()
				.when(function (rightOfUseAsset) { return helpers.getNumericValue(rightOfUseAsset.OtherInitialCosts) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('LeaseIncentivesReceivedAmountDate')
				.notEmpty()
				.when(function (rightOfUseAsset) { return helpers.getNumericValue(rightOfUseAsset.LeaseIncentivesReceivedAmount) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");
			rules.ruleFor('RestorationPaymentDate')
				.notEmpty()
				.when(function (rightOfUseAsset) { return helpers.getNumericValue(rightOfUseAsset.RestorationValue) > 0 })
				.withMessage("VALIDATION_DATE_MUST_NOT_BE_EMPTY");

			rules.ruleFor('Assets')
				.must(function (rou, assets) { return rou.ContractRevision.Contract.ContractType.Value != "Lessee" || assets != null && assets.length > 0; });

			rules.ruleFor('Assets').must(function (rou, assets) {
				var sum = 0;
				for (var f in assets) {
					var asset = assets[f];
					if (!asset.IsDeleted) {

						for (var g in asset.AssetComponents) {
							var assetComponent = asset.AssetComponents[g];
							sum += helpers.getNumericValue(assetComponent.AssetShare) * 1.0;
						}
					}
				}

				return sum == 100;
			});

			return rules;
		}
	]);