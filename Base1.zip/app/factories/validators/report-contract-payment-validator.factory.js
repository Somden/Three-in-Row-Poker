﻿'use strict';

angular
	.module('LeadApp')
	.factory('reportContractPaymentValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('selectedContract').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('revision').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");

			return rules;
		}
	]);