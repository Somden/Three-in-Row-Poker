﻿'use strict';

angular
	.module('LeadApp')
	.factory('notesReportValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('selectedCompany').notEmpty();
			rules
				.ruleFor('evaluationEnd')
				.must(function (arg) { return arg.evaluationStart == null || arg.evaluationEnd > arg.evaluationStart; })
				.when(function (arg, date) {
					return (!angular.isDefined(date) || date != null) && !validationHelper.dateIsEmpty(date) && angular.isDefined(arg.evaluationStart);
				});
			rules
				.ruleFor('evaluationStart')
				.must(function (arg) { return arg.evaluationEnd == null || arg.evaluationStart < arg.evaluationEnd; })
				.when(function (arg, date) {
					return (!angular.isDefined(date) || date != null) && !validationHelper.dateIsEmpty(date) && angular.isDefined(arg.evaluationEnd);
				});
			return rules;
		}
	]);