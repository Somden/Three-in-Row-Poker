﻿'use strict';

angular
	.module('LeadApp')
	.factory('currencyValidator', [
		'validator',
		function (validator) {
			var rules = new validator();
			rules.ruleFor('Code').notEmpty().withMessage("VALIDATION_FIELD_MUST_NOT_BE_EMPTY");
			rules.ruleFor('Code').length(3);
			rules.ruleFor('Name').notEmpty(3);
			return rules;
		}
	]);