﻿'use strict';

angular
	.module('LeadApp')
	.factory("messageFactory", [
		"$rootScope", "$timeout", "$translate",
		function ($rootScope, $timeout, $translate) {
			var messages = [];

			function NotificationItem(text, type, details) {
				var self = this;

				self.id = helpers.randomId();
				self.text = text;
				self.type = type || "success";
				self.details = details;

				self.isVisible = true;

				if (self.type == "success" || self.type == "danger" || self.type == "warning") {
					var timeout = self.isError ? 5000 : 2000;
					if (self.type === "warning") {
						timeout = 7000;
					}
					// Hide message after some time
					$timeout(function () {
						self.isVisible = false;
					}, timeout);

					// Remove message completely some seconds after it was hidden
					$timeout(function () {
						removeMessage(self.id);
					}, timeout + 5000);
				}
			}

			function removeMessage(messageId) {
				for (var f in messages) {
					var message = messages[f];
					if (message.id == messageId) {
						messages.splice(f, 1);
						return;
					}
				}
			}

			var loadingMessage = {
				loadingIds: [],

				show: function (translationkey) {
					var id = helpers.randomId();

					$rootScope.$broadcast("LOADING_MESSAGE_SHOW", {
						id: id,
						translationkey: translationkey || "LOADING"
					});

					loadingMessage.loadingIds.push(id);

					return id;
				},
				hide: function (loadingId, $scope) {
					$rootScope.$broadcast("LOADING_MESSAGE_HIDE", loadingId);

					loadingMessage.loadingIds.splice(loadingMessage.loadingIds.indexOf(loadingId));
				},

				isLoadingScreenVisible: function isLoadingScreenVisible() {
					return loadingMessage.loadingIds.length > 0;
				}
			};

			// A message that shows the progress of an export (also send the initial export request)
			var exportNotificationMessage = {
				startExport: function (reportSourceName, reportParameters, reportConfig, translationkey, resourceFactory, exportType) {
					var notification = new NotificationItem(translationkey, "export");

					messages.splice(0, 0, notification);

					reportingHelper
						.getExportItemsRequest(reportSourceName, reportParameters, exportType, reportConfig, resourceFactory)
						.then(function (resp) {
							exportNotificationMessage.startExportFileChecks(resp.ExportId, notification.id, resourceFactory);
						})
						.catch(function (resp) {
							console.error(resp.message);
						});
				},

				addExportWatchByExportId: function (exportId, resourceFactory) {
					var notification = new NotificationItem("Starting to display export", "export");

					messages.splice(0, 0, notification);

					exportNotificationMessage.startExportFileChecks(exportId, notification.id, resourceFactory);
				},

				updateProgress: function (id, message, progress, remainingTime) {
					var notification = getNotificationById(id);

					if (notification != null) {
						notification.progress = progress;
						notification.sideInfo = (Math.round(progress * 10) / 10.0) + "%";
						notification.sideInfoTitle = "Estimated remaining time: " + remainingTime;
						notification.text = message;
					}
				},

				finish: function (id, translationkey, url) {
					var notification = getNotificationById(id);

					if (notification != null) {
						notification.type = "export-success";
						notification.text = translationkey;
						notification.progress = 100;
						notification.sideInfo = null;
						notification.isFinished = true;
						notification.downloadUrl = url;
						notification.download = function () {
							removeMessage(notification.id);

							var win = window.open(notification.downloadUrl, '_blank');
							win.focus();
						};
					}
				},

				showError: function (id, translationkey, errorMessage) {
					var notification = getNotificationById(id);

					if (notification != null) {
						notification.type = "export-error";
						notification.text = translationkey;
						notification.progress = 100;
						notification.sideInfo = null;
						notification.isFinished = true;
						notification.hasError = true;
						notification.errorMessage = errorMessage;
					}
				},

				startExportFileChecks: function (exportId, notificationId, resourceFactory) {
					exportNotificationMessage.checkProgress(exportId, notificationId, resourceFactory, function onResponse(isFinished) {
						if (!isFinished) {
							$timeout(function () {
								exportNotificationMessage.startExportFileChecks(exportId, notificationId, resourceFactory);
							}, 3000);
						}
					});
				},

				checkProgress: function (exportId, messageId, resourceFactory, onResponse) {
					function success(exportObject) {
						$rootScope.$apply(function () {
							if (exportObject.IsFinished) {
								exportNotificationMessage.finish(messageId, "REPORT_EXPORT_READY", exportObject.DownloadUrl);
							}
							else if (exportObject.HasError) {
								exportNotificationMessage.showError(messageId, "REPORT_EXPORT_ERROR", exportObject.ErrorMessage);
							}
							else {
								var lastMessage = exportObject.ExportProgress[exportObject.ExportProgress.length - 1];

								var remainingTime = exportNotificationMessage.getRemainingTime(exportObject.ExportProgress);
								exportNotificationMessage.updateProgress(messageId, lastMessage.Message, lastMessage.Progress, remainingTime);
							}

							if (typeof (onResponse) == "function") {
								onResponse(exportObject.IsFinished);
							}
						});
					}

					resourceFactory
						.reportProgress(exportId)
						.getCurrentProgress()
						.$promise
						.then(success)
						.catch(function () {
							if (typeof (onResponse) == "function") {
								onResponse(false);
							}
						});
				},

				getRemainingTime: function (allMessages) {
					var firstMessage = allMessages[0];
					var lastMessage = allMessages[allMessages.length - 1];

					if (firstMessage == null) return null;
					if (firstMessage.Progress == lastMessage.Progress) return null;

					var startTime = new Date(firstMessage.DateTime);
					var lastTime = new Date(lastMessage.DateTime);
					var diffInSec = (lastTime - startTime) / 1000;
					var estimatedTotalTimeInSec = diffInSec / (lastMessage.Progress / 100.0);

					var remainingTimeInSec = Math.round(estimatedTotalTimeInSec - diffInSec);
					var remainingTimeInMin = Math.ceil(remainingTimeInSec / 60);

					if (remainingTimeInSec < 60) return remainingTimeInSec + "sec";
					else return remainingTimeInMin + "min";
				}
			};

			function getNotificationById(id) {
				for (var f in messages) {
					var notification = messages[f];

					if (notification.id == id) {
						return notification;
					}
				}
			};

			function showSuccessMessage(text) {
				messages.splice(0, 0, new NotificationItem(text));
			}

			function showWarningMessage(text) {
				messages.splice(0, 0, new NotificationItem(text, "warning"));
			}

			function showErrorMessage(text, details) {
				messages.splice(0, 0, new NotificationItem(text, "danger", details));
			}

			return {
				loadingMessage: loadingMessage,
				exportNotificationMessage: exportNotificationMessage,

				showSuccessMessage: showSuccessMessage,
				showErrorMessage: showErrorMessage,
				showWarningMessage: showWarningMessage,

				messages: messages
			};
		}
	]);