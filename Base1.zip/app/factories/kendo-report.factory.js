﻿"use strict";

/* This is a helper to bulild kendo grid.

Here is an example for how to call it:
TODO: write it    
*/

angular
    .module("LeadApp")
    .factory("kendoReportFactory", [
        "$rootScope",
        function ($rootScope) {
            return function (reportElementId,reportName,config) {
            	config = config || {};
            	var reportElement = $("#" + reportElementId);
                if (!reportElement.length) {
                    throw reportElementId+" not found for kendo reporting";
                }

                if (!reportElement.data("telerik_ReportViewer")) {

                	var source = null;
                    if (config.previewLoad) {
                        source = { report: reportName }
                        if (config.parameters) {
                            source.parameters = config.parameters;
                        }
                    }

                    reportElement.telerik_ReportViewer({
                        serviceUrl: config.serviceUrl || "/repapi/reports",
                        reportSource: source,
                        viewMode: config.ViewMode || telerikReportViewer.ViewModes.INTERACTIVE,
                        scaleMode: config.ScaleMode || telerikReportViewer.ScaleModes.SPECIFIC,
                        scale: 1.0,
                        enableAccessibility: false,
                        ready: function () {
                            if (typeof (config.ready) === "function") {
                                config.ready();
                            }
                        }
                    });
                }
               

                var reportViewer = reportElement.data("telerik_ReportViewer");

                return { 
                    reportViewer: reportViewer,
                    refresh: function(paremeters) {
                        reportViewer.reportSource({
                        	report: reportName,
                        	parameters: paremeters
                        });
                    }
                };
            }
        }
    ]);