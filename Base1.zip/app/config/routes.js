﻿'use strict';

// Setup routes
angular
    .module('LeadApp')
    .config([
        "$routeProvider", "KENDO_OVERVIEW_TEMPLATE_PATH",
        function ($routeProvider, KENDO_OVERVIEW_TEMPLATE_PATH) {
            $routeProvider
                .when('/', {
                    redirectTo: '/contract/contracts',
                })

                // Contracts
                .when('/contract/:contractState/:contractId', {
                    templateUrl: '/app/views/contract/contract.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractController'
                })
                .when('/contract/:contractState', {
                    templateUrl: '/app/views/contract/contract-overview.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractOverviewController',
                    controllerAs: "vm"
                })

                // Reports
                .when('/report/contractSeries', {
                    templateUrl: '/app/views/report/contract-series-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractSeriesReportController',
                    controllerAs: "vm"
                })
                .when('/report/contractPayments', {
                    templateUrl: '/app/views/report/contract-payment-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractPaymentReportController',
                    controllerAs: "vm"
                })
                .when('/report/contractListReport', {
                    templateUrl: '/app/views/report/contract-list-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractListReportController'
                })
                .when('/report/companySummaryReport', {
                    templateUrl: '/app/views/report/company-summary-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'CompanySummaryReportController'
                })
                .when('/report/contractAssetListReport', {
                    templateUrl: '/app/views/report/asset-list-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'AssetListReportController'
                })
                .when('/report/notesReport', {
                    templateUrl: '/app/views/report/notes-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'NotesReportController'
                })
                .when('/report/exportLogReport', {
                    templateUrl: '/app/views/report/export-log-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ExportLogReportController'
                })
                .when('/report/paymentRulesReport', {
                    templateUrl: '/app/views/report/payment-rule-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'PaymentRulesReportController'
                })
                .when('/report/bookingEntriesReport', {
                    templateUrl: '/app/views/report/booking-entries-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'BookingEntriesReportController'
                })
                .when('/report/bookingEntriesReportMonthly', {
                    templateUrl: '/app/views/report/booking-entries-report-monthly.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'BookingEntriesReportMonthlyController'
                })
                .when('/report/bookingEntriesReportQuarterly', {
                    templateUrl: '/app/views/report/booking-entries-report-quarterly.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'BookingEntriesReportQuarterlyController'
                })
                .when('/report/bookingEntriesReportYearly', {
                    templateUrl: '/app/views/report/booking-entries-report-yearly.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'BookingEntriesReportYearlyController'
                })
                .when('/report/contractsControllingBookingOverall', {
                    templateUrl: '/app/views/report/contract-controlling-booking-overall-report.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractsControllingBookingOverall'
                })

            
                // Companies
                .when('/configuration/company/new', {
                    templateUrl: '/app/views/baseData/company.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'CompanyController',
                    controllerAs: "vm"
                })
                .when('/configuration/company/:companyId/edit', {
                    templateUrl: '/app/views/baseData/company.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'CompanyController',
                    controllerAs: "vm"
                })
                .when('/configuration/company', {
                    redirectTo: '/configuration/company/all'
                })
                .when('/configuration/company/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'CompanyOverviewController',
                    controllerAs: "vm"
                })

                // Currencies
                .when('/configuration/currency/new', {
                    templateUrl: '/app/views/baseData/currency.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'CurrencyController',
                    controllerAs: "vm"

                })
                .when('/configuration/currency/:currencyId/edit', {
                    templateUrl: '/app/views/baseData/currency.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'CurrencyController',
                    controllerAs: "vm"

                })
                .when('/configuration/currency', {
                    redirectTo: '/configuration/currency/all'
                })
                .when('/configuration/currency/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'CurrencyOverviewController',
                    controllerAs: "vm"
                })

                // Partners
                .when('/configuration/partner/new', {
                    templateUrl: '/app/views/baseData/partner.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'PartnerController',
                    controllerAs: "vm"

                })
                .when('/configuration/partner/:partnerId/edit', {
                    templateUrl: '/app/views/baseData/partner.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'PartnerController',
                    controllerAs: "vm"
                })
                .when('/configuration/partner', {
                    redirectTo: '/configuration/partner/all'
                })
                .when('/configuration/partner/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'PartnerOverviewController',
                    controllerAs: "vm"
                })

                // Asset Classes
                .when('/configuration/assetClass/new', {
                    templateUrl: '/app/views/baseData/asset-class.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'AssetClassController',
                    controllerAs: "vm"
                })
                .when('/configuration/assetClass/:assetClassId/edit', {
                    templateUrl: '/app/views/baseData/asset-class.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'AssetClassController',
                    controllerAs: "vm"
                })
                .when('/configuration/assetClass', {
                    redirectTo: '/configuration/assetClass/all'
                })
                .when('/configuration/assetClass/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'AssetClassOverviewController',
                    controllerAs: "vm"
                })

                // Ledger
                .when('/configuration/ledgers/new', {
                    templateUrl: '/app/views/baseData/ledger.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'LedgerController',
                    controllerAs: "vm"
                })
                .when('/configuration/ledgers/:ledgerId/edit', {
                    templateUrl: '/app/views/baseData/ledger.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'LedgerController',
                    controllerAs: "vm"
                })
                .when('/configuration/ledgers', {
                    redirectTo: '/configuration/ledgers/all'
                })
                .when('/configuration/ledgers/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'LedgerOverviewController',
                    controllerAs: "vm"
                })

                // Ledger Associations
                .when('/configuration/ledgerAssociation/new', {
                    templateUrl: '/app/views/baseData/ledger-association.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'LedgerAssociationController',
                    controllerAs: "vm"
                })
                .when('/configuration/ledgerAssociation/:ledgerAssociationId/edit', {
                    templateUrl: '/app/views/baseData/ledger-association.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'LedgerAssociationController',
                    controllerAs: "vm"
                })
                .when('/configuration/ledgerAssociation', {
                    redirectTo: '/configuration/ledgerAssociation/all'
                })
                .when('/configuration/ledgerAssociation/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'LedgerAssociationOverviewController',
                    controllerAs: "vm"
                })

                // Users
                .when('/configuration/user/new/:domainName', {
                    templateUrl: '/app/views/configuration/user.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'UserController',
                    controllerAs: "vm"
                })
                .when('/configuration/user/new', {
                    templateUrl: '/app/views/configuration/user.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'UserController',
                    controllerAs: "vm"
                })
                .when('/configuration/user/:userId/edit', {
                    templateUrl: '/app/views/configuration/user.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'UserController',
                    controllerAs: "vm"
                })
                .when('/configuration/user', {
                    redirectTo: '/configuration/user/all'
                })
                .when('/configuration/user/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'UserOverviewController',
                    controllerAs: "vm"
                })

                //ContractLock Date Settings

                .when('/configuration/contractLockDateSettings/new', {
                    templateUrl: '/app/views/configuration/contract-lockdate-settings.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractLockdateSettingsController',
                    controllerAs: "vm"
                })
                .when('/configuration/contractLockDateSettings/:contractLockDateSettingId/edit', {
                    templateUrl: '/app/views/configuration/contract-lockdate-settings.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ContractLockdateSettingsController',
                    controllerAs: "vm"
                })
                .when('/configuration/contractLockDateSettings', {
                    redirectTo: '/configuration/contractLockDateSettings/all'
                })
                .when('/configuration/contractLockDateSettings/:range', {
                    templateUrl: KENDO_OVERVIEW_TEMPLATE_PATH,
                    controller: 'contractLockDateSettingsOverviewController',
                    controllerAs: "vm"
                })

                // Logs
                .when('/configuration/log', {
                    templateUrl: '/app/views/configuration/log-overview.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'LogController'
                })

                // History
                .when('/configuration/history', {
                    templateUrl: '/app/views/configuration/history-overview.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'HistoryController',
                    controllerAs: "vm"
                })

                // UserProfile
                .when('/configuration/userProfile', {
                    templateUrl: '/app/views/configuration/user-profile.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'UserProfileController'
                })

                // Change Password
                .when('/configuration/changePassword', {
                    templateUrl: '/app/views/configuration/change-password.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ChangePasswordController'
                })

                // Change Password
                .when('/configuration/exportOverview', {
                    templateUrl: '/app/views/configuration/export-overview.controller.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ExportOverviewController',
                    controllerAs: 'vm'

                })

                // Extension pages
                .when('/extension/:extensionName', {
                    templateUrl: '/app/views/extension/extension.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ExtensionController'
                })

                .when('/extension/:extensionName/new', {
                    templateUrl: '/app/views/extension/extension.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ExtensionController',
                    controllerAs: 'vm'
                })
                .when('/extension/:extensionName/:entityId/edit', {
                    templateUrl: '/app/views/extension/extension.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ExtensionController',
                    controllerAs: 'vm'
                })
                .when('/extension/:extensionName/:range', {
                    templateUrl: '/app/views/extension/extension.html?cache=' + globalConfig.htmlCacheToken,
                    controller: 'ExtensionController',
                    controllerAs: 'vm'
                })

                .otherwise({
                    redirectTo: '/'
                });
        }
    ]);