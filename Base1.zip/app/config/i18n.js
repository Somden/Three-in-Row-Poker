﻿"use strict";

angular
    .module("LeadApp")
    .config(["$translateProvider", function ($translateProvider) {
        var englishTranslations = {};
        var germanTranslations = {};

        var translationLists = [
            translations
        ];

        // TODO: Find a way without using try catch
        (function () {
            try {
                translationLists.push(overriddenTranslations);
            }
            catch (e) { }
        })();

        for (var f in translationLists) {
            var translationList = translationLists[f];
            for (var g in translationList) {
                var translation = translationList[g];
                var key = translation.key;
                var en = translation.en;
                var de = translation.de;

                englishTranslations[key] = en;
                germanTranslations[key] = de;
            }
        }

        $translateProvider.translations("en", englishTranslations);
        $translateProvider.translations("de", germanTranslations);
        $translateProvider.preferredLanguage("en");
    }]);