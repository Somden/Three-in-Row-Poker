﻿"use strict";

(function () {
    // App initialization
    angular
        .module("LeadApp", [
            "ngRoute",
            "ngResource",
            "ngCookies",
            "pascalprecht.translate",
            "ui.bootstrap",
            "kendo.directives",
            "ngFluentValidation"])

        // Add a custom "XSS Anti Forgery Token" header to all http-calls:
        .config([
            "$httpProvider",
            function ($httpProvider) {
                $httpProvider.defaults.headers.post = { "RequestVerificationToken": globalConfig.antiForgeryToken };
                $httpProvider.defaults.headers.put = { "RequestVerificationToken": globalConfig.antiForgeryToken };
                $httpProvider.defaults.headers.delete = { "RequestVerificationToken": globalConfig.antiForgeryToken };
            }])

        .run([
            "$rootScope", "pageFactory", "resourceFactory",
            function ($rootScope, pageFactory, resourceFactory) {

                var currentLanguage = null;
                if (globalConfig.currentUser.Language != null) {
                    currentLanguage = pageFactory.getLanguageByLanguageKey(globalConfig.currentUser.Language.Value);
                }
                currentLanguage = currentLanguage || pageFactory.getDefaultLanguage();

                retrocycle(globalConfig.currentUser);

                $rootScope.dateFormat = currentLanguage.dateFormat;
                $rootScope.dateMonthYearFormat = currentLanguage.dateMonthYearFormat;
                $rootScope.languageSettings = currentLanguage;
                $rootScope.currentUser = globalConfig.currentUser;
                $rootScope.htmlCacheToken = globalConfig.htmlCacheToken;
                $rootScope.basePathExtensions = globalConfig.basePathExtensions;
                reportingHelper.initializeFieldFormatter(resourceFactory);

                ($rootScope.initializeKendoHelpers = function () {
                    $rootScope.kendoHelpers = buildKendoHelpers($rootScope);
                })();

                if (globalConfig.currentUser.Language != null) {
                    pageFactory.changeLanguage(currentLanguage);
                }
                else {
                    pageFactory.changeLanguage(pageFactory.getDefaultLanguage(), true);
                }
            }]);
}());