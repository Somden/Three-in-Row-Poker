﻿'use strict';

angular
    .module("LeadApp")
    .filter("cultureFormat", [
        "$rootScope",
        function ($rootScope) {
            return function (number, afterCommaDigits) {
                return helpers.numberToCultureString(number, $rootScope, true, afterCommaDigits);
            };
        }
    ]);