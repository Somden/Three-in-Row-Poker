﻿'use strict'

// Zieht das Timezone-Offset vom gegebenen Datetime-Objekt wieder ab, um die originale Zeit zu erhalten.
// Dadurch wird. z.B. eine von einem Webservice erhaltene Uhrzeit "16:30 +01:00", die JavaScript in "17:30 +01:00" umwandelt,
// wieder als "16:30" dargestellt.
// date: DateTime
// Returns: DateTime
function removeDateTimeOffset(date) {
    var kendoDate = kendo.parseDate(date);
    var offset = kendoDate.getTimezoneOffset();
    var result = new Date(kendoDate.getTime() + offset * 60000);
    return result;
}

// Liefert das übergebene DateTime-Objekt als string im deutschen Datumsformat "dd.MM.yyyy HH:mm:ss"
// und rechnet die Uhrzeit über das DateTimeOffset zurück auf UMT.
// Wird z.B. im KendoGrid benutzt, um Date-Columns korrekt darzustellen.
// Returns: string
function renderKendoDateTime(date) {
    var newDate = removeDateTimeOffset(date);
    return kendo.toString(newDate, "dd.MM.yyyy HH:mm:ss");
}

// Liefert das übergebene DateTime-Objekt als string im deutschen Datumsformat "dd.MM.yyyy HH:mm:ss"
// Wird z.B. im KendoGrid benutzt, um Date-Columns korrekt darzustellen.
// Returns: string
function renderDateTime(date, format) {
    if (format != null && format.length > 0)
        return kendo.toString(date, format);
    return kendo.toString(date, "dd.MM.yyyy HH:mm:ss");
}

function renderKendoCustomDateTime(date, format) {
    var newDate = removeDateTimeOffset(date);
    return kendo.toString(newDate, format);
}

// Liefert das übergebene DateTime-Objekt als string im deutschen Datumsformat "dd.MM.yyyy HH:mm:ss"
// und rechnet die Uhrzeit über das DateTimeOffset zurück auf UMT.
// Wird z.B. im KendoGrid benutzt, um Date-Columns korrekt darzustellen.
// Returns: string
function renderKendoDate(date, format) {
    if (date != null) {
        var newDate = removeDateTimeOffset(date);
        return kendo.toString(newDate, format);
    }
    return "";
}