﻿'use strict';

angular
    .module('LeadApp')
    .component('navigationComponent', {
        templateUrl: "/app/components/navigation.component.html",
        controllerAs: "vm",
        controller: [
            "$rootScope", "$location", "$injector",
            function ($rootScope, $location, $injector) {
                var vm = this;

                (function initialize(){
                    vm.isActive = isActive;
                    vm.isSubItemVisible = isSubItemVisible;
                    vm.navigateTo = navigateTo;

                    vm.orderedNavigation = [];
                })();

                var navigationItems = [];
                var visibilityOfSubItems = [];
                var pageExtensionDefinitions = null;
                if ($injector.has("pageExtensionDefinitions")) {
                    pageExtensionDefinitions = $injector.get("pageExtensionDefinitions");
                }

                function findSubItemsFor(mainItem) {
                    var subItems = [];
                    for (var f in navigationItems) {
                        var subItem = navigationItems[f];
                        if (subItem.subItemOf == mainItem.id) {
                            subItems.push(subItem);
                        }
                    }
                    return subItems;
                };

                function navigateTo(item) {
                    if (item.hasSubItems) {
                        if (visibilityOfSubItems[item.id] == null) {
                            visibilityOfSubItems[item.id] = true;
                        }
                        else {
                            visibilityOfSubItems[item.id] = !visibilityOfSubItems[item.id];
                        }
                    }

                    if (item.path != null) {
                        location.href = "#!" + item.path;
                    }
                };

                function isSubItemVisible(item) {
                    return visibilityOfSubItems[item.subItemOf] || false;
                };

                function isActive(item) {
                    if (item.path === $location.path()) {
                        return true;
                    }

                    if (item.highlightSubPaths) {
                        return $location.path().substr(0, item.path.length) == item.path;
                    }

                    return false;
                };

                function defineStandardNavigationItems() {
                    var contractsNavigationItem = new NavigationMainItem("contractsMenuItem", "ITEM_MAIN_CONTRACTS", "fa-file-text-o");
                    var reportsNavigationItem = new NavigationMainItem("reportsMenuItem", "ITEM_MAIN_REPORTS", "fa-table");
                    var baseDataNavigationItem = new NavigationMainItem("baseDataMenuItem", "ITEM_MAIN_BASE_DATA", "fa-wrench");
                    var settingsNavigationItem = new NavigationMainItem("configurationMenuItem", "ITEM_MAIN_SETTINGS", "fa-cog");

                    navigationItems = [
                        contractsNavigationItem,
                        reportsNavigationItem,
                        baseDataNavigationItem
                    ];

                    if ($rootScope.currentUser.IsAdmin) {
                        navigationItems.push(settingsNavigationItem);
                    }

                    navigationItems = navigationItems.concat([
                        new NavigationSubItem("ITEM_SUB_CONTRACTS_ALL", "/contract/contracts", contractsNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_CONTRACTS_TEMPLATES", "/contract/templates", contractsNavigationItem.id, true),

                        new NavigationSubItem("ITEM_SUB_REPORT_CONTRACT_SERIES_REPORT", "/report/contractSeries", reportsNavigationItem.id),
                        new NavigationSubItem("ITEM_SUB_REPORT_CONTRACT_PAYMENTS_REPORT", "/report/contractPayments", reportsNavigationItem.id),
                        new NavigationSubItem("ITEM_SUB_REPORT_CONTRACT_LIST_REPORT", "/report/contractListReport", reportsNavigationItem.id),
                        new NavigationSubItem("ITEM_SUB_REPORT_ASSET_LIST_REPORT", "/report/contractAssetListReport", reportsNavigationItem.id),

                        new NavigationSubItem("ITEM_SUB_REPORT_COMPANY_SUMMARY_REPORT", "/report/companySummaryReport", reportsNavigationItem.id),
                        new NavigationSubItem("ITEM_SUB_REPORT_NOTES_REPORT", "/report/notesReport", reportsNavigationItem.id),
                        new NavigationSubItem("ITEM_SUB_REPORT_EXPORT_LOG_REPORT", "/report/exportLogReport", reportsNavigationItem.id),
                        
                        new NavigationSubItem("ITEM_SUB_CONFIGURATION_USERS", "/configuration/user", settingsNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_CONFIGURATION_LOG", "/configuration/log", settingsNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_CONFIGURATION_HISTORY", "/configuration/history", settingsNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_CONFIGURATION_CONTRACTLOCKDATESETTINGS", "/configuration/contractLockDateSettings", settingsNavigationItem.id, true),

                        new NavigationSubItem("ITEM_SUB_CONFIGURATION_COMPANIES", "/configuration/company", baseDataNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_CONFIGURATION_PARTNERS", "/configuration/partner", baseDataNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_BASEDATA_CURRENCY", "/configuration/currency", baseDataNavigationItem.id, true),
                        new NavigationSubItem("ITEM_SUB_BASEDATA_ASSETCLASS", "/configuration/assetClass", baseDataNavigationItem.id, true),                        
                    ]);

                    if (!globalConfig.noBaseControllingReports) {
                        navigationItems = navigationItems.concat([
                            //new NavigationSubItem("ITEM_SUB_REPORT_PAYMENTRULES_REPORT", "/report/paymentRulesReport", reportsNavigationItem.id),
                            //new NavigationSubItem("ITEM_SUB_REPORT_BOOKING_ENTIRES_REPORT", "/report/bookingEntriesReport", reportsNavigationItem.id),
                            //new NavigationSubItem("ITEM_SUB_REPORT_BOOKING_ENTIRES_MONTHLY_REPORT", "/report/bookingEntriesReportMonthly", reportsNavigationItem.id),
                            //new NavigationSubItem("ITEM_SUB_REPORT_BOOKING_ENTIRES_QUARTERLY_REPORT", "/report/bookingEntriesReportQuarterly", reportsNavigationItem.id),                            
                            //new NavigationSubItem("ITEM_SUB_REPORT_BOOKING_ENTIRES_YEARLY_REPORT", "/report/bookingEntriesReportYearly", reportsNavigationItem.id), 
                            //new NavigationSubItem("ITEM_SUB_REPORT_CONTRACT_BOOKING_OVERALL", "/report/contractsControllingBookingOverall", reportsNavigationItem.id)                             
                        ]);
                    }

                    if (!globalConfig.noLedgerManagement) {
                        navigationItems = navigationItems.concat([
                            new NavigationSubItem("ITEM_SUB_BASEDATA_LEDGER", "/configuration/ledgers", baseDataNavigationItem.id, true),
                            new NavigationSubItem("ITEM_SUB_BASEDATA_LEDGERASSOCIATION", "/configuration/ledgerAssociation", baseDataNavigationItem.id, true),
                        ]);
                    }
                };

                function addExtensionPagesToNavigation() {
                    if (pageExtensionDefinitions == null) {
                        return;
                    }

                    for (var f in pageExtensionDefinitions) {
                        var item = pageExtensionDefinitions[f];
                        navigationItems.push(new NavigationExtensionSubItem(item.title, item.componentName, item.mainNavigationItem));
                    }
                };

                function getActiveMainItemId() {
                    for (var f in navigationItems) {
                        var item = navigationItems[f];
                        if (vm.isActive(item)) {
                            return item.subItemOf;
                        }
                    }
                };

                function expandMainItemAccordingToUrl() {
                    var mainItemId = getActiveMainItemId();
                    if (mainItemId != null) {
                        visibilityOfSubItems[mainItemId] = true;
                    }
                };

                function getMainNavigationItems() {
                    var mainItems = [];
                    for (var f in navigationItems) {
                        var item = navigationItems[f];
                        if (item.isMainItem) {
                            mainItems.push(item);
                        }
                    }

                    return mainItems;
                }

                function buildNavigation() {
                    var mainItems = getMainNavigationItems();
                    for (var f in mainItems) {
                        var item = mainItems[f];
                        vm.orderedNavigation.push(item);

                        var subItems = findSubItemsFor(item);
                        for (var g in subItems) {
                            vm.orderedNavigation.push(subItems[g]);
                        }
                    }
                };

                this.$onInit = function () {
                    defineStandardNavigationItems();
                    addExtensionPagesToNavigation();
                    expandMainItemAccordingToUrl();

                    buildNavigation();
                };
            }
        ]
    });