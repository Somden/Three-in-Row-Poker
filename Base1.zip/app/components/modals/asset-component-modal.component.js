﻿'use strict';

angular
    .module("LeadApp")
    .directive('assetComponentModal', [
        "$filter", "$uibModal", "assetComponentValidator", "kendoDataSourceBuilder",
        function ($filter, $uibModal, assetComponentValidator, kendoDataSourceBuilder) {
            return {
                templateUrl: "/app/components/modals/asset-component-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "=",
                    isInitialRevision: "=",
                    isReassessment: "=",
                    isModification: "=",
                    isFormReadonly: "=",
                    isHelpVisible: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    var modalConfig = {
                        template: $("#assetComponentModal").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        controller: ["$scope", "$rootScope", "$uibModalInstance", function ($scope, $rootScope, $uibModalInstance) {
                            $scope.isInitialRevision = $directiveScope.isInitialRevision;
                            $scope.isReassessment = $directiveScope.isReassessment;
                            $scope.isModification = $directiveScope.isModification;
                            $scope.isFormReadonly = $directiveScope.isFormReadonly;
                            $scope.isHelpVisible = $directiveScope.isHelpVisible;
                            $scope.validator = assetComponentValidator;

                            $scope.isEdit = function () { return $scope.config.assetComponent != null; }

                            $scope.contract = $directiveScope.config.contract;

                            var filterAssetClassId = ($scope.config.assetComponent == null || $scope.config.assetComponent.AssetClass == null) ? null : $scope.config.assetComponent.AssetClass.Id;
                            $scope.assetComponentDataSource = kendoDataSourceBuilder("/odata/AssetClass")
                                .whereEquals("Id", filterAssetClassId)
                                .orEquals("IsDeleted", false)
                                .whereEquals("Company_Id", $scope.contract.Company.Id)
                                .or({ field: "Company_Id", operator: "eq", value: null });
                            $scope.sapBookingStateDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                                .whereEquals("EnumType", "SapBookingState");

                            $scope.assetComponentForm = {
                                Id: -helpers.randomId(),
                                IsLimited: true,
                                SapBookingState_Id: 1000,
                                SapBookingState: {
                                    Id: 1000,
                                    EnumType: "SapBookingState",
                                    Value: "NotPosted"
                                },
                                AssetShare: 100,
                                AmountChange: 100
                            };
                            if ($scope.isEdit()) {
                                helpers.objectAssign($scope.assetComponentForm, $scope.config.assetComponent);
                            }

                            $scope.hasModalErrors = function (asset) {
                                return !assetComponentValidator.validate(asset).isValid;
                            };

                            $scope.ok = function () {
                                if ($scope.config.callback($scope.assetComponentForm, $scope.isEdit()) !== false) {
                                    $scope.config.isOpen = false;
                                }
                            };

                            $scope.$watch("config.isOpen", function (isOpen) {
                                $directiveScope.config.isOpen = isOpen;
                            });
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);