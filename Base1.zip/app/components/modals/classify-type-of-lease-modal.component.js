﻿'use strict';

angular
    .module("LeadApp")
    .directive('classifyTypeOfLeaseModal', [
        '$filter', '$uibModal', 'classifyTypeOfLeaseValidator', 'messageFactory', 'resourceFactory',
        function ($filter, $uibModal, classifyTypeOfLeaseValidator, messageFactory, resourceFactory) {
            return {
                templateUrl: "/app/components/modals/classify-type-of-lease-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "=",
                    isHelpVisible: "=",
                    isFormReadonly: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    $scope.hasModalErrors = function (classifyTypeOfLease) {
                        return !classifyTypeOfLeaseValidator.validate(classifyTypeOfLease).isValid;
                    };

                    var modalConfig = {
                        template: $("#classifyTypesOfLeaseModal").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        controller: ["$scope", "$uibModalInstance", function ($scope, $uibModalInstance) {
                            $scope.isHelpVisible = $directiveScope.isHelpVisible;

                            $scope.classifyTypeOfLease = {
                                classification: "",
                                automaticTransfer: false,
                                barginPurchase: false,
                                specialisation: false,
                                economiclife: false,
                                economiclifeValue: 0.0,
                                recoveryOfInvestment: false,
                                recoveryOfInvestmentValue: 0.0
                            };

                            var callback = function ($scope) {
                                if (!$scope.isFormReadonly() && $scope.classifyTypeOfLease.classification != "") {
                                    for (var f in $scope.accountingStandardUsGaapValues.value) {
                                        if ($scope.accountingStandardUsGaapValues.value[f].Value == $scope.classifyTypeOfLease.classification) {
                                            $scope.accountingStandard.usGaap = $scope.accountingStandardUsGaapValues.value[f];
                                            break;
                                        }
                                    }
                                }
                                return true;
                            };

                            $scope.ok = function () {
                                $scope.config.callback($scope.classifyTypeOfLease.classification);
                                $scope.config.isOpen = false;
                            };

                            $scope.refreshClassifyTypeOfLease = function () {
                                var typeofleaseClass = {
                                    Contract: $scope.config.contract,
                                    EconomiclifeValue: $scope.classifyTypeOfLease.economiclifeValue.toString().replace(",", ".") / 100.0,
                                    RecoveryOfInvestmentValue: $scope.classifyTypeOfLease.recoveryOfInvestmentValue.toString().replace(",", ".") / 100.0,
                                    Specialisation: $scope.classifyTypeOfLease.specialisation
                                };
                                var decycledtypeofleaseClass = decycle(typeofleaseClass);

                                $scope.loadingId = messageFactory.loadingMessage.show("CALCULATE_CLASSIFY_TYPE");
                                resourceFactory.calculationHelper($scope.config.contract.Id).GetTypeOfLease(decycledtypeofleaseClass).$promise
                                    .then(function (resp) {
                                        $scope.classifyTypeOfLease.classification = resp.Payload.classification;
                                        $scope.classifyTypeOfLease.economiclife = resp.Payload.economiclife;
                                        $scope.classifyTypeOfLease.recoveryOfInvestment = resp.Payload.recoveryOfInvestment;
                                        $scope.classifyTypeOfLease.automaticTransfer = resp.Payload.automaticTransfer;
                                        $scope.classifyTypeOfLease.barginPurchase = resp.Payload.bargain_purchase_option;
                                    })
                                    .catch(function (resp) {
                                        $scope.resourceErrors =
                                        {
                                            list: resp.data.ValidationErrors
                                        }
                                    })
                                    .finally(function (resp) {
                                        messageFactory.loadingMessage.hide($scope.loadingId); $scope.loadingId = null;
                                    });
                            };
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);