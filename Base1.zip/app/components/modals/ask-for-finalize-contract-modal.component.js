﻿'use strict';

angular
    .module("LeadApp")
    .directive('askForFinalizeContractModal', [
        '$uibModal',
        function ($uibModal) {
            return {
                templateUrl: "/app/components/modals/ask-for-finalize-contract-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "=",
                    activateDate: "=",
                    retirementDate: "=",
                    isHelpVisible: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    var modalConfig = {
                        template: $("#askForFinalizeContractModalTemplate").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        controller: ["$scope", "$uibModalInstance", function ($scope, $uibModalInstance) {
                            $scope.isHelpVisible = $directiveScope.isHelpVisible;

                            $scope.activateDate = $directiveScope.config.activateDate;
                            $scope.ok = function () {
                                if ($scope.config.callback($scope.retirementDate) !== false) {
                                    $scope.config.isOpen = false;
                                }
                            };

                            $scope.hasModalErrors = function () {
                                if ($scope.config.askForTerminated) {
                                    if ($scope.retirementDate == null) return true;
                                    if ($scope.retirementDate == validationHelper.minDateString) return true;
                                    if (new Date($scope.retirementDate) < new Date($scope.activateDate)) return true;
                                }

                                return false;
                            };

                            $scope.$watch("config.isOpen", function (isOpen) {
                                $directiveScope.config.isOpen = isOpen;
                            });
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);