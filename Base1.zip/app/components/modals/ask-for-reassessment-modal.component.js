'use strict';

angular
    .module("LeadApp")
    .directive('askForReassessmentModal', [
        '$uibModal',
        function ($uibModal) {
            return {
                templateUrl: "/app/components/modals/ask-for-reassessment-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "=",
                    currentActivateDate: "=",
                    isHelpVisible: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    var modalConfig = {
                        template: $("#askForReassessmentModalTemplate").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        controller: ["$scope", "$rootScope", "$uibModalInstance","kendoDataSourceBuilder", function ($scope, $rootScope, $uibModalInstance,kendoDataSourceBuilder) {
                            $scope.isHelpVisible = $directiveScope.isHelpVisible;

                            $scope.contract = $directiveScope.config.contract;

                            $scope.minimumNewActivateDate = new Date($scope.currentActivateDate);
                            $scope.minimumNewActivateDate.setDate($scope.minimumNewActivateDate.getDate() + 1);


                            var contractLockDateSettings = null;

                            var contractLockDateSettingDataSource = kendoDataSourceBuilder("/odata/ContractLockDateSetting")
                                .withoutDeleted();

                            contractLockDateSettingDataSource.fetch(function () {
                                var data = this.data();
                                contractLockDateSettings = data;

                            });


                            $scope.ok = function () {
                                if ($scope.config.callback($scope.activateDate) !== false) {
                                    $scope.config.isOpen = false;
                                }
                            };

                            $scope.hasModalErrors = function () {
                                if ($scope.activateDate == null) return true;
                                if ($scope.activateDate == validationHelper.minDateString) return true;
                                if (new Date($scope.activateDate) < $scope.minimumNewActivateDate) return true;

                                var lockDate = validationHelper.getCurrentLockingDate($scope.contract, contractLockDateSettings);
                                if (lockDate != null) {
                                    return new Date(lockDate)>new Date($scope.activateDate);
                                }

                                return false;
                            };

                            $scope.$watch("config.isOpen", function (isOpen) { $directiveScope.config.isOpen = isOpen; });
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);