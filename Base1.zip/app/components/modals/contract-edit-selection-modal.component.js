﻿'use strict';

angular
    .module("LeadApp")
    .directive('contractEditSelectionModal', [
        '$uibModal',
        function ($uibModal) {
            return {
                templateUrl: "/app/components/modals/contract-edit-selection-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    var modalConfig = {
                        template: $("#contractEditSelectionModalTemplate").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        closing: function () {
                            return true;
                        },
                        controller: ["$scope", "$uibModalInstance", function ($scope, $uibModalInstance) {
                            $scope.contract = $directiveScope.config.contract;

                            $scope.canCreateReassessment = $directiveScope.config.canCreateReassessment;
                            $scope.canCreateModification = $directiveScope.config.canCreateModification;

                            $scope.closeModal = function (callback) {
                                $scope.config.isOpen = false;

                                if (typeof (callback) == "function") {
                                    callback();
                                }
                            };

                            $scope.askForReassessment = function () { $scope.closeModal($directiveScope.config.askForReassessment); };
                            $scope.askForModification = function () { $scope.closeModal($directiveScope.config.askForModification) };
                            $scope.makeCurrentRevisionEditable = function () { $scope.closeModal($directiveScope.config.makeCurrentRevisionEditable) };

                            $scope.$watch("config.isOpen", function (isOpen) { $directiveScope.config.isOpen = isOpen; });
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);