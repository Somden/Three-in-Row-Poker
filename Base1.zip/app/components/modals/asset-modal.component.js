﻿'use strict';

angular
    .module("LeadApp")
    .directive('assetModal', [
        '$filter', '$uibModal', 'assetModalValidator',
        function ($filter, $uibModal, assetModalValidator) {
            return {
                templateUrl: "/app/components/modals/asset-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "=",
                    isFormReadonly: "=",
                    isInitialRevision: "=",
                    isHelpVisible: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    var modalConfig = {
                        template: $("#assetModal").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        controller: ["$scope", "$rootScope", "$uibModalInstance", function ($scope, $rootScope, $uibModalInstance) {
                            $scope.isReassessment = $directiveScope.isReassessment;
                            $scope.isFormReadonly = $directiveScope.isFormReadonly;
                            $scope.isInitialRevision = $directiveScope.isInitialRevision;
                            $scope.isHelpVisible = $directiveScope.isHelpVisible;

                            $scope.isEdit = function () { return $scope.config.asset != null };

                            $scope.contract = $directiveScope.config.contract;

                            $scope.assetForm = { Id: -helpers.randomId() };
                            if ($scope.isEdit()) {
                                helpers.objectAssign($scope.assetForm, $scope.config.asset);
                            }

                            $scope.hasModalErrors = function (asset) {
                                return !assetModalValidator.validate(asset).isValid;
                            };

                            $scope.ok = function () {
                                if ($scope.config.callback($scope.assetForm, $scope.isEdit()) !== false) {
                                    $scope.config.isOpen = false;
                                }
                            };

                            $scope.$watch("config.isOpen", function (isOpen) { $directiveScope.config.isOpen = isOpen; });
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);