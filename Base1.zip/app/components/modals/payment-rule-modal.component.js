﻿'use strict';

angular
    .module("LeadApp")
    .directive("paymentRuleModal", [
        "$filter", "$uibModal", "paymentRuleValidator", "resourceFactory", "kendoDataSourceBuilder",
        function ($filter, $uibModal, paymentRuleValidator, resourceFactory, kendoDataSourceBuilder) {
            return {
                templateUrl: "/app/components/modals/payment-rule-modal.component.html?cache=" + globalConfig.htmlCacheToken,
                restrict: 'E',
                scope: {
                    config: "=",
                    isReassessment: "=",
                    isHelpVisible: "="
                },
                controller: ['$scope', function ($scope) {
                    var $directiveScope = $scope;

                    var modalConfig = {
                        template: $("#paymentRuleModalTemplate").html(),
                        size: "md",
                        backdrop: "static",
                        scope: $scope,
                        controller: ["$scope", "$rootScope", "$uibModalInstance", function ($scope, $rootScope, $uibModalInstance) {
                            $scope.isHelpVisible = $directiveScope.isHelpVisible;
                            $scope.isReassessment = $directiveScope.isReassessment;

                            $scope.isEdit = function () { return $scope.config.paymentRule != null };

                            $scope.isAutoDescriptionEnabled = !$scope.isEdit(),
                            $scope.contract = $directiveScope.config.contract;
                            $scope.intervalDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                                .whereEquals("EnumType", "Interval");

                            $scope.paymentRuleForm = { Id: -helpers.randomId() };
                            if ($scope.isEdit()) {
                                helpers.objectAssign($scope.paymentRuleForm, $scope.config.paymentRule);

                                if ($scope.paymentRuleForm.IsScalingEnabled == null) {
                                    $scope.paymentRuleForm.IsScalingEnabled = $scope.paymentRuleForm.ScalingFrequency > 0;
                                }

                                if ($scope.paymentRuleForm.HasScalingInPercentage == null) {
                                    $scope.paymentRuleForm.HasScalingInPercentage = helpers.getNumericValue($scope.paymentRuleForm.PercentageScalingValue) > 0;
                                }
                            }

                            if ($scope.config.onlyOneTimePayments) {
                                resourceFactory.permittedValue("Interval", "Once").getByEnumType().$promise.then(
                                    function (resp) {
                                        $scope.paymentRuleForm.PaymentInterval = resp.value[0];
                                    });
                            }

                            $scope.showScalingOption = function() {
                                return $scope.paymentRuleForm.PaymentInterval.Value !== "Once";
                            }

                            $scope.isFullyEditable = function () {
                                return !$scope.isReassessment() || $scope.paymentRuleForm.Id < 0;
                            };

                            $scope.hasModalErrors = function (paymentRule) {
                                return !paymentRuleValidator.validate(paymentRule).isValid;
                            };

                            $scope.getIntervalDescription = function (interval) {
                                switch (interval) {
                                    case "Monthly":
                                        return "MONTHS";
                                    case "Yearly":
                                        return "YEARS";
                                }
                            };

                            $scope.determineDescription = function () {
                                var parts = [];
                                if ($scope.paymentRuleForm.PaymentInterval != null) {
                                    var interval = $scope.paymentRuleForm.PaymentInterval.Value;
                                    var frequency = $scope.paymentRuleForm.PaymentFrequency || 0;

                                    switch (interval) {
                                        case "Once":
                                            parts.push("One time payment");
                                            break;
                                        case "Monthly":
                                            if (frequency == 1) parts.push("Payment every month");
                                            else parts.push("Payment every " + frequency + " months");
                                            break;
                                        case "Yearly":
                                            if (frequency == 1) parts.push("Payment every year");
                                            else parts.push("Payment every " + frequency + " years");
                                            break;
                                    }
                                }

                                if ($scope.paymentRuleForm.PaymentStartDate != null) {
                                    var timeString = "from " + $filter('date')($scope.paymentRuleForm.PaymentStartDate, "yyyy-MM-dd");

                                    if ($scope.paymentRuleForm.PaymentEndDate != null) {
                                        timeString += " to " + $filter('date')($scope.paymentRuleForm.PaymentEndDate, "yyyy-MM-dd");
                                    }

                                    if ($scope.paymentRuleForm.PaymentInterval != null && $scope.paymentRuleForm.PaymentInterval.Value == "Once") {
                                        timeString = "at " + $filter('date')($scope.paymentRuleForm.PaymentStartDate, "yyyy-MM-dd");
                                    }

                                    parts.push(timeString);
                                }

                                $scope.paymentRuleForm.Description = parts.join(" ");
                            };

                            $scope.toggleIsAutoDescription = function () {
                                $scope.isAutoDescriptionEnabled = !$scope.isAutoDescriptionEnabled;

                                if ($scope.isAutoDescriptionEnabled) {
                                    $scope.determineDescription();
                                }
                            };

                            $scope.ok = function () {
                                switch ($scope.paymentRuleForm.PaymentInterval.Value) {
                                    case "Once":
                                        $scope.paymentRuleForm.PaymentEndDate = $scope.paymentRuleForm.PaymentStartDate;
                                        break;
                                    default: break;
                                }
                                if ($scope.config.callback($scope.paymentRuleForm, $scope.isEdit()) !== false) {
                                    $scope.config.isOpen = false;
                                }
                            };

                            $scope._onPaymentRuleFormChange = function () {
                                $scope.hasModalErrors($scope.paymentRuleForm);

                                if ($scope.isAutoDescriptionEnabled) {
                                    $scope.determineDescription();
                                }

                                if (!$scope.canDetermineFrequency) {
                                    $scope.paymentRuleForm.PaymentFrequency = 1;
                                }

                                if (!$scope.canDetermineFrequency
                                    && $scope.paymentRuleForm.PaymentStartDate != null
                                    && $scope.isFullyEditable()) {
                                    console.log("[paymentRuleModal.js] Setting PaymentEndDate to PaymentStartDate");
                                    $scope.paymentRuleForm.PaymentEndDate = $scope.paymentRuleForm.PaymentStartDate;
                                }

                                if ($scope.paymentRuleForm.IsScalingEnabled == null) {
                                    $scope.paymentRuleForm.IsScalingEnabled = $scope.paymentRuleForm.ScalingFrequency > 0;
                                }

                                if ($scope.paymentRuleForm.HasScalingInPercentage == null) {
                                    $scope.paymentRuleForm.HasScalingInPercentage = helpers.getNumericValue($scope.paymentRuleForm.PercentageScalingValue) > 0;
                                }

                                if (!$scope.paymentRuleForm.IsScalingEnabled) {
                                    $scope.paymentRuleForm.ScalingFrequency = 0;
                                    $scope.paymentRuleForm.AbsoluteScalingValue = 0;
                                    $scope.paymentRuleForm.PercentageScalingValue = 0;
                                }

                                if ($scope.paymentRuleForm.HasScalingInPercentage) {
                                    $scope.paymentRuleForm.AbsoluteScalingValue = 0;
                                }
                                else if (!$scope.paymentRuleForm.HasScalingInPercentage) {
                                    $scope.paymentRuleForm.PercentageScalingValue = 0;
                                }
                            };

                            $scope._onPaymentIntervalChange = function () {
                                if ($scope.paymentRuleForm.PaymentInterval == null) return;

                                switch ($scope.paymentRuleForm.PaymentInterval.Value) {
                                    case "Monthly":
                                    case "Yearly":
                                        if ($scope.canDetermineFrequency)
                                            break;
                                        $scope.canDetermineFrequency = true;
                                        break;
                                    default:
                                        if (!$scope.canDetermineFrequency)
                                            break;
                                        $scope.canDetermineFrequency = false;
                                        break;
                                }
                            };

                            $scope._onPaymentIntervalChange();

                            $scope.$watch("config.isOpen", function (isOpen) { $directiveScope.config.isOpen = isOpen; });
                        }]
                    };

                    $directiveScope.$watch("config.isOpen", function (isOpen, oldValue) {
                        if (isOpen == oldValue) return;

                        if (isOpen) {
                            $directiveScope.modal = $uibModal.open(modalConfig);
                            $directiveScope.modal.result.catch(function (callback) {
                                if (callback == "escape key press") {
                                    $directiveScope.config.isOpen = false;
                                }
                            });
                        }
                        else {
                            $directiveScope.modal.close();
                        }
                    });
                }]
            }
        }
    ]);