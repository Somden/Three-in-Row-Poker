﻿'use strict';

angular
    .module("LeadApp")
    .component('paymentOverviewViewsection', {
        templateUrl: '/app/components/viewsections/payment-overview-viewsection.component.html?cache=' + globalConfig.htmlCacheToken,
        bindings: {
            contractRevision: '=',
        },
        controllerAs: "vm",
        controller:
            ['$translate', 'resourceFactory', 'contractValidator', 'contractRevisionValidator', 'resourceFactoryHelpers',
            function ($translate, resourceFactory, contractValidator, contractRevisionValidator, resourceFactoryHelpers) {
                var vm = this;
                vm.resultsMightBeDeprecated = false;

                vm.loadDataByContractRevision = function (contractRevision) {
                    vm.isContractValid = contractValidator.validate(vm.contractRevision.Contract).isValid;
                    vm.isContractValid &= contractRevisionValidator.validate(vm.contractRevision).isValid;
                    if (!vm.isContractValid) return;

                    vm.resultData = true;
                    vm.isLoading = true;
                    vm.totalRow = null;

                    var contract = JSON.parse(resourceFactoryHelpers.transformContractRequest(decycle(contractRevision.Contract), true)); //notwork

                    var req = {
                        contract: contract,
                        revisionNumber: contractRevision.Revision,
                    };

                    resourceFactory
                        .paymentOverview() // -> \LeadWeb\Controllers\ApiControllers\Calculations\PaymentOverviewController.cs
                        .loadWithModel(req)
                        .$promise
                        .then(function (response) {
                            vm.isLoading = false;
                            vm.resultsMightBeDeprecated = false;

                            vm.resultData = response.Payload;
                            if (response.Payload) {
                                vm.totalRow = calculateTotalRow(response.Payload.PaymentDateResults || []);
                            }
                        })
                        .catch(function (response) { console.warn("[paymentOverview] loadData() - Error"); })
                        .finally(function () { console.log("[paymentOverview] loadData() - Finally"); });
                };

                var calculateTotalRow = function (data) {
                    return {
                        NominalPayment: data.reduce(function (sum, item) { return sum + item.NominalPayment; }, 0),
                        PresentValue: data.reduce(function (sum, item) { return sum + item.PresentValue; }, 0)
                    };
                };

                (function initializeWatches() {
                    var previousValues = {};

                    vm.$doCheck = function () {
                        if (previousValues.previousContractRevision != vm.contractRevision) {
                            vm.loadDataByContractRevision(vm.contractRevision);
                            previousValues.previousContractRevision = vm.contractRevision;
                        }
                    };
                })();
            }]
    });