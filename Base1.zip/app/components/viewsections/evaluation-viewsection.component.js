'use strict';

angular
    .module("LeadApp")
    .component('evaluationViewsection', {
        templateUrl: '/app/components/viewsections/evaluation-viewsection.component.html?cache=' + globalConfig.htmlCacheToken,
        bindings: {
            contractRevision: '=',
        },
        controllerAs: "vm",
        controller: [
            "$rootScope", "$timeout", "resourceFactory", "resourceFactoryHelpers", "messageFactory", "kendoDataSourceBuilder",
            function ($rootScope, $timeout, resourceFactory, resourceFactoryHelpers, messageFactory, kendoDataSourceBuilder) {
                var vm = this;

                vm.showPeriodEvaluation = false;
                vm.evaluationConfig = {};
                vm.currencyCode = "TBD";

                vm.accountingStandardDataSource = kendoDataSourceBuilder("/odata/PermittedValues")
                    .whereEquals("EnumType", "AccountingStandardType");

                vm.evaluationConfig.accountingStandard = {
                    EnumType: "AccountingStandardType",
                    Value: "IFRS",
                };

                vm.showTogglePeriodEvaluation = function () {
                    try {
                        return vm.contractRevision.RightOfUseAsset.Assets.length > 0 || vm.contractRevision.Contract.ContractType.Value === "Lessor";
                    } catch (ex) {
                        return false;
                    }
                }

                vm.toggleShowPeriodEvaluation = function () {
                    vm.showPeriodEvaluation = !vm.showPeriodEvaluation;
                    vm.showResults = false;
                };

                vm.loadDataByContractRevision = function (contractRevision) {
                    
                    if (vm.showPeriodEvaluation && (!vm.evaluationConfig.startDate || !vm.evaluationConfig.endDate || !vm.evaluationConfig.accountingStandard || !vm.evaluationConfig.assetComponent)) {
                        messageFactory.showErrorMessage("EVALUATION_MISSING_FIELDS_HEADER", "EVALUATION_MISSING_FIELDS_TEXT");
                    }
                    else if (!vm.showPeriodEvaluation && (!vm.evaluationConfig.date || !vm.evaluationConfig.accountingStandard || (vm.contractRevision.Contract.ContractType.Value != 'Lessor' && !vm.evaluationConfig.assetComponent))) {
                        messageFactory.showErrorMessage("EVALUATION_MISSING_FIELDS_HEADER", "EVALUATION_MISSING_FIELDS_TEXT");
                    }
                    else {
                        vm.isLoading = true;
                        vm.resultData = null;
                        vm.loadingEvaluationResults = true;

                        var request = getRequestObject(contractRevision);

                        resourceFactory
                            .evaluationOverview() // -> \LeadWeb\Controllers\ApiControllers\Calculations\ContractEvaluationController.cs
                            .loadWithModel(request)
                            .$promise
                            .then(function (response) {
                                vm.isLoading = false;
                                vm.resultsMightBeDeprecated = false;

                                vm.results =
                                {
                                    liabilityDemand: response.CalcLiabilityDemand,
                                    assetValue: response.CalcAssetValue,
                                    remainingPayments: response.CalcRemainingPayments,
                                    interestShareSum: response.CalcInterestShareInPeriod,
                                    deprecation: response.CalcDeprecation,
                                    paymentsSumNominal: response.CalcPaymentsSumNominal
                                };

                                vm.loadingEvaluationResults = false;
                                vm.showResults = true;
                            })
                            .catch(function (response) {
                                console.warn("[evaluationOverview] loadDataByContractRevision() - Error", response);
                                vm.loadingEvaluationResults = false;
                                vm.showResults = true;
                            })
                            .finally(function () { console.log("[evaluationOverview] loadDataByContractRevision() - Finally"); });
                    }
                }

                function getRequestObject(contractRevision) {
                    var contractEvaluationData = new Object();
                    contractEvaluationData.contract = JSON.parse(resourceFactoryHelpers.transformContractRequest((vm.contractRevision == null ? null : decycle(vm.contractRevision.Contract)), true));
                    //contractEvaluationData.contract.InterestRate = contractRevision.InterestRateInternal;

                    if (vm.showPeriodEvaluation) {
                        contractEvaluationData.evaluationPeriodStart = (vm.evaluationConfig.startDate == null ? null : vm.evaluationConfig.startDate.getFullYear() + "-" + (vm.evaluationConfig.startDate.getMonth() + 1) + "-" + vm.evaluationConfig.startDate.getDate());
                        contractEvaluationData.evaluationPeriodEnd = (vm.evaluationConfig.endDate == null ? null : vm.evaluationConfig.endDate.getFullYear() + "-" + (vm.evaluationConfig.endDate.getMonth() + 1) + "-" + vm.evaluationConfig.endDate.getDate());
                    }
                    else {
                        contractEvaluationData.evaluationPeriodStart = (vm.evaluationConfig.date == null ? null : vm.evaluationConfig.date.getFullYear() + "-" + (vm.evaluationConfig.date.getMonth() + 1) + "-" + vm.evaluationConfig.date.getDate());
                        contractEvaluationData.evaluationPeriodEnd = null;
                    }

                    contractEvaluationData.accountingStandard = (vm.evaluationConfig.accountingStandard == null ? null : vm.evaluationConfig.accountingStandard.Value);
                    contractEvaluationData.contractComponentId = (vm.evaluationConfig.assetComponent == null ? 0 : vm.evaluationConfig.assetComponent.Id);


                    return contractEvaluationData;
                }

                vm.loadEvaluationResults = function () {
                    vm.loadDataByContractRevision(vm.contractRevision);
                };

                vm._onContractRevisionChanged = function () {
                    // Create asset component list (without saving the current contract)
                    if (vm.contractRevision != null && vm.contractRevision.RightOfUseAsset != null && vm.contractRevision.RightOfUseAsset.Assets != null) {
                        var assets = vm.contractRevision.RightOfUseAsset.Assets;
                        var compList = [];
                        for (var i = 0; i < assets.length; i++) {
                            if (assets[i].AssetComponents != null) {
                                for (var x = 0; x < assets[i].AssetComponents.length; x++) {
                                    compList.push({ Id: assets[i].AssetComponents[x].ContractComponentId, Name: assets[i].AssetComponents[x].Name });
                                }
                            }
                        }

                        vm.assetComponentList = compList;

                        if (vm.assetComponentList.length == 1) {
                            vm.evaluationConfig.assetComponent = vm.assetComponentList[0];
                        }
                    }

                    vm.showResults = false;
                };

                (function initializeWatches() {
                    var previousValues = {};

                    vm.$doCheck = function () {
                        if (previousValues.previousContractRevision != vm.contractRevision) {
                            previousValues.previousContractRevision = vm.contractRevision;

                            vm._onContractRevisionChanged();
                        }
                    };
                })();
            }
        ]
    });