﻿'use strict';

angular
    .module("LeadApp")
    .component('liabilityOverviewViewsection', {
        templateUrl: '/app/components/viewsections/liability-overview-viewsection.component.html?cache=' + globalConfig.htmlCacheToken,
        bindings: {
            contractRevision: '=',
        },
        controllerAs: "vm",
        controller:
            ["$translate", "contractLeasingPeriodValidator", "extensionLeasingPeriodValidator", "resourceFactory", "resourceFactoryHelpers",
            function ($translate, contractLeasingPeriodValidator, extensionLeasingPeriodValidator, resourceFactory, resourceFactoryHelpers) {
                var vm = this;
                vm.showPaymentValues = false;
                vm.resultsMightBeDeprecated = false;

                vm.show = function () {
                    try {
                        return vm.contractRevision.RightOfUseAsset.Assets.length > 0 || vm.contractRevision.Contract.ContractType.Value === "Lessor";
                    } catch (ex) {
                        return false;
                    }
                }

                vm.loadDataByContractRevision = function (contractRevision) {
                    try {
                        vm.isLoading = true;
                        vm.resultData = null;
                        vm.totalRow = null;

                        // Prepare contract
                        var contract = decycle(contractRevision.Contract);
                        contract = JSON.parse(resourceFactoryHelpers.transformContractRequest(contract, true));
                        retrocycle(contract);
                        if (contract.CurrentContractRevision.Id == contract.DisplayedContractRevision.Id || !contract.DisplayedContractRevision.Id) {
                            contract.DisplayedContractRevision = contract.CurrentContractRevision;
                        }

                        var request = getRequestObject(contract);
                        request = decycle(request);

                        resourceFactory
                            .liabilityOverview() // -> \LeadWeb\Controllers\ApiControllers\Calculations\ContractLiabilityController.cs
                            .loadWithModel(request)
                            .$promise
                            .then(function (response) {
                                vm.isLoading = false;
                                vm.resultsMightBeDeprecated = false;

                                vm.resultData = response.Payload;
                                vm.totalRow = calculateLiabilityValueTotalRow(response.Payload || []);
                            })
                            .catch(function (response) { console.warn("[liabilityOverview] loadDataByContractRevision() - Error", response); })
                            .finally(function () { console.log("[liabilityOverview] loadDataByContractRevision() - Finally"); });
                    } catch (e) {
                        console.warn("[liabilityOverview] loadDataByContractRevision() - Error", e);
                        vm.isLoading = false;
                    }
                }

                function getRequestObject(contract) {
                    var request = [];
                    var contractRevision = contract.DisplayedContractRevision;// decycle(contract.DisplayedContractRevision);
                    var leasingPeriods = leasingPeriodHelpers.getAllLeasingPeriodsByContract(contract);
                    leasingPeriods = leasingPeriods.filter(function (lp) { lp.ContractRevision = contract.DisplayedContractRevision; return lp.IsExpectedExecuted; });
                    leasingPeriods = leasingPeriods.filter(function (lp) { lp.ContractRevision = contract.DisplayedContractRevision; lp.ContractRevision.Contract = contract; return contractRevision.ContractLeasingPeriod == lp ? contractLeasingPeriodValidator.validate(lp).isValid : extensionLeasingPeriodValidator.validate(lp).isValid });
                    leasingPeriods.forEach(function (leasingPeriod) {
                        var contractLeasingPeriod = {
                            leasingPeriod: leasingPeriod,
                            leasingPeriodStartDate: leasingPeriodHelpers.getStartDateForLeasingPeriod(leasingPeriod, contractRevision.Contract),
                            type: contractRevision.ContractLeasingPeriod == leasingPeriod ? "LEASING_PERIOD_CONTRACT_LEASING_PERIOD" : "LEASING_PERIOD_CONTRACT_EXTENSION_PERIOD",
                            interestRate: contractRevision.UseInterestRate ? contractRevision.InterestRate : contractRevision.IncrementalBorrowingRate,
                        };
                        request.push(contractLeasingPeriod);
                    });

                    return request;
                }

                var calculateLiabilityValueTotalRow = function (data) {
                    return {
                        StartDate: (data[0] || {}).StartDate,
                        EndDate: (data[data.length - 1] || {}).EndDate,
                        Type: $translate.instant("TABLE_ROWTYPE_TOTAL"),
                        DurationDays: data.reduce(function (sum, item) { return sum + item.DurationDays; }, 0),

                        NominalValue: data.reduce(function (sum, item) { return sum + item.NominalValue; }, 0),
                        NominalValuePaymentRule: data.reduce(function (sum, item) { return sum + item.NominalValuePaymentRule; }, 0),
                        NominalValuePaymentRuleRate: data.reduce(function (sum, item) { return sum + item.NominalValuePaymentRuleRate; }, 0),
                        NominalValueInSubstancePayment: data.reduce(function (sum, item) { return sum + item.NominalValueInSubstancePayment; }, 0),
                        NominalValueManualPayment: data.reduce(function (sum, item) { return sum + item.NominalValueManualPayment; }, 0),
                        NominalValueExtensionOption: data.reduce(function (sum, item) { return sum + item.NominalValueExtensionOption; }, 0),
                        NominalValueTerminationOption: data.reduce(function (sum, item) { return sum + item.NominalValueTerminationOption; }, 0),

                        PresentValue: data.reduce(function (sum, item) { return sum + item.PresentValue; }, 0),
                        PresentValuePaymentRule: data.reduce(function (sum, item) { return sum + item.PresentValuePaymentRule; }, 0),
                        PresentValuePaymentRuleRate: data.reduce(function (sum, item) { return sum + item.PresentValuePaymentRuleRate; }, 0),
                        PresentValueInSubstancePayment: data.reduce(function (sum, item) { return sum + item.PresentValueInSubstancePayment; }, 0),
                        PresentValueManualPayment: data.reduce(function (sum, item) { return sum + item.PresentValueManualPayment; }, 0),
                        PresentValueExtensionOption: data.reduce(function (sum, item) { return sum + item.PresentValueExtensionOption; }, 0),
                        PresentValueTerminationOption: data.reduce(function (sum, item) { return sum + item.PresentValueTerminationOption; }, 0)
                    };
                }

                var _onContractRevisionChanged = function () {
                    if (vm.contractRevision == null) return;
                    vm.loadDataByContractRevision(vm.contractRevision);
                };

                //// TODO: Listen to all changes that affect the parameters of the
                //vm.$watch('contractRevision.ContractLeasingPeriod.PaymentRules', function () { vm.resultsMightBeDeprecated = true; });

                (function initializeWatches() {
                    var previousValues = {
                    };

                    vm.$doCheck = function () {
                        if (previousValues.previousContractRevision != vm.contractRevision) {
                            _onContractRevisionChanged();
                            previousValues.previousContractRevision = vm.contractRevision;
                        }

                        if (vm.contractRevision != null) {
                            if (previousValues.interestRate != vm.contractRevision.InterestRate) {
                                vm.resultsMightBeDeprecated = true;
                                previousValues.interestRate = vm.contractRevision.InterestRate;
                            }

                            if (previousValues.extensionLeasingPeriods != vm.contractRevision.ExtensionLeasingPeriods) {
                                vm.resultsMightBeDeprecated = true;
                                previousValues.extensionLeasingPeriods = vm.contractRevision.ExtensionLeasingPeriods;
                            }

                            var newCommencementDate = vm.contractRevision.Contract == null ? null : vm.contractRevision.Contract.CommencementDate;
                            if (previousValues.commencementDate != newCommencementDate) {
                                vm.resultsMightBeDeprecated = true;
                                previousValues.commencementDate = newCommencementDate;
                            }

                            var newContractLeasingPeriodEndDate = vm.contractRevision.ContractLeasingPeriod.EndDate == null ? null : vm.contractRevision.ContractLeasingPeriod.EndDate;
                            if (previousValues.contractLeasingPeriodEndDate != newContractLeasingPeriodEndDate) {
                                vm.resultsMightBeDeprecated = true;
                                previousValues.contractLeasingPeriodEndDate = newContractLeasingPeriodEndDate;
                            }

                            var newContractLeasingPeriodPaymentRules = vm.contractRevision.ContractLeasingPeriod.PaymentRules == null ? null : vm.contractRevision.ContractLeasingPeriod.PaymentRules;
                            if (previousValues.contractLeasingPeriodPaymentRules != newContractLeasingPeriodPaymentRules) {
                                vm.resultsMightBeDeprecated = true;
                                previousValues.contractLeasingPeriodPaymentRules = newContractLeasingPeriodPaymentRules;
                            }
                        }
                    };
                })();

                vm.togglePresentAndPaymentValues = function () {
                    vm.showPaymentValues = !vm.showPaymentValues;
                };
            }]
    });