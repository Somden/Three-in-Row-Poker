﻿"use strict";

angular
    .module("LeadApp")
    .component("sectionExtension", {
        bindings: {
            entity: "=",
            validator: "=",
            isFormReadonly: "=",
            isHelpVisible: "=",
            basePath: "@",
            view: "@"
        },
        controllerAs: "vm",
        controller: [
            "$scope", "$compile", "$http", "$element", "$injector",
            function ($scope, $compile, $http, $element, $injector) {
                var vm = this;

                // Check whether sectionExtensionDefinitions exist and if not, component init can be cancelled
                if (!$injector.has("sectionExtensionDefinitions")) return;
                var sectionExtensionDefinitions = $injector.get("sectionExtensionDefinitions");

                vm.loadComponent = function (componentName, $element) {
                    var tagName = helpers.camelToHtml(componentName);
                    var element = document.createElement(tagName);
                    element.setAttribute("entity", "vm.entity");
                    element.setAttribute("validator", "vm.validator");
                    element.setAttribute("is-form-readonly", "vm.isFormReadonly");
                    element.setAttribute("is-help-visible", "vm.isHelpVisible");
                    element.setAttribute("base-path", vm.basePath);
                    var compiledElement = $compile(element)($scope);
                    $element.append(compiledElement);
                };

                function createLoadElement() {
                    var spinner = document.createElement("i");
                    spinner.classList.add("fa");
                    spinner.classList.add("fa-spinner");
                    spinner.classList.add("fa-spin");

                    var loadText = document.createElement("span");
                    loadText.innerText = "{{ 'LOADING_EXTENSION' | translate }}";

                    var loadElement = document.createElement("div");
                    loadElement.classList.add("text-center");
                    loadElement.classList.add("loadingElement");
                    loadElement.appendChild(spinner);
                    loadElement.appendChild(loadText);

                    return loadElement;
                }

                function createDescriptionElement(viewKey) {
                    var descriptionTitle = document.createElement("h4");
                    descriptionTitle.innerText = "You can add an extension here!";

                    var descriptionLabel = document.createElement("small");
                    descriptionLabel.innerText = "Use the following view-key in the section-extension-definitions.value.js, for adding your extension here";

                    var descriptionInput = document.createElement("input");
                    descriptionInput.classList.add("form-control");
                    descriptionInput.type = "text";
                    descriptionInput.value = viewKey;

                    var descriptionElement = document.createElement("div");
                    descriptionElement.classList.add("extension-description");
                    descriptionElement.appendChild(descriptionTitle);
                    descriptionElement.appendChild(descriptionLabel);
                    descriptionElement.appendChild(descriptionInput);

                    return descriptionElement;
                }

                this.$onInit = function () {
                    var descriptionElement = createDescriptionElement(vm.view);
                    $element.append(descriptionElement);

                    // Look for all components that should be loaded
                    for (var f in sectionExtensionDefinitions) {
                        var component = sectionExtensionDefinitions[f];

                        if (component.view == vm.view) {
                            vm.loadComponent(component.componentName, $element);
                        }
                    }
                };
            }
        ]
    });