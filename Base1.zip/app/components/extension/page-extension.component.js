﻿"use strict";

// Will contain all extension pages
angular
    .module("LeadApp")
    .component("pageExtension", {
        bindings: {
            basePath: "@",
            entityId: "@",
            pageToShow: "@"
        },
        controller: [
            "$scope", "$compile", "$http", "$element",
            function ($scope, $compile, $http, $element) {
                $scope.loadComponent = function (directiveName, $element) {
                    var tagName = helpers.camelToHtml(directiveName);
                    var element = document.createElement(tagName);
                    element.setAttribute("contract", "contract");
                    element.setAttribute("entity-id", $scope.$ctrl.entityId);
                    element.setAttribute("base-path", $scope.$ctrl.basePath);
                    var compiledHtml = $compile(element)($scope);
                    $element.append(compiledHtml);
                };

                this.$onInit = function () {
                    $scope.loadComponent($scope.$ctrl.pageToShow, $element);
                };
            }
        ]
    });