'use strict';

angular
    .module("LeadApp")
    .component('leasingPeriods', {
        templateUrl: '/app/components/tabs/leasing-periods.component.html?cache=' + globalConfig.htmlCacheToken,
        bindings: {
            contract: '=',
            isHelpVisible: "=",
            isFormReadonly: "=",
            isReassessment: "=",
            isModification: "=",
            isInitialRevision: "=",
            isTemplate: "=",
            isPending: "="
        },
        controllerAs: "vm",
        controller: function ($scope, $timeout) {
            var vm = this;
            vm.selectedLeasingPeriod = null;
            vm.helpers = helpers;

            vm.openLeasingPeriod = function (leasingPeriod) {
                if (vm.selectedLeasingPeriod != null) {
                    // If unlimited, ContractLeasingPeriod should not be closable
                    if (!vm.contract.IsLimited) return;

                    vm.selectedLeasingPeriod = null;
                    return;
                }

                vm.selectedLeasingPeriod = leasingPeriod;
                
                vm.selectedLeasingPeriod.StartDate = leasingPeriodHelpers.getStartDateForLeasingPeriod(leasingPeriod, vm.contract);
            };

            vm.isEndDateChangeble = function () {
                if (vm.contract == null) return false;
                if (vm.isFormReadonly()) return false;

                if (vm.isInitialRevision()) return true;

                // See #597 for the modify-rules
                if (vm.isModification()) return true;
                if (vm.isReassessment() && vm.contract.IsLimited) return false;
                if (vm.isReassessment() && !vm.contract.IsLimited) return true;

                return false;
            };

            vm.isContractLeasingPeriod = function (leasingPeriod) {
                return leasingPeriod != null && leasingPeriod.Id == vm.contract.DisplayedContractRevision.ContractLeasingPeriod.Id;
            };

            vm.addNewLeasingPeriod = function () {
                vm.selectedLeasingPeriod = {
                    Id: -helpers.randomId(),
                    IsRelative: false,
                    PaymentRules:[]
                };
                
                vm.selectedLeasingPeriod.ViewModelNewId = vm.selectedLeasingPeriod.Id;

                vm.selectedLeasingPeriod.StartDate = leasingPeriodHelpers.getStartDateForLeasingPeriod(vm.selectedLeasingPeriod, vm.contract);

                if (vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods == null) {
                    vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods = [];
                }

                vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods.push(vm.selectedLeasingPeriod);
            };

            vm.removeLeasingPeriod = function (leasingPeriodToRemove) {
                for (var f in vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods) {
                    var leasingPeriod = vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods[f];
                    if (leasingPeriod.Id == leasingPeriodToRemove.Id) {
                        vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods.splice(f, 1);
                        break;
                    }
                }

                vm.selectedLeasingPeriod = null;
            };

            // Determines whether a given leasing period is the contract leasing period or not
            vm.isSelectedLeasingPeriod = function (leasingPeriod) {
                if (vm.selectedLeasingPeriod == null) return false;
                if (leasingPeriod == null) return false;

                return vm.selectedLeasingPeriod.Id == leasingPeriod.Id;
            };

            // Depending on whether given leasing period has a termination option or not, it removes it or adds one
            vm.toggleTerminationOptionInLeasingPeriod = function (leasingPeriod) {
                if (leasingPeriod.TerminationOption == null) {
                    leasingPeriod.TerminationOption = {
                        Id: -1
                    };
                }
                else {
                    leasingPeriod.TerminationOption = null;
                }
            };

            // Removes a paymentrule from given leasingperiod
            vm.removeLeasingPeriodPaymentRuleByIndex = function (leasingPeriod, paymentRuleIndex) {
                leasingPeriod.PaymentRules.splice(paymentRuleIndex, 1);
            };

            vm.openLeasingPeriodPaymentRuleModal = function (paymentRuleToEdit) {
                vm.leasingPeriodPaymentRuleModal = {
                    isOpen: true,
                    paymentRule: paymentRuleToEdit,
                    contract: vm.contract,
                    callback: function (paymentRule, isEdit) {
                        if (isEdit) {
                            // Replace
                            for (var f in vm.selectedLeasingPeriod.PaymentRules) {
                                if (vm.selectedLeasingPeriod.PaymentRules[f].Id == paymentRule.Id) {
                                    vm.selectedLeasingPeriod.PaymentRules[f] = paymentRule;
                                }
                            }
                        }
                        else {
                            // Add
                            vm.selectedLeasingPeriod.PaymentRules = vm.selectedLeasingPeriod.PaymentRules || [];
                            vm.selectedLeasingPeriod.PaymentRules.push(paymentRule);
                        }
                    }
                };
            };

            vm.determineEndDateByStartDateAndDuration = function (startDate, duration) {
                var endDate = new Date(startDate);
                var month = endDate.getMonth();
                endDate.setMonth(month + duration);

                endDate.setDate(endDate.getDate() - 1);

                return endDate;
            };

            vm.isSelectedLeasingPeriodEmpty = function () {
                return vm.selectedLeasingPeriod == null || vm.selectedLeasingPeriod.Id == null;
            };

            // A change in end date may changes the duration
            vm._onLeasingPeriodEndDateChanged = function () {
                if (vm.contract == null || vm.contract.DisplayedContractRevision == null) return;
                if (validationHelper.dateIsEmpty(vm.contract.CommencementDate)) return;

                var allLeasingPeriods = leasingPeriodHelpers.getAllLeasingPeriodsByContract(vm.contract);
                for (var f in allLeasingPeriods) {
                    var leasingPeriod = allLeasingPeriods[f];

                    if (leasingPeriod == null) continue;

                    var startDate = new Date(leasingPeriodHelpers.getStartDateForLeasingPeriod(leasingPeriod, vm.contract));
                    var endDate = new Date(leasingPeriod.EndDate);

                    // If not relative (or duration not defined yet), then adjust Duration
                    if (!leasingPeriod.IsRelative || leasingPeriod.Duration == null) {
                        if (!validationHelper.dateIsEmpty(startDate) && !validationHelper.dateIsEmpty(endDate)) {
                            var diffYears = endDate.getFullYear() - startDate.getFullYear();
                            var diffMonths = endDate.getMonth() - startDate.getMonth();
                            var diffDay = Math.abs(endDate.getDate() - startDate.getDate());

                            var deltaMonths = diffYears * 12 + diffMonths + Math.round(diffDay / 30.0);

                            leasingPeriod.Duration = deltaMonths;
                        }
                    }
                        // If relative, then adjust EndDate
                    else {
                        if (!validationHelper.dateIsEmpty(startDate)) {
                            var deltaMonths = leasingPeriod.Duration * 1;
                            if (deltaMonths <= 0) continue;

                            leasingPeriod.EndDate = vm.determineEndDateByStartDateAndDuration(startDate, deltaMonths);
                        }
                    }

                    // Update termination option end date (absolute or relative)
                    if (leasingPeriod.TerminationOption != null) {
                        if (leasingPeriod.TerminationOption.IsRelative) {
                            vm._onContractLeasingPeriodTerminationOptionDurationChanged(leasingPeriod.TerminationOption.Duration, leasingPeriod.TerminationOption.Duration);
                        }
                        else {
                            vm._onLeasingPeriodTerminationOptionEndDateChanged(leasingPeriod.TerminationOption.EndDate, leasingPeriod.TerminationOption.EndDate);
                        }
                    }
                }

                if (vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods != null) {
                    vm.contract.DisplayedContractRevision.ExtensionLeasingPeriods.sort(function (a, b) { return a.EndDate < b.EndDate; });
                }
            };

            // A change in duration may changes the end date
            vm._onLeasingPeriodDurationChanged = function () {
                if (vm.contract == null || vm.contract.DisplayedContractRevision == null) return;
                if (validationHelper.dateIsEmpty(vm.contract.CommencementDate)) return;

                var allLeasingPeriods = leasingPeriodHelpers.getAllLeasingPeriodsByContract(vm.contract);
                for (var f in allLeasingPeriods) {
                    var leasingPeriod = allLeasingPeriods[f];

                    if (leasingPeriod == null) continue;
                    if (leasingPeriod.Duration == null) continue;
                    if (!leasingPeriod.IsRelative) continue;

                    var startDate = leasingPeriodHelpers.getStartDateForLeasingPeriod(leasingPeriod, vm.contract);
                    if (validationHelper.dateIsEmpty(startDate)) continue;

                    var deltaMonths = leasingPeriod.Duration * 1;
                    if (deltaMonths <= 0) continue;

                    var endDate = vm.determineEndDateByStartDateAndDuration(startDate, deltaMonths);
                    leasingPeriod.EndDate = endDate;
                }
            };

            // A change in termination end date may changes the termination duration
            vm._onLeasingPeriodTerminationOptionEndDateChanged = function () {
                if (vm.contract == null || vm.contract.DisplayedContractRevision == null) return;
                if (validationHelper.dateIsEmpty(vm.contract.CommencementDate)) return;

                var allLeasingPeriods = leasingPeriodHelpers.getAllLeasingPeriodsByContract(vm.contract);
                for (var f in allLeasingPeriods) {
                    var leasingPeriod = allLeasingPeriods[f];

                    if (leasingPeriod == null) continue;
                    if (leasingPeriod.TerminationOption == null) continue;

                    var leasingEndDate = new Date(leasingPeriod.EndDate);
                    var terminationDate = new Date(leasingPeriod.TerminationOption.EndDate);

                    if (!validationHelper.dateIsEmpty(leasingEndDate) && !validationHelper.dateIsEmpty(terminationDate)) {
                        var diffYears = leasingEndDate.getFullYear() - terminationDate.getFullYear();
                        var diffMonths = leasingEndDate.getMonth() - terminationDate.getMonth();

                        var deltaMonths = diffYears * 12 + diffMonths;

                        if (deltaMonths < 0) {
                            deltaMonths = null;
                        }

                        leasingPeriod.TerminationOption.Duration = deltaMonths;
                    }
                }
            };

            // A change in termination duration may changes the termination end date
            vm._onContractLeasingPeriodTerminationOptionDurationChanged = function () {
                if (vm.contract == null || vm.contract.DisplayedContractRevision == null) return;
                if (validationHelper.dateIsEmpty(vm.contract.CommencementDate)) return;

                var allLeasingPeriods = leasingPeriodHelpers.getAllLeasingPeriodsByContract(vm.contract);
                for (var f in allLeasingPeriods) {
                    var leasingPeriod = allLeasingPeriods[f];

                    if (leasingPeriod == null) continue;
                    if (leasingPeriod.TerminationOption == null) continue;
                    if (leasingPeriod.TerminationOption.Duration == null) continue;
                    if (!leasingPeriod.TerminationOption.IsRelative) continue;
                    if (validationHelper.dateIsEmpty(leasingPeriod.EndDate)) continue;

                    var deltaMonths = leasingPeriod.TerminationOption.Duration * 1
                    if (deltaMonths <= 0) continue;

                    var endDate = new Date(leasingPeriod.EndDate);
                    var month = endDate.getMonth();
                    endDate.setMonth(month - deltaMonths);
                    leasingPeriod.TerminationOption.EndDate = endDate;
                }
            };

            function _onContractChanged() {
                vm._onLeasingPeriodEndDateChanged();
                vm._onLeasingPeriodDurationChanged();
                vm._onLeasingPeriodTerminationOptionEndDateChanged();
                vm._onContractLeasingPeriodTerminationOptionDurationChanged();

                vm.selectedLeasingPeriod = null;
            };

            // Detect when the display contract revision changesvar previousContract = null;
            function _onDisplayedContractRevisionChanged() {
                vm.selectedLeasingPeriod = null;
            };

            // If contract is unlimited, only contract leasing period is allowed, so select it
            function _onIsLimitedChanged() {
                if (vm.contract == null || vm.contract.DisplayedContractRevision == null) return;

                if (!vm.contract.IsLimited) {
                    vm.selectedLeasingPeriod = vm.contract.DisplayedContractRevision.ContractLeasingPeriod;
                }
            };

            function _onCommencementDateChanged() {
                if (vm.contract == null || vm.contract.DisplayedContractRevision == null) return;
                if (vm.contract.DisplayedContractRevision.ContractLeasingPeriod == null) return;
                if (validationHelper.dateIsEmpty(vm.contract.CommencementDate)) return;

                // Update contract leasing end date (absolute or relative)
                if (vm.contract.DisplayedContractRevision.ContractLeasingPeriod.IsRelative) {
                    vm._onLeasingPeriodDurationChanged(vm.contract.DisplayedContractRevision.ContractLeasingPeriod.Duration, vm.contract.DisplayedContractRevision.ContractLeasingPeriod.Duration);
                }
                else {
                    vm._onLeasingPeriodEndDateChanged(vm.contract.DisplayedContractRevision.ContractLeasingPeriod.EndDate, vm.contract.DisplayedContractRevision.ContractLeasingPeriod.EndDate);
                }
            };

            (function initializeWatches() {
                var previousValues = {};

                // Detect when the contract gets reloaded (by a changing reference) and inform all watches
                vm.$doCheck = function () {
                    var newContract = vm.contract;
                    if (previousValues.previousContract != newContract) {
                        _onContractChanged();
                        previousValues.previousContract = newContract;
                    }

                    var newDisplayedContractRevision = vm.contract == null ? null : vm.contract.DisplayedContractRevision;
                    if (previousValues.contractDisplayedContractRevision != newDisplayedContractRevision) {
                        _onDisplayedContractRevisionChanged();
                        previousValues.contractDisplayedContractRevision = newDisplayedContractRevision;
                    }

                    var newIsLimited = vm.contract == null ? null : vm.contract.IsLimited;
                    if (previousValues.contractIsLimited != newIsLimited) {
                        _onIsLimitedChanged();
                        previousValues.contractIsLimited = newIsLimited;
                    }

                    var newCommencementDate = vm.contract == null ? null : vm.contract.CommencementDate;
                    if (previousValues.contractCommencementDate != newCommencementDate) {
                        _onCommencementDateChanged();
                        previousValues.contractCommencementDate = newCommencementDate;
                    }
                };
            })();
        }
    });