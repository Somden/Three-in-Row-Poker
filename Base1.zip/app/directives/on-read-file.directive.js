﻿'use strict';

angular
    .module("LeadApp")
    .directive('onReadFile', [
        "$parse", "messageFactory",
        function ($parse, messageFactory) {
            return {
                restrict: 'A',
                scope: false,
                link: function (scope, element, attrs) {
                    var fn = $parse(attrs.onReadFile);
                    if (angular.isDefined(attrs.reloadEnabled) && attrs.reloadEnabled == "true") {
                        element.on('input', function (arg) {
                            upload(arg);
                            console.log(arg.target.files[0]);
                        });
                    } else {
                        element.on('change', function (onChangeEvent) {
                            upload(onChangeEvent);
                        });
                    }
                    var upload = function (onChangeEvent) {
                        messageFactory.showSuccessMessage("analyse file...");

                        var reader = new FileReader();
                        reader.onerror = function (onerrorEvent) {
                            messageFactory.showErrorMessage("Error reading file...");
                        };
                        reader.onprogress = function (arg) {
                            //console.log(arg);
                        };
                        reader.onload = function (onLoadEvent) {
                            scope.$apply(function () {
                                fn(scope, { $fileContent: onLoadEvent.target.result });
                            });
                        };

                        reader.readAsText((onChangeEvent.srcElement || onChangeEvent.target).files[0]);
                    };
                }
            };
        }
    ]);