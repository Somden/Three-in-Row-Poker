﻿'use strict';

angular
    .module("LeadApp")
    .directive('copyCellWidthsFrom', [
        "$interval",
        function ($interval) {
            return {
                restrict: 'A',
                scope: {
                    copyCellWidthsFrom: "="
                },
                link: function (scope, item, element) {
                    var adjustCellWidths = function () {
                        var sourceElem = $(scope.copyCellWidthsFrom);

                        var sourceElemWidth = sourceElem.width();
                        if (sourceElemWidth == item.data("lastSourceWidth")) return;
                        item.data("lastSourceWidth", sourceElemWidth);

                        var headerCellWidths = $("tr:first-child td", sourceElem).map(function () {
                            return $(this).width();
                        }).get();


                        $("tr:first-child", item).children().each(function (i, v) {
                            if (headerCellWidths.length <= i) return;

                            $(v).width(headerCellWidths[i]);
                        });
                    };

                    $interval(function () {
                        adjustCellWidths();
                    }, 100);
                }
            }
        }
    ]);