﻿/* Adds a loading overlay to an element with attached kendo-drop-down-list
    To make it work properly, the element also needs to have this:
        k-data-bound="removeLoadingOverlay"
*/

"use strict";

angular
    .module("LeadApp")
    .directive('addLoadingOverlay', function () {
        return function (scope, element, attrs) {
            scope.$watch(attrs.kDataSource, function (value) {
                if (value == null) return;

                var loadingOverlay = $(".md-input-loading-overlay", element.parent());
                if (loadingOverlay.length == 0) {
                    var loadingOverlay = $("<div>")
                        .addClass("md-input-loading-overlay text-center")
                        .appendTo(element.parent());

                    $("<i>")
                        .addClass("fa fa-spinner fa-spin")
                        .appendTo(loadingOverlay);
                }
                else {
                    loadingOverlay.show();
                }
            });

            scope.removeLoadingOverlay = function () {
                $(".md-input-loading-overlay", this.element.parent().parent()).hide();
            }
        };
    });