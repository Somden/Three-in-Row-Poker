﻿'use strict';

angular
    .module("LeadApp")
    .directive('clickOnCtrlEnter', [
        function () {
            return {
                restrict: 'A',
                link: function (item, element) {
                    var $doc = angular.element(document);
                    $doc.on('keydown', function (e, a, key) {
                        if (e.ctrlKey && e.keyCode == 13 && !element[0].disabled) {
                            element.trigger("click");
                        }
                    })
                }
            }
        }
    ]);