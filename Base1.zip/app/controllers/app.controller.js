﻿'use strict';

angular
    .module("LeadApp")
    .controller("AppController", [
        "$scope", "$cookies", "pageFactory", "messageFactory", "$window",
        function ($scope, $cookies, pageFactory, messageFactory, $window) {
            $scope.pageFactory = pageFactory;
            $scope.messageFactory = messageFactory;
            $scope.isSideBarVisible = true;
            $scope.globalConfig = globalConfig;

            var changePasswordLocation = "#!/configuration/changePassword";

            $scope.isSideBarButtonVisible = function () {
                return globalConfig.currentUser.MustChangePassword ? false : true;
            }

            if ($cookies.get("isSideBarVisible") != null) {
                $scope.isSideBarVisible = $cookies.get("isSideBarVisible") == "true";
            }

            $scope.navigateTo = function (path) {
                location.href = "#!" + path;
            }

            $scope.toggleSideBarVisibility = function () {
                $scope.isSideBarVisible = !$scope.isSideBarVisible;
                $cookies.put("isSideBarVisible", $scope.isSideBarVisible);
            }

            $scope.loadingMessages = [];
            $scope.$on("LOADING_MESSAGE_SHOW", function (event, args) {
                $scope.loadingMessages.push({
                    id: args.id,
                    translationkey: args.translationkey
                });
            });

            $scope.$on("LOADING_MESSAGE_HIDE", function (event, loadingId) {
                for (var i = $scope.loadingMessages.length - 1; i >= 0; i--) {
                    if ($scope.loadingMessages[i].id == loadingId) {
                        if(!$scope.$$phase) {
                            $scope.$apply(function () {
                                $scope.loadingMessages.splice(i, 1);
                            });
                        }
                        else {
                            $scope.loadingMessages.splice(i, 1);
                        }
                    }
                }
            });

            // Intercepting URL changes.
            $scope.$on('$locationChangeStart', function (event, next, current) {
                let pos = next.lastIndexOf('#');
                // If the user has to change his password and tries to navigate to another page we prevent that:
                if (globalConfig.currentUser.MustChangePassword
                   && next.substr(pos, changePasswordLocation.length) != changePasswordLocation) {
                    event.preventDefault();
                    $window.location.href = changePasswordLocation;
                }
            });

            if (globalConfig.currentUser.MustChangePassword) {
                $scope.isSideBarVisible = false;
            }

        }
    ]);