﻿// Public
function retrocycle(obj) {
    var catalog = [];
    catalogObject(obj, catalog);
    resolveReferences(obj, catalog);
    removeAllExtendedIdsAndReferences(obj);
}

// Public
function decycle(value, objects) {
    // Keep a reference to each unique object or array
    objects = objects || [];

    // Property name
    var propertyName;

    // The new object or array
    var newObject;

    var _value = value && value.toJSON instanceof Function ? value.toJSON() : value;
    // typeof null === 'object', so go on if this value is really an object but not
    // one of the weird builtin objects.
    if (typeof _value === 'object' && _value !== null) {
        // If the value is an object or array, look to see if we have already
        // encountered it. If so, return a $ref object. This is a hard way,
        // linear search that will get slower as the number of unique objects grows.
        for (var i = 0; i < objects.length; i += 1) {
            if (objects[i] === _value && _value.$id != null) {
                return { $ref: "" + _value.$id };
            }
        }

        // Otherwise, accumulate the unique 
        objects.push(_value);

        // If it is an array, replicate the array
        if (Object.prototype.toString.apply(_value) === '[object Array]') {
            newObject = [];
            for (var i = 0; i < _value.length; i += 1) {
                newObject[i] = decycle(_value[i], objects);
            }
        }
        // If it is an object, replicate the object.
        else {
            _value.$id = "" + objects.length;

            newObject = {
                $id: "" + _value.$id
            };
            for (propertyName in _value) {
                if (Object.prototype.hasOwnProperty.call(_value, propertyName)) {
                    newObject[propertyName] = decycle(_value[propertyName], objects);
                }
            }
        }

        return newObject;
    }

    return _value;
}

function removeAllExtendedIdsAndReferences(obj, processedObjects) {
    processedObjects = processedObjects || [];

    if (processedObjects.indexOf(obj) != -1) return;
    processedObjects.push(obj);

    var i;
    if (obj && typeof obj === 'object') {
        if (typeof obj.$id === 'string') {
            delete obj.$id;
        }
        if (typeof obj.$ref === 'string') {
            delete obj.$ref;
        }

        if (Object.prototype.toString.apply(obj) === '[object Array]') {
            for (i = 0; i < obj.length; i += 1) {
                removeAllExtendedIdsAndReferences(obj[i], processedObjects);
            }
        } else {
            for (name in obj) {
                if (typeof obj[name] === 'object') {
                    removeAllExtendedIdsAndReferences(obj[name], processedObjects);
                }
            }
        }
    }
}

function catalogObject(obj, catalog) {
    var i;
    if (obj && typeof obj === 'object') {
        var id = obj.$id;
        if (typeof id === 'string') {
            catalog[id] = obj;
        }
        if (Object.prototype.toString.apply(obj) === '[object Array]') {
            for (i = 0; i < obj.length; i += 1) {
                catalogObject(obj[i], catalog);
            }
        } else {
            for (name in obj) {
                if (typeof obj[name] === 'object') {
                    catalogObject(obj[name], catalog);
                }
            }
        }
    }
}

function resolveReferences(obj, catalog) {
    var i, item, name, id;
    if (obj && typeof obj === 'object') {
        if (Object.prototype.toString.apply(obj) === '[object Array]') {
            for (i = 0; i < obj.length; i += 1) {
                item = obj[i];
                if (item && typeof item === 'object') {
                    id = item.$ref;
                    if (typeof id === 'string') {
                        obj[i] = catalog[id];
                    } else {
                        resolveReferences(item, catalog);
                    }
                }
            }
        } else {
            for (name in obj) {
                if (typeof obj[name] === 'object') {
                    item = obj[name];
                    if (item) {
                        id = item.$ref;
                        if (typeof id === 'string') {
                            obj[name] = catalog[id];
                        } else {
                            resolveReferences(item, catalog);
                        }
                    }
                }
            }
        }
    }
}