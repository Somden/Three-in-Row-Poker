﻿'use strict';

var helpers = {
    defaultDateFormat: "yyyy-MM-dd",

    randomId: function () {
        return Math.round(Math.random() * Math.pow(2, 16));
    },
    isList: function (obj) {
        return Object.prototype.toString.call(obj) === "[object Array]";
    },
    isNumber: function (n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    },
    numericIsChanged: function(newValue, oldValue) {
        var delta = oldValue - newValue;
        delta = Math.abs(delta);
        if (delta >= 0 && delta <= 0.000001) {
            return false;
        }
        return true;
    },
    getNumericValue: function (object) {
        if (object == null) return 0;

        if (typeof (object) == "string") {
            object = object.replace(",", ".");
        }

        var result = object * 1.0;
        return isNaN(result) ? 0 : result;
    },
    numberToCultureString: function (object, $rootScope, showThousandsSeparator, afterCommaDigits) {
        if (helpers.isNumber(object)) {
            object = helpers.addNumberSeparators(object, $rootScope.languageSettings.commaSeparator, showThousandsSeparator ? $rootScope.languageSettings.thousandsSeparator : null, afterCommaDigits);
        }

        return object;
    },
    addNumberSeparators: function (nStr, commaSeparator, thousandsSeparator, afterCommaDigits) {
        commaSeparator = commaSeparator || ".";
        afterCommaDigits = afterCommaDigits || 2;

        var afterCommaDigitsString = "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

        if (typeof (nStr) == "number")
        {
            nStr = nStr.toStringESafe();
        }

        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? commaSeparator + (x[1] + afterCommaDigitsString).substr(0, afterCommaDigits) : '';

        if (thousandsSeparator != null) {
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1)) {
                x1 = x1.replace(rgx, '$1' + thousandsSeparator + '$2');
            }
        }

        return x1 + x2;
    },
    objectAssign: function (target, varArgs) { // .length of function is 2
        if (target == null) { // TypeError if undefined or null
            throw new TypeError('Cannot convert undefined or null to object');
        }

        var to = Object(target);

        for (var index = 1; index < arguments.length; index++) {
            var nextSource = arguments[index];

            if (nextSource != null) { // Skip over if undefined or null
                for (var nextKey in nextSource) {
                    // Avoid bugs when hasOwnProperty is shadowed
                    if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                        to[nextKey] = nextSource[nextKey];
                    }
                }
            }
        }
    },
    camelToHtml: function (camelCase) {
        var re = /[A-Z]/g;

        return camelCase.replace(re, function (match, index, original) {
            return "-" + match.toLowerCase();
        });
    }
};