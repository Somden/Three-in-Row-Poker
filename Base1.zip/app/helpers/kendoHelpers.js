var buildKendoHelpers = function ($rootScope) {
    return {
        // Returns a given template from the DOM by a given elementId
        getKendoTemplate: function (templateId) {
            return $(templateId).html();
        },

        kendoDatePickerOptions: {
            format: $rootScope.dateFormat
        },
        kendoMonthYearPickerOptions: {
            format: $rootScope.dateMonthYearFormat,
            start: "year",
            depth: "year",
            dateInput: true
        },
        kendoYearPickerOptions: {
            format: "yyyy",
            start: "decade",
            depth: "decade",
            dateInput: true
        }
    };
};