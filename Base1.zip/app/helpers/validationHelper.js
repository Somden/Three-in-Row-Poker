﻿var validationHelper = {
	allowStringRegEx: "[^'<>*]+$",
	minDate: new Date("0001-01-01T00:00:00Z"),
	minDateString: "0001-01-01T00:00:00",
	invalidDateString: "Invalid Date",

	//decimalRegex: "^\\d*[,]?\\d{1,10}$",
	//decimalWithTwoAfterPointsRegex: "^\\d*[,]?\\d{1,2}$",
	//decimalWithFourAfterPointsRegex: "^\\d*[,]?\\d{1,4}$",
	justDigitsRegex: "^\\d{1,5}$",
	twoDigitsRegex: "^[0-9]{2}$",
	tenDigitsRegex: "^[0-9]{10}$",
	sixDigitsRegex: "^[0-9]{6}$",

	dateIsEmpty: function (date) {
		if (date == null) return true;
		if (typeof (date) == "object" && date.getTime() == validationHelper.minDate.getTime()) return true;
		if (typeof (date) == "string") {
			if (validationHelper.beginsWith(date, validationHelper.minDateString)) return true;
			if (date == validationHelper.invalidDateString) return true;
		}

		return false;
	},

	beginsWith: function (text, needle) {
		return text.substring(0, needle.length) == needle;
	},

	getCurrentLockingDate:function (contract,contractLockDateSettings) {
	    if (contractLockDateSettings == null || contract == null || contractLockDateSettings.length === 0) {
	        return null;
	    }

	    var companyId = null;

	    if (contract.Company) {
	        companyId = contract.Company.Id;
	    }

	    var maxDate = null;

	    var companyMaxDate = null;
	    var hasCompany = false;

	    for (var i = 0; i < contractLockDateSettings.length; i++) {

	        if (contractLockDateSettings[i].Company_Id != null &&
	            companyId === contractLockDateSettings[i].Company_Id) {
	            hasCompany = true;
	            if (companyMaxDate == null) {
	                companyMaxDate = contractLockDateSettings[i].LockingDate;
	                continue;
	            }

	            if (contractLockDateSettings[i].LockingDate != null) {

	                if (new Date(contractLockDateSettings[i].LockingDate) > new Date(companyMaxDate)) {
	                    companyMaxDate = contractLockDateSettings[i].LockingDate;
	                }

	            }
	        }

	        if (contractLockDateSettings[i].Company_Id == null) {
	            if (maxDate == null) {
	                maxDate = contractLockDateSettings[i].LockingDate;
	                continue;
	            }

	            if (contractLockDateSettings[i].LockingDate != null) {
	                if (new Date(contractLockDateSettings[i].LockingDate) > new Date(maxDate)) {
	                    maxDate = contractLockDateSettings[i].LockingDate;
	                }
	            }

	        }
	    }

	    if (hasCompany) {
	        return companyMaxDate;
	    }

	    return maxDate;
	}
};