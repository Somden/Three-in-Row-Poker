﻿var reportingHelper = {
    fieldformat: {},
    fieldType: {
        number: { name: "Number", },
        dateTime: { name: "DateTime", },
        boolean_CSV: { name: "Boolean_CSV", },
        string: { name: "String", },
    },

    initializeFieldFormatter: function (resourceFactory, callback) {
        if (!angular.isDefined(reportingHelper.fieldformat.fieldFormatItems)) {
            resourceFactory.fieldFormatterHelper().get().$promise.then(function (arg) {
                reportingHelper.fieldformat = JSON.parse(arg.value);
                if (callback != null)
                    callback(reportingHelper.fieldformat);
            })
            .catch(function (e) {
                console.log(e.status + " : " + e.errorThrown);
            });
        }
    },

    getExportItemsRequest: function (reportSourceName, reportParameters, type, exportConfig, resourceFactory) {
        var exportRequest = {
            ReportSourceName: reportSourceName,
            ReportParameters: reportParameters,

            PropertyFormat: [],
            PropertyDefaultValue: [],
            DefaultIntFormat: "",
            DefaultDecimalFormat: "",
            ExportAll: true,
            DefaultDateFormat: "",
            Format: type,
            Header: exportConfig.Header
        };

        if (angular.isDefined(exportConfig) && angular.isDefined(exportConfig.Format)) {
            for (var f in exportConfig.Format) {
                exportRequest.PropertyFormat.push({
                    key: f,
                    value: exportConfig.Format[f].value
                });
            }
        }

        return resourceFactory
            .report()
            .post(exportRequest)
            .$promise;
    }
}