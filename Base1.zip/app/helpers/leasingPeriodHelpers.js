var leasingPeriodHelpers = {
    // Determines the startdate of given leasing period
	getStartDateForLeasingPeriod: function (selectedLeasingPeriod, contract) {
        if (selectedLeasingPeriod == null)
            return;
        if (contract == null || contract.DisplayedContractRevision == null || contract.DisplayedContractRevision.ContractLeasingPeriod == null)
            return;

        if (selectedLeasingPeriod.Id == contract.DisplayedContractRevision.ContractLeasingPeriod.Id) {
            return contract.CommencementDate;
        }

        var allLeasingPeriods = leasingPeriodHelpers.getAllLeasingPeriodsByContract(contract);
        allLeasingPeriods = allLeasingPeriods.map(function(leasingPeriod) {
            return {
                Id: leasingPeriod.Id,
                EndDate: leasingPeriod.EndDate || 0
            };
        });
        allLeasingPeriods = allLeasingPeriods.sort(function(a, b) {
            return a.EndDate > b.EndDate;
        });

        var lastEndDate = null;
        for (var f in allLeasingPeriods) {
            var leasingPeriod = allLeasingPeriods[f];
            if (leasingPeriod.EndDate == null) {
                continue;
            }

            if (leasingPeriod.Id == selectedLeasingPeriod.Id) {
                break;
            }

            lastEndDate = leasingPeriod.EndDate;
        }

        var startDate = new Date(lastEndDate);

        if (startDate < contract.DisplayedContractRevision.ContractLeasingPeriod.EndDate) {
            startDate = contract.DisplayedContractRevision.ContractLeasingPeriod.EndDate;
        }

        // Take one day after the leasing period end date
        startDate.setDate(startDate.getDate() + 1);

        return startDate;
    },

    // Returns contract leasing period + extension leasing periods in one array
    getAllLeasingPeriodsByContract: function(contract) {
        if (contract == null || contract.DisplayedContractRevision == null) {
            return [];
        }

        var leasingPeriods = [contract.DisplayedContractRevision.ContractLeasingPeriod];

        if (contract.DisplayedContractRevision.ExtensionLeasingPeriods != null) {
            leasingPeriods = leasingPeriods.concat(contract.DisplayedContractRevision.ExtensionLeasingPeriods);
        }

        return leasingPeriods;
    }
};
