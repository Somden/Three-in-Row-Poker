﻿'use strict';
var dateHelper = {

    dateDiffInYears:function (dateold, datenew) {
        var ynew = datenew.getFullYear();
        var mnew = datenew.getMonth();
        var dnew = datenew.getDate();
        var yold = dateold.getFullYear();
        var mold = dateold.getMonth();
        var dold = dateold.getDate();
        var diff = ynew - yold;
        if (mold > mnew) diff--;
        else {
            if (mold == mnew) {
                if (dold > dnew) diff--;
            }
        }
        return diff;
    },

    formatDateToReportParameter:function(date) {
        if (date == null) {
            return null;
        }

        if (typeof date.getMonth === 'function') {
            var month = date.getMonth();
            month = month + 1;
            month = month + "";
            if (month.length<2) {
                month = "0" + month;
            }

            var day = date.getDate() + "";

            if (day.length<2) {
                day = "0" + day;
            }

            return date.getFullYear() + "." + month + "."+day;
        }

        return null;
    }
}