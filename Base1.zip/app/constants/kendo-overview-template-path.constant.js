﻿"use strict";

angular
    .module("LeadApp")
    .constant("KENDO_OVERVIEW_TEMPLATE_PATH", "/app/templates/kendo-grid-overview.template.html?cache=" + globalConfig.htmlCacheToken);