﻿Date.prototype.toJSON = function () {
    var year = this.getFullYear().fillWith("0", 4);
    var month = (this.getMonth() + 1).fillWith("0", 2);
    var day = this.getDate().fillWith("0", 2);
    var hours = this.getHours().fillWith("0", 2);
    var minutes = this.getMinutes().fillWith("0", 2);
    var seconds = this.getSeconds().fillWith("0", 2);
    var milliseconds = this.getMilliseconds().fillWith("0", 3);

    return year + "-" + month + "-" + day + "T" + hours + ":" + minutes + ":" + seconds + "." + milliseconds + "Z";
};

Date.prototype.convertTimeToLocalTime = function () {
    this.setMinutes(this.getMinutes() + this.getTimezoneOffset());

    var minDate = new Date("0001-01-01T00:00:00Z");
    if (this < minDate) {
        this.setUTCFullYear(1);
        this.setUTCMonth(0);
        this.setUTCDate(1);
        this.setUTCHours(0);
        this.setUTCMinutes(0);
        this.setUTCSeconds(0);
        this.setUTCMilliseconds(0);
    }

    return this;
};