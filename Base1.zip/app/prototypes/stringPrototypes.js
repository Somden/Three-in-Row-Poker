﻿// Removes given preAndPostFix from the string, if preAndPostFix is at the beginning AND at the end of the string
String.prototype.removePreAndPostFix = function (preAndPostFix) {
    if (this.indexOf(preAndPostFix) == 0 && this.endsWith(preAndPostFix)) {
        return this.substr(1, this.length - 2)
    }

    return this;
};

// Removes given prefix from the string, if prefix is at the beginning of the string
String.prototype.removePrefix = function (prefix) {
    if (this.indexOf(prefix) == 0) {
        return this.substr(prefix.length)
    }

    return this;
};

if (String.prototype.startsWith == null) {
    String.prototype.startsWith = function (search) {
        return this.slice(0, search.length) === search;
    };
}