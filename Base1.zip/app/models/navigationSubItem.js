﻿'use strict';

function NavigationSubItem(titleTranslationKey, path, subItemOf, highlightSubPaths) {
    this.titleTranslationKey = titleTranslationKey;
    this.path = path;
    this.subItemOf = subItemOf;
    this.highlightSubPaths = highlightSubPaths;
}