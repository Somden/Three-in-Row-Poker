﻿'use strict';

function NavigationExtensionSubItem(titleTranslationKey, extensionName, subItemOf) {
    this.titleTranslationKey = titleTranslationKey;
    this.extensionName = extensionName;
    this.path = "/extension/" + extensionName;
    this.subItemOf = subItemOf;
}