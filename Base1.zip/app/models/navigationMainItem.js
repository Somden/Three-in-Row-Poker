﻿'use strict';

function NavigationMainItem(id, titleTranslationKey, icon) {
    this.id = id;
    this.titleTranslationKey = titleTranslationKey;
    this.icon = icon;
    this.hasSubItems = true;
    this.isMainItem = true;
}